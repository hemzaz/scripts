import subprocess
import os


def crx2rnx_path():
    return os.path.join(os.path.split(__file__)[0], 'linux', 'CRX2RNX')
