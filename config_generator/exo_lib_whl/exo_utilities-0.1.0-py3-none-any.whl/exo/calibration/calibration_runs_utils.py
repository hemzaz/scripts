import json
from concurrent.futures import ThreadPoolExecutor
from exo.utilities import s3
from io import BytesIO
import tarfile
import click
from datetime import datetime, timedelta
from itertools import chain
import tabulate
import gzip
from exo.utilities.range_s3_search import iterator,range_s3_search


def list_dir(folder):
    return [folder + '/' + key for key in s3.list_dir(folder)]


def list_calibration_runs(
        prefix,
        min_date=None,
        max_date=None):
    runs = range_s3_search(
            path=prefix,
            start_date=min_date,
            end_date=max_date)
    return runs

def get_latest_done(prefix):
    for run in iterator(prefix,reverse=True):
        if done_exists(run_path=run['path']):
            return run
    raise Exception("didn't find done calibration")


def get_run_info(run_path):
    return json.loads(s3.get_object(F"{run_path}/run_info.json"))

def get_iono_summary(run_path):
    return json.loads(s3.get_object(F"{run_path}/iono-summary.json"))


def get_products_json(run_path):
    return json.loads(s3.get_object(F"{run_path}/products-metadata.json"))

def run_info_exists(run_path):
    return s3.object_exists(F"{run_path}/run_info.json")

def done_exists(run_path):
    return s3.object_exists(F"{run_path}/done.json")

def obs_chk_exists(run_path):
    return s3.object_exists(F"{run_path}/obs.chk.gz")

def check_if_error_file_exists(run_path,mwb_flavor):
    return s3.object_exists(F"{run_path}/{mw_error_file_name(mwb_flavor)}")    

def get_obs_chk(run_path):
    return json.loads(gzip.decompress(s3.get_object(F"{run_path}/obs.chk.gz")))




def get_run_zone(run):
    try:
        return get_run_info(run)['tags']['zone']
    except Exception as ex:
        pass
    return run.split('/')[-6]

def download_error_file(run_path, dest_dir,mwb_flavor):
    temp = BytesIO()
    print(F"{run_path}/{mw_error_file_name(mwb_flavor)}")
    temp.write(s3.get_object(F"{run_path}/{mw_error_file_name(mwb_flavor)}"))
    temp.seek(0)
    tar = tarfile.open(fileobj=temp)
    tar.extractall(dest_dir)



from enum import Enum
class mwb_flavors(Enum):
    gps_l1_l2 = "gps_l1_l2"
    gps_l1_l5 = "gps_l1_l5"
    galileo_e1_e5a = "galileo_e1_e5a"
    galileo_e1_e5b = "galileo_e1_e5b"

def mw_error_file_name(calibration_type):
    if calibration_type == mwb_flavors.gps_l1_l2:
        return "mwb-gps-error-l1-l2.tar.gz"
    elif calibration_type == mwb_flavors.gps_l1_l5:
        return "mwb-gps-error-l1-l5.tar.gz"
    elif calibration_type == mwb_flavors.galileo_e1_e5a:
        return "mwb-galileo-error-e1-e5a.tar.gz"
    elif calibration_type == mwb_flavors.galileo_e1_e5b:
        return "mwb-galileo-error-e1-e5b.tar.gz"
    
    raise NotImplementedError(F"{calibration_type} not supported")

now = datetime.now()
ACCEPTED_DATE_TIME_FORMAT = ['%Y-%m-%dT%H:%M:%S', '%Y-%m-%d']


@click.group()
def cli():
    pass

@click.option('--s3-prefix', default='s3://lear-exo-foc-staging-calibration-calibration/runs')
@click.option('--start-date',
              default=(now - timedelta(days=6)).strftime('%Y-%m-%dT%H:%M:%S'),
              type=click.DateTime(formats=ACCEPTED_DATE_TIME_FORMAT))
@click.option('--end-date',
              default=(now - timedelta(days=0)).strftime('%Y-%m-%dT%H:%M:%S'),
              type=click.DateTime(formats=ACCEPTED_DATE_TIME_FORMAT))
@click.option('--output-type', default='table',
              type=click.Choice(["json", "table"]))
@cli.command()
def list(s3_prefix, start_date, end_date, output_type):
    runs = list_calibration_runs(
            s3_prefix,
            start_date,
            end_date,
            )
    if output_type == "table":
        print(tabulate.tabulate([[run['time'].isoformat(),run['path']] for run in runs], ["time",'path']))
    elif output_type == "json":
        for run in runs:
            run['time'] = run['time'].isoformat()
        print(json.dumps(runs))
    else:
        raise Exception("Unsupported output_type")


@cli.command()
@click.option('--s3-prefix', default='s3://lear-exo-foc-staging-calibration-calibration/runs')
@click.argument('output_file')
def latest_done(s3_prefix,output_file):
    with open(output_file,'w') as f:
        latest = get_latest_done(s3_prefix)
        output = dict(s3_path = latest['path'],time = latest['time'].isoformat())
        json.dump(output,f)

