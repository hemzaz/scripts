import boto3
import re
from botocore.exceptions import ClientError
import logging

client = boto3.client('s3')


def split_path(path):
    return re.findall(r'[sS]3://([^//]+)/(.*)', path)[0]


def list_dir(s3_path):
    bucket, prefix = split_path(s3_path)
    prefix = prefix + '/'
    res = client.list_objects(Bucket=bucket, Prefix=prefix, Delimiter='/')
    return [x.get('Prefix')[len(prefix):-1]
            for x in res.get('CommonPrefixes', [])]

def generate_presigned_url(s3_path,timeout=180):
    bucket, prefix = split_path(s3_path)
    response = client.generate_presigned_url('get_object',
                                                Params={'Bucket': bucket,
                                                        'Key': prefix},
                                                ExpiresIn=timeout)
    return response

def list_files(s3_path, file_prefix=''):
    bucket, prefix = split_path(s3_path)
    prefix = prefix + '/'
    if file_prefix:
        prefix = prefix + file_prefix
    continuation_token = None
    output = []
    base_kwargs = dict(
        Bucket=bucket, Prefix=prefix, Delimiter='/'
    )
    while True:
        list_kwargs = dict(MaxKeys=1000, **base_kwargs)
        if continuation_token:
            list_kwargs['ContinuationToken'] = continuation_token
        response = client.list_objects_v2(**list_kwargs)
        output = output + response.get('Contents', [])
        if not response.get('IsTruncated'):  # At the end of the list?
            break
        continuation_token = response.get('NextContinuationToken')
    return [x.get('Key')[len(split_path(s3_path)[1]) + 1:] for x in output]


def upload_file(file_name, to, **args):
    bucket, object_name = split_path(to)
    try:
        response = client.upload_file(file_name, bucket, object_name, **args)
    except ClientError as e:
        logging.error(e)
        return False
    return True


def download_file(key, dest_file):
    bucket, object_name = split_path(key)
    client.download_file(bucket, object_name, dest_file)


def get_object(path):
    bucket, key = split_path(path)
    obj = client.get_object(Bucket=bucket, Key=key)
    return obj['Body'].read()


def object_exists(path):
    bucket, key = split_path(path)
    try:
        client.head_object(Bucket=bucket, Key=key)
        return True
    except ClientError:
        return False


def copy_object(source, dest):
    if source.startswith('s3://') and not dest.startswith('s3://'):
        data = get_object(source)
        with open(dest, 'wb') as f:
            f.write(data)
    elif not source.startswith('s3://') and dest.startswith('s3://'):
        with open(source, 'rb') as f:
            write_to_key(f.read(), dest)
    else:
        print(source, dest)
        raise NotImplementedError()


def write_to_key(data, path, tags=None):
    kwargs = {}
    bucket, key = split_path(path)
    if tags is not None:
        kwargs['Tagging'] = "&".join(
            [F"{key}={value}" for key, value in tags.items()])
    client.put_object(Bucket=bucket, Key=key, Body=data, **kwargs)


def put_tags(path, tags):
    kwargs = {}
    bucket, key = split_path(path)
    kwargs['Tagging'] = dict(
        TagSet=[
            dict(
                Key=key,
                Value=value) for key,
            value in tags.items()])
    client.put_object_tagging(Bucket=bucket, Key=key, **kwargs)


