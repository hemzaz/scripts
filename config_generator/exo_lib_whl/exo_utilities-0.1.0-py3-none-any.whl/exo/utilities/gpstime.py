"""
  2  A Python implementation of GPS related time conversions.
  3
  4  Copyright 2002 by Bud P. Bruegger, Sistema, Italy
  5  mailto:bud@sistema.it
  6  http://www.sistema.it
  7
  8  Modifications for GPS seconds by Duncan Brown
  9
 10  PyUTCFromGpsSeconds added by Ben Johnson
 11
 12  This program is free software; you can redistribute it and/or modify it under
 13  the terms of the GNU Lesser General Public License as published by the Free
 14  Software Foundation; either version 2 of the License, or (at your option) any
 15  later version.
 16
 17  This program is distributed in the hope that it will be useful, but WITHOUT ANY
 18  WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 19  PARTICULAR PURPOSE.  See the GNU Lesser General Public License for more
 20  details.
 21
 22  You should have received a copy of the GNU Lesser General Public License along
 23  with this program; if not, write to the Free Software Foundation, Inc., 59
 24  Temple Place, Suite 330, Boston, MA  02111-1307  USA
 25
 26  GPS Time Utility functions
 27
 28  This file contains a Python implementation of GPS related time conversions.
 29
 30  The two main functions convert between UTC and GPS time (GPS-week, time of
 31  week in seconds, GPS-day, time of day in seconds).  The other functions are
 32  convenience wrappers around these base functions.
 33
 34  A good reference for GPS time issues is:
 35  http://www.oc.nps.navy.mil/~jclynch/timsys.html
 36
 37  Note that python time types are represented in seconds since (a platform
 38  dependent Python) Epoch.  This makes implementation quite straight forward
 39  as compared to some algorigthms found in the literature and on the web.
 40  """

import math
import calendar
import datetime
from collections import namedtuple
gps_struct = namedtuple(
    'gps_struct', [
        'week', 'sec_of_week', 'day', 'gps_sec_of_day', 'day_in_year'])
_leapSecs = 18
secsInWeek = 604800
secsInDay = 86400
gpsEpoch = (1980, 1, 6, 0, 0, 0)  # (year, month, day, hh, mm, ss)


def from_utc(date_time, leapSecs=_leapSecs):
    secFract = date_time.microsecond / 1e6
    epochTuple = gpsEpoch + (0, -1, 0)
    t0 = calendar.timegm(epochTuple)
    t = calendar.timegm((date_time.year, date_time.month, date_time.day,
                         date_time.hour, date_time.minute, int(date_time.second), 0, -1, 0))
    t = t + leapSecs
    tdiff = t - t0
    gpsSOW = (tdiff % secsInWeek) + secFract
    gpsWeek = int(math.floor(tdiff / secsInWeek))
    gpsDay = int(math.floor(gpsSOW / secsInDay))
    gpsSOD = (gpsSOW % secsInDay)
    day_in_year = (t - calendar.timegm((date_time.year, 1, 1,
                                        0, 0, 0, 0) + (0, -1, 0))) / secsInDay + 1
    return gps_struct(gpsWeek, gpsSOW, gpsDay, gpsSOD, day_in_year)
