import shutil
import os
from . import s3
import io
from .tar_creator import create_tar
import json
import boto3
import subprocess
import tempfile
import tarfile
import logging
import re
import hashlib


class s3_diff_saver:
    def __init__(self, folder, working_folder=None, exculde=None):
        self._folder = folder
        self._saved_diffs = []
        self._working_folder = working_folder
        self._exculde = exculde

    def _meta_data_diff_file(self):
        return os.path.join(self._working_folder, 'diff_metadata.json')

    def _copy_folder(self):
        return os.path.join(
            self._working_folder,
            'copy',
            os.path.split(
                self._folder)[1])

    def _old_folder(self):
        return os.path.join(
            self._working_folder,
            'old',
            os.path.split(
                self._folder)[1])

    def _diff_file(self):
        return os.path.join(self._working_folder, 'diff.patch')

    def create_diff(self, s3_path):
        if not os.path.exists(self._meta_data_diff_file()):
            self._save_first(s3_path)
        else:
            diff_ignore = ""
            if self._exculde:
                diff_ignore = F"--exclude={self._exculde}"
            shutil.copytree(
                self._folder,
                self._copy_folder(),
                ignore=self._get_ignore())
            subprocess.call(
                F'diff -Naur {diff_ignore} "{self._old_folder()}" "{self._copy_folder()}" > "{self._diff_file()}"',
                shell=True)
            x = open(self._diff_file()).read()
            folder_name = os.path.split(self._folder)[-1]
            s = F'diff -Naur {self._old_folder()}/(.*) {self._copy_folder()}/(.*)'
            x = re.sub(s, rF'diff -Naur {folder_name}/\1 {folder_name}/\2', x)
            x = re.sub(rF'--- {self._old_folder()}/(.*)\t',
                       rF'--- {folder_name}/\1\t', x)
            x = re.sub(
                rF'\+\+\+ {self._copy_folder()}/(.*)\t',
                rF'+++ {folder_name}/\1\t',
                x)
            open(self._diff_file(), 'w').write(x)
            temp_tar = tempfile.mktemp()
            current_md5 = self._get_md5_for_folder(self._copy_folder())
            metadata = json.load(open(self._meta_data_diff_file()))
            metadata['current_md5'] = self._get_md5_for_folder(
                self._copy_folder())
            with open(self._meta_data_diff_file(), 'w') as f:
                f.write(json.dumps(metadata))
            tar_to_upload = create_tar(
                [self._meta_data_diff_file(), self._diff_file()])
            s3.upload_file(tar_to_upload, s3_path)
            metadata['diffs'].append(
                dict(
                    s3_path=s3_path,
                    current_md5=current_md5,
                    old_md5=self._get_md5_for_folder(
                        self._old_folder())))
            shutil.rmtree(self._old_folder(), ignore_errors=True)
            shutil.copytree(
                self._copy_folder(),
                self._old_folder(),
                ignore=self._get_ignore())
            shutil.rmtree(self._copy_folder(), ignore_errors=True)
            with open(self._meta_data_diff_file(), 'w') as f:
                f.write(json.dumps(metadata))

    def recreate(self, s3_path):
        shutil.rmtree(self._folder, ignore_errors=True)
        x = s3.get_object(s3_path)
        logging.info(F"downloading {s3_path}")
        base = tarfile.open(fileobj=io.BytesIO(x))
        is_diff_file = [member for member in base.getmembers(
        ) if member.name == 'diff_metadata.json']
        if is_diff_file:
            logging.info(F"{s3_path} is diff file")
            metadata = json.load(base.extractfile('diff_metadata.json'))
            os.makedirs(self._folder, exist_ok=True)
            with open(os.path.join(self._folder, 'diff_metadata.json'), 'w') as f:
                f.write(json.dumps(metadata))
            base_tar = metadata['diffs'][0]['s3_path']
            version = metadata.get('version', 0)
            logging.info(F'download base tar {base_tar}')
            s3_client = boto3.client('s3')
            bucket, key = s3.split_path(base_tar)
            fileobj = io.BytesIO()
            s3_client.download_fileobj(
                bucket,
                key,
                fileobj,
                Config=boto3.s3.transfer.TransferConfig(
                    multipart_threshold=2 * 1e6,
                    max_concurrency=20,
                    multipart_chunksize=int(1e6)))
            logging.info(F'Done download base tar {base_tar}')
            fileobj.seek(0)
            root_tar = tarfile.open(fileobj=fileobj)
            root_tar.extractall(self._folder)
            diffs = [self._get_diff_file(
                diff['s3_path']) for diff in metadata['diffs'][1:]] + [base.extractfile('diff.patch')]
            for diff in diffs:
                current_files_md5 = self._get_md5_for_folder(self._folder)
                diff_file = tempfile.mktemp()
                with open(diff_file, 'wb') as f:
                    x = diff.read()
                    f.write(x)
                command = F"patch {metadata.get('patch_args','--strip 2 -E')} -F 0 -d {self._folder} -i {diff_file}"
                subprocess.call(
                    command,
                    shell=True,
                    stdin=None,
                    stdout=None,
                    stderr=None)
                os.remove(diff_file)
        else:
            base.extractall(self._folder)

    def _get_diff_file(self, s3_path):
        logging.info(F'downloading diff {s3_path}')
        s3_object = s3.get_object(s3_path)
        return tarfile.open(fileobj=io.BytesIO(
            s3_object)).extractfile('diff.patch')

    def _get_md5_for_folder(self, folder):
        md5sums = {}
        for root, folder, files in os.walk(folder):
            for file in files:
                file_name = os.path.join(os.path.split(root)[-1], file)
                hash_md5 = hashlib.md5()
                with open(os.path.join(root, file), 'rb') as f:
                    for chunk in iter(lambda: f.read(4096), b""):
                        hash_md5.update(chunk)
                md5sums[file_name] = hash_md5.hexdigest()
        return md5sums

    def _get_ignore(self):
        if self._exculde:
            return shutil.ignore_patterns(F"**{self._exculde}")
        return None

    def _save_first(self, s3_path):
        shutil.rmtree(self._working_folder, ignore_errors=True)
        shutil.copytree(
            self._folder,
            self._old_folder(),
            ignore=self._get_ignore())
        tar = create_tar(self._old_folder())
        s3.upload_file(tar, s3_path)
        os.remove(tar)
        data = dict()
        data['version'] = 1
        data['patch_args'] = '--strip 0'
        data['diffs'] = [
            dict(
                s3_path=s3_path,
                current_md5=self._get_md5_for_folder(
                    self._old_folder()))]
        with open(self._meta_data_diff_file(), 'w') as f:
            f.write(json.dumps(data))
