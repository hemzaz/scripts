import click
import re
from datetime import timedelta


class TimeDelta(click.ParamType):
    name = 'timedelta'

    def get_metavar(self, param):
        return r'[\d+(y|years|w|weeks|d|days|h|hours|m|minutes|s|seconds)]'

    def get_missing_message(self, param):
        return 'Please set TimeDelta'

    def convert(self, value, param, ctx):
        REGEX = r'(\-*\d+)\s*(.*)'
        parse = re.findall(REGEX, value)
        if not parse:
            self.fail(F'Failed to parse {value}')
        num, units = parse[0]
        num = float(num)
        units = units.lower()
        if re.findall(r'(^m$|^min$|^minutes$)', units):
            return timedelta(minutes=num)
        if re.findall(r'(^h$|^hour$|^hours$)', units):
            return timedelta(hours=num)
        elif re.findall(r'(^d$|^day$|^days$)', units):
            return timedelta(days=num)
        elif re.findall(r'(^w$|^week$|^weeks$)', units):
            return timedelta(days=num * 7)
        elif re.findall(r'(^y$|^year$|^years$)', units):
            return timedelta(days=num * 365)
        elif re.findall(r'(^s$|^sec$|^seconds$)', units):
            return timedelta(seconds=num)
        else:
            self.fail(F'Unsupported unit {units}')
        return value

    def __repr__(self):
        return 'TIMEDELTA'


ACCEPTED_DATE_TIME_FORMAT = ['%Y-%m-%dT%H:%M:%S', '%Y-%m-%d']


class DateTime(click.DateTime):
    def __init__(self, formats=ACCEPTED_DATE_TIME_FORMAT):
        super().__init__(formats=formats)


TIMEDELTA = TimeDelta()


class S3Path(click.ParamType):
    def __init__(self, *args, **kwargs):
        self._dir = kwargs.pop('dirs', True)
        self._file = kwargs.pop('files', True)
        super().__init__(*args, **kwargs)
    name = 'S3://<bucket-name>/prefix'

    def convert(self, value, param, ctx):
        regexs = []
        if self._dir:
            regexs.append(r'^[Ss]3://.*/$')
        if self._file:
            regexs.append(r'^[Ss]3://.*/[a-zA-Z0-9-_]+$')
        if not any([re.match(regex, value) for regex in regexs]):
            self.fail(
                f'{value} is not according to S3 format. {" ".join(regexs)}',
                param,
                ctx,
            )
        return value


class Label(click.ParamType):
    name = 'label'

    def convert(self, value, param, ctx):
        found = re.match(r'([a-zA-Z0-9]+):([a-zA-Z0-9]+)$', value)
        if not found:
            self.fail(
                f"{value} is not according to label format. '<key>:<value>'",
                param,
                ctx,
            )
        return found.groups()


class EnumType(click.Choice):
    def __init__(self, enum):
        self.__enum = enum
        super().__init__(enum.__members__)

    def convert(self, value, param, ctx):
        return self.__enum[super().convert(value, param, ctx)]
