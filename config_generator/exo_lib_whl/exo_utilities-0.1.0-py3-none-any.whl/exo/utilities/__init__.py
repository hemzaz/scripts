def exo_range(start, stop, step):
    while start < stop:
        yield start
        start = start + step
