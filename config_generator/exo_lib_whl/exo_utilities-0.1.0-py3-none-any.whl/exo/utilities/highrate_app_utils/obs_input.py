import os
from retrying import retry
from exo.utilities.prometheus import GetPrometheusInputs
from .softlink import softlink
from contextlib import contextmanager
from filelock import Timeout, FileLock
import logging
import time

logger = logging.getLogger(__name__)
class ObsInput():
  def __init__(self,working_folder,run_folder):
    self._run_folder = run_folder
    self._working_folder = working_folder
    self._prometheus = GetPrometheusInputs('http://localhost:5555')
    

  @contextmanager
  def prepare(self):
    self._check_ready()
    with softlink(os.path.join(self._working_folder,'obs')
                      ,os.path.join(self._run_folder,'obs')):
      lock = FileLock(os.path.join(self._run_folder,'obs','lock.lock'))
      with lock:
        yield

  @retry(stop_max_delay=15 * 60 * 1000,wait_fixed=2000)
  def _check_ready(self):
    try:
      logger.info('waiting for obs to be ready')
      self._prometheus.refresh()
      if self._prometheus.get_single_sample(name = 'rinex_files_readiness').value != 1.0:
        raise Exception("Wait for rinex file to be ready")
    except Exception as ex:
      time.sleep(15)
      logger.info(F'obs are not ready, {ex}')
      raise
    