import os 
from contextlib import contextmanager

@contextmanager
def softlink(src,dest):
  try:
    os.symlink(src,dest)
    yield
  finally:
    print('delete')
    os.remove(dest)
