import os
import shutil
from contextlib import contextmanager
from retrying import retry
from exo.utilities.prometheus import GetPrometheusInputs
from .softlink import softlink
import logging
logger = logging.getLogger(__name__)

class NavInput():
  def __init__(self,working_folder,run_folder):
    self._run_folder = run_folder
    self._working_folder = working_folder
    self._nav_prometheus = GetPrometheusInputs('http://localhost:9092')

  @retry(stop_max_delay=2 * 60 * 1000,wait_fixed=2000)
  def _get_nav_current_id(self):
    try:
      self._nav_prometheus.refresh()
      nav_currnet_id = self._nav_prometheus.get_single_sample(name = 'ready_counter').value
      if nav_currnet_id<0:
          raise Exception("nav not ready")
      return nav_currnet_id
    except Exception as ex:
      logger.info('waiting for nav',ex)
      raise

  def _source_nav_dir(self):
    return os.path.join(self._working_folder,'nav')

  @contextmanager
  def prepare(self):
    current_nav_id = int(self._get_nav_current_id())
    nav_dirs = os.listdir(self._source_nav_dir())
    dirs_to_delete = [nav_dir for nav_dir in nav_dirs if int(nav_dir) < current_nav_id]
    for dir_to_delete in dirs_to_delete:
      path = os.path.join(
          self._source_nav_dir(),
          dir_to_delete)
      shutil.rmtree(path)
    with softlink(os.path.join(
        self._source_nav_dir(),str(current_nav_id)
        ),os.path.join(self._run_folder,'nav')):
      yield None
