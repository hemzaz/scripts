import os
import json
import shutil
import re
from retrying import retry
from contextlib import contextmanager
import logging
logger = logging.getLogger(__name__)

class ProductRequirement():
  def __init__(self,source_dir,needed_products):
    self._source_dir = source_dir
    self.needed_products = needed_products

  def _get_files_source_dir(self):
    return self._source_dir

  def _get_metadata_json_file(self):
    return os.path.join(self._get_files_source_dir(),'metadata.json')
  
  def _load_json(self):
    return json.load(open(self._get_metadata_json_file()))

  def copy(self,dest_folder):
    products_to_copy = []
    for product_data in self._load_json()['files']:
      if any([x for x in self.needed_products if re.findall(x,product_data['relative_dest_path'])]):
        products_to_copy.append(product_data)
        source_path = os.path.join(self._get_files_source_dir(),product_data['relative_dest_path'])
        dest_path = os.path.join(dest_folder,product_data['relative_dest_path'])
        os.makedirs(os.path.split(dest_path)[0],exist_ok=True)
        shutil.copyfile(source_path,dest_path)
    return products_to_copy

class DynamicProductRequirement(ProductRequirement):
  def _get_latest_done_folder(self):
    folders = [int(x) for x in os.listdir(self._source_dir)]
    folders.sort()
    folders = folders[::-1]
    found = None
    for i in folders:
      if not found:
        if os.path.exists(os.path.join(self._source_dir,str(i),'done.txt')):
          found =  os.path.join(self._source_dir,str(i))
      else:
        shutil.rmtree(os.path.join(self._source_dir,str(i)))
    if found==None:
      raise Exception('no Done.txt files in any source dir')
    return found

  def _get_files_source_dir(self):
    return self._current_download_dir
  
  @retry(stop_max_delay=2 * 60 * 1000,wait_fixed=2000)
  def copy(self,dest_folder):
    self._current_download_dir = self._get_latest_done_folder()
    return super().copy(dest_folder)


class ProductInput():
  def __init__(self,inputs):
    self._inputs = inputs

  @contextmanager
  def prepare(self,dest_folder):
    files = []
    for input in self._inputs:
      files.extend(input.copy(dest_folder=dest_folder))
    with open(os.path.join(dest_folder,'metadata.json'),'w') as f:
      f.write(json.dumps(dict(files = files)))
    yield
    shutil.rmtree(dest_folder)


