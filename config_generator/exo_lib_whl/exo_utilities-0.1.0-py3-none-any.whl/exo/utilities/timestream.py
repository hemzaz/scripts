import boto3
import awswrangler as wr
from more_itertools import sliced


def get_arn_properties(arn):
    components = arn.split(':')
    properties = dict(sliced(components[-1].split('/'), 2))
    properties['region'] = components[3]
    properties['account'] = components[4]

    return properties

def get_type_string(value):
    if type(value) == float:
        return 'DOUBLE'
    raise Exception('Not supported')

def write_record(table_arn, name, time, value, labels={}):
    arn_properties = get_arn_properties(table_arn)
    session = boto3.session.Session(region_name=arn_properties['region'])
    write_client = session.client('timestream-write',)

    record = {
        'Dimensions': [dict(Name=key.replace('-','_'),Value=value) for key,value in labels.items()],
        'MeasureName': name,
        'MeasureValue': str(value),
        'MeasureValueType': get_type_string(value) ,
        'Time': str(int(time.timestamp()* 1000)),
        'TimeUnit': 'MILLISECONDS',

    }
    
    result = write_client.write_records(DatabaseName=arn_properties['database'],TableName= arn_properties['table'],
                                       Records=[record], CommonAttributes={})


def DataFrameToTimeStream(table_arn, data_frame,
                          values_columns,
                          labels_columns=[],
                          time_column='time',
                          labels={},
                          name_prefix=''):
    labels = dict([(k.replace('-', '_'), v) for k, v in labels.items()])
    arn_properties = get_arn_properties(table_arn)
    for key, value in labels.items():
        data_frame[key] = value
    for value_column in values_columns:
        data_frame[name_prefix+value_column] = data_frame[value_column]
        data_frame_temp = data_frame[data_frame[name_prefix +
                                                value_column].notnull()]
        session = boto3.session.Session(region_name=arn_properties['region'])

        rejected_records = wr.timestream.write(
            df=data_frame_temp,
            database=arn_properties['database'],
            table=arn_properties['table'],
            time_col=time_column,
            measure_col=name_prefix + value_column,
            dimensions_cols=labels_columns + list(labels.keys()),
            boto3_session=session
        )
