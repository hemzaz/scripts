from prometheus_client.parser import text_string_to_metric_families
import requests

class GetPrometheusInputs:
  def __init__(self,url):
    self._url = url

  def refresh(self):
    response = requests.get(self._url)
    response.raise_for_status()
    self._data = list(text_string_to_metric_families(response.text))

  def get_metric(self,name):
    if self._data == None:
      raise NoMetric('please refresh first')
    return [item for item in self._data if item.name == name][0]

  def get_samples(self,name,tags = {}):
    res  = []
    for sample in self.get_metric(name=name).samples:
      if sample.labels.items() <= tags.items():
        res.append(sample)
    return res

  def get_single_sample(self,name,tags= {}):
    res = self.get_samples(name = name, tags= tags)
    if len(res)== 1:
      return res[0]
    elif len(res) == 0:
      raise NoSample("No Sample")
    else:
      raise MoreThenOnSample(F"{len(res)}")


class NoMetric(IOError):
  pass

class NoSample(IOError):
  pass

class MoreThenOnSample(IOError):
  pass

