import tarfile
import tempfile
import os
import re
from stat import *


def reset(tarinfo):
    if tarinfo.name != "":
        tarinfo.uid = tarinfo.gid = 0
        tarinfo.uname = tarinfo.gname = "unknown"
    return tarinfo

def _check_regex(path,include_regex):
    if include_regex==None:
        return True
    if re.findall(include_regex,path):
        return True
    return False
from IPython import embed


def create_tar(what, temp=tempfile.mktemp(),no_dir_name=False,include_regex=None):
    if isinstance(what, str):
        what = [what]
    with tarfile.open(temp, "w:gz", dereference=True) as tar:
        for file_or_folder in what:

            if os.path.isdir(file_or_folder):
                for root, subFolders, files in os.walk(file_or_folder):
                    for file in files:
                        file_path = os.path.join(root,file)
                        file_used_name = os.path.relpath(os.path.join(root,file),file_or_folder)
                        if not no_dir_name:
                            file_used_name = os.path.join(os.path.split(file_or_folder)[1],file_used_name)
                        if _check_regex(path = file_used_name,include_regex=include_regex):
                            tar.add(file_path, arcname=file_used_name, filter=reset)

            else:
                tar.add(file_or_folder, arcname=os.path.split(
                    file_or_folder)[1], filter=reset)
    return temp