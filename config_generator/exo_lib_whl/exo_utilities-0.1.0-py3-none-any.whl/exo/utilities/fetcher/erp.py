import ftputil
from datetime import timedelta
import os
import subprocess
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver
from exo.utilities import gpstime
from exo.utilities.fetcher.cddis_fetcher import create_cddis_fetcher

from enum import Enum


class ErpTypes(Enum):
    igs_daily = "igs_daily"
    igs_weekly = "igs_weekly"
    igr_daily = "igr_daily"


def erp_filename(time, erp_type):
    gps_time = gpstime.from_utc(time)
    if erp_type == ErpTypes.igs_daily:
        return F"igs{gps_time.week}{gps_time.day}.erp"
    if erp_type == ErpTypes.igr_daily:
        return F"igr{gps_time.week}{gps_time.day}.erp"
    elif erp_type == ErpTypes.igs_weekly:
        return F"igs{gps_time.week}7.erp"
    else:
        raise Exception("Not supported erp_type")


class ErpDownloader:
    def __init__(self):
        self._fetcher = create_cddis_fetcher()

    def download(self, time, dest_folder, erp_type):
        gps_time = gpstime.from_utc(time)
        erp_file_name = erp_filename(time=time, erp_type=erp_type)
        remote_path = F"archive/gnss/products/{gps_time.week}/{erp_file_name}.Z"
        dest_path = os.path.join(dest_folder, erp_file_name)
        self._fetcher.download(remote_path, dest_path + '.Z')
        subprocess.check_output(['uncompress', '-f', dest_path + '.Z'])
        return dest_path


class ErpArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix, **kwargs):
        super().__init__(s3_prefix, step=timedelta(days=1), fill_thread=1, **kwargs)

    def _for_each_time(self, time):
        yield {"time": time,
               'key': F"{time.year}/{erp_filename(time, erp_type=ErpTypes.igr_daily)}",
               'erp_type': ErpTypes.igr_daily,
               'restore_file_name': erp_filename(time, erp_type=ErpTypes.igr_daily)}

    def _download_file(self, x):
        new_file = ErpDownloader().download(
            dest_folder=self._workdir,
            time=x['time'],
            erp_type=x['erp_type'])
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
