import subprocess
import itertools
import re
import more_itertools
import os
import tempfile


def get_stations_info_from_site(site):
    tempdir = tempfile.mkdtemp()
    os.makedirs(tempdir, exist_ok=True)
    temp_file_name = site.replace("/", "")\
        .replace("http", "").replace("https", "") \
        .replace(".", "_").replace('-', "_")
    full_file_name = os.path.join(tempdir, temp_file_name)
    raw = subprocess.check_output(["curl", site]).decode('utf-8')
    lines = raw.split("\n")
    lines_filtered = [line for line in lines if line.startswith("STR")]
    header = [
        "type",
        "mountpoint",
        'identidier',
        "format",
        "format_details",
        "Carrier",
        "System",
        "network",
        "Country",
        "latitude",
        "longitude",
        "NMEA",
        "Solution",
        "Generator",
        "Compress",
        "Auth",
        "fee",
        "bitrate",
        "Misc"]
    data = [dict(zip(header, line.split(';')))for line in lines_filtered]
    for item in data:
        item['System'] = list(item['System'].split('+'))
        item['caster'] = site
        item['format_details'] = list(more_itertools.flatten(
            [format_message(x) for x in item['format_details'].split(',')]))
    return data


def format_message(text):
    has_rate = re.findall(r'(\d+)\((\d+)\)', text)
    if has_rate:
        message_type_text = has_rate[0][0]
        for message_type in message_type_text.split('/'):
            yield dict(message_type=message_type, rate=int(has_rate[0][1]))
    elif re.findall(r'(\d+)\((.+)\)', text):
        has_rate = re.findall(r'(\d+)\((.+)\)', text)
        message_type_text = has_rate[0][0]
        for message_type in message_type_text.split('/'):
            yield dict(message_type=message_type, rate=has_rate[0][1])
    else:
        yield dict(message_type=text)
