import ftputil
from datetime import timedelta
import os
import subprocess
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver
from exo.utilities import gpstime
from exo.utilities.fetcher.cddis_fetcher import create_cddis_fetcher
from enum import Enum


def sinex_file_name(time):
    gps_time = gpstime.from_utc(time)
    return F"igs20P{gps_time.week}.ssc"


class SinexDownloader:
    def __init__(self):
        self._fetcher = create_cddis_fetcher()

    def download(self, time, dest_folder):
        gps_time = gpstime.from_utc(time)
        file_name = sinex_file_name(time=time)
        remote_path = F"archive/gnss/products/{gps_time.week}/{file_name}.Z"
        dest_path = os.path.join(dest_folder, file_name)
        self._fetcher.download(remote_path, dest_path + '.Z')
        subprocess.check_output(['uncompress', '-f', dest_path + '.Z'])
        return dest_path


class SinexArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix,  **kwargs):
        super().__init__(s3_prefix, step=timedelta(days=1), fill_thread=1, **kwargs)

    def _for_each_time(self, time):
        yield {"time": time,
               'key': F"{time.year}/{sinex_file_name(time)}",
               'restore_file_name': sinex_file_name(time)}

    def _download_file(self, x):
        new_file = SinexDownloader().download(
            dest_folder=self._workdir,
            time=x['time'],
        )
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
