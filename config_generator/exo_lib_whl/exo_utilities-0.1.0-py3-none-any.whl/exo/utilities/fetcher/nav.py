import ftputil
from datetime import timedelta
import os
import subprocess
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver
from exo.utilities import gpstime
from exo.utilities.fetcher.cddis_fetcher import create_cddis_fetcher
from enum import Enum
import gzip


class NavTypes(Enum):
    nav_gps_daily = "nav_gps_daily"
    nav_mgex_daily = "nav_mgex_daily"


def nav_filename(time, nav_file_type):
    gps_time = gpstime.from_utc(time)
    if nav_file_type == NavTypes.nav_gps_daily:
        return F"brdc{int(gps_time.day_in_year):03}0.{time.year-2000:02}n"
    elif nav_file_type == NavTypes.nav_mgex_daily:
        return F"BRDC00IGS_R_{time.year}{int(gps_time.day_in_year):03}0000_01D_MN.rnx"

    else:
        raise Exception(F"Not supported nav_file_type {nav_file_type}")


HEADER_REPLACE = """
     3              N: GNSS NAV DATA    E: GALILEO          RINEX VERSION / TYPE
PICO                EXO                 14-SEP-20 09:30:25  PGM / RUN BY / DATE
                                                            END OF HEADER"""


class NavDownloader:
    def __init__(self):
        self._fetcher = create_cddis_fetcher()

    def download(self, time, dest_folder, nav_file_type):
        gps_time = gpstime.from_utc(time)
        nav_file_name = nav_filename(time=time, nav_file_type=nav_file_type)
        if nav_file_type == NavTypes.nav_gps_daily:
            remote_path = F"archive/gnss/data/daily/{time.year}/{int(gps_time.day_in_year):03}/{time.year-2000:02}n/{nav_file_name}.Z"
            dest_path = os.path.join(dest_folder, nav_file_name)
            self._fetcher.download(remote_path, dest_path + '.Z')
            subprocess.check_output(['uncompress', '-f', dest_path + '.Z'])
        else:
            remote_file_name = F"BRDC00IGS_R_{time.year}{int(gps_time.day_in_year):03}0000_01D_MN.rnx"
            dest_path = os.path.join(dest_folder, nav_file_name)
            remote_path = F"archive/gnss/data/daily/{time.year}/{int(gps_time.day_in_year):03}/{time.year-2000:02}p/{remote_file_name}.gz"
            self._fetcher.download(remote_path, dest_path + '.gz')
            with open(dest_path, 'w') as f:
                data = gzip.open(dest_path + '.gz').read()
                text = data.decode('utf-8')
                f.write(HEADER_REPLACE)
                f.write(text.split("END OF HEADER")[1])
            os.remove(dest_path + '.gz')
        return dest_path


class NavArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix,  **kwargs):
        self._nav_downloader = None 
        super().__init__(s3_prefix, step=timedelta(days=1), fill_thread=20, **kwargs)

    def _for_each_time(self, time):
        gps_time = gpstime.from_utc(time)
        yield {"time": time,
               'key': F"{gps_time.week}/{nav_filename(time,nav_file_type= NavTypes.nav_gps_daily)}",
               'nav_file_type': NavTypes.nav_gps_daily,
               'restore_file_name': nav_filename(time, nav_file_type=NavTypes.nav_gps_daily)}
        yield {"time": time,
               'key': F"{gps_time.week}/{nav_filename(time,nav_file_type= NavTypes.nav_mgex_daily)}",
               'nav_file_type': NavTypes.nav_mgex_daily,
               'restore_file_name': nav_filename(time, nav_file_type=NavTypes.nav_mgex_daily)}

    def _download_file(self, x):
        if not self._nav_downloader:
            self._nav_downloader = NavDownloader()
        new_file = self._nav_downloader.download(
            dest_folder=self._workdir,
            time=x['time'],
            nav_file_type=x['nav_file_type'])
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
