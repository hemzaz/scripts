from exo.utilities import exo_range
import ftputil
import re
import os
from datetime import timedelta, datetime
import subprocess
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver
from exo.utilities import gpstime
from exo.utilities.fetcher.cddis_fetcher import create_cddis_fetcher
from enum import Enum
from functools import partial


class SP3Types(Enum):
    igu_hourly = "igu_hourly"
    igr_daily = "igr_daily"
    igs_daily = "igs_daily"
    wum_hourly = "wum_hourly"
    cod_daily = "cod_daily"
    gfz_daily = "gfz_daily"
    iac_daily = "iac_daily"
    jax_daily = "jax_daily"
    sha_daily = "sha_daily"
    grg_daily = "grg_daily"


def sp3_file_times(time, sp3_type):
    if sp3_type == SP3Types.igu_hourly:
        for hour in [0, 6, 12, 18]:
            yield datetime(year=time.year, month=time.month, day=time.day, hour=hour)
    elif sp3_type in [SP3Types.igr_daily, SP3Types.igs_daily, SP3Types.cod_daily,
                      SP3Types.gfz_daily,
                      SP3Types.iac_daily,
                      SP3Types.jax_daily,
                      SP3Types.sha_daily,
                      SP3Types.grg_daily]:
        yield datetime(year=time.year, month=time.month, day=time.day)
    elif sp3_type == SP3Types.wum_hourly:
        for hour in range(0, 24):
            yield datetime(year=time.year, month=time.month, day=time.day, hour=hour)
    else:
        raise NotImplementedError(F"Unsupported sp3_type: {sp3_type}")


def sp3_filename(time, sp3_type):
    gps_time = gpstime.from_utc(time)
    if sp3_type == SP3Types.igs_daily:
        return F"igs{gps_time.week}{gps_time.day}.sp3"
    elif sp3_type == SP3Types.igr_daily:
        return F"igr{gps_time.week}{gps_time.day}.sp3"
    elif sp3_type == SP3Types.igu_hourly:
        return F"igu{gps_time.week:04}{gps_time.day:01}_{time.hour:02}.sp3"
    elif sp3_type == SP3Types.cod_daily:
        return F"COD0MGXFIN_{time.year:04}{int(gps_time.day_in_year):03}0000_01D_05M_ORB.SP3"
    elif sp3_type == SP3Types.iac_daily:
        return F"IAC0MGXFIN_{time.year:04}{int(gps_time.day_in_year):03}0000_01D_05M_ORB.SP3"
    elif sp3_type == SP3Types.jax_daily:
        return F"JAX0MGXFIN_{time.year:04}{int(gps_time.day_in_year):03}0000_01D_05M_ORB.SP3"
    elif sp3_type == SP3Types.sha_daily:
        return F"SHA0MGXRAP_{time.year:04}{int(gps_time.day_in_year):03}0000_01D_05M_ORB.SP3"
    elif sp3_type == SP3Types.gfz_daily:
        return F"GFZ0MGXRAP_{time.year:04}{int(gps_time.day_in_year):03}0000_01D_05M_ORB.SP3"
    elif sp3_type == SP3Types.grg_daily:
        return F"GRG0MGXFIN_{time.year:04}{int(gps_time.day_in_year):03}0000_01D_15M_ORB.SP3"
    elif sp3_type == SP3Types.wum_hourly:
        return Fr"WUM0MGXULA_{time.year:04}{int(gps_time.day_in_year):03}{time.hour:02}00_01D_05M_ORB.SP3"
    else:
        raise NotImplementedError(F"Not supported sp3_type: {sp3_type}")


def download_cod_iax_jax_sha_grg_sp3(
        start_time,
        end_time,
        dest_folder,
        sp3_type):
    fetcher = create_cddis_fetcher()
    downloaded_files = []
    for day_date_time in exo_range(
        start_time,
        end_time +
        timedelta(
            days=1),
        timedelta(
            days=1)):
        for date_time in sp3_file_times(
                time=day_date_time,
                sp3_type=SP3Types.cod_daily):
            if date_time >= start_time and date_time < end_time:
                gps_time = gpstime.from_utc(date_time)
                file_name = sp3_filename(
                    time=date_time, sp3_type=sp3_type)
                dest = os.path.join(dest_folder, file_name + '.gz')
                fetcher.download(
                    F"archive/gps/products/mgex/{gps_time.week}/{file_name}.gz", dest)
                subprocess.check_call(['gunzip', '-f', dest])
                if dest.endswith(".gz"):
                    dest = dest[:-len('.gz')]
                downloaded_files.append(dest)
    return downloaded_files


def download_wum_sp3(start_time, end_time, dest_folder, override=False):
    start_day_time = start_time - \
        timedelta(hours=start_time.hour, minutes=start_time.minute,
                  seconds=start_time.second)
    downloaded_files = []
    for day_date_time in exo_range(
        start_day_time,
        end_time +
        timedelta(
            days=1),
        timedelta(
            days=1)):
        gps_struct = gpstime.from_utc(day_date_time)
        file_regex = Fr"WUM0MGXULA_{day_date_time.year:04}{int(gps_struct.day_in_year):03}(\d\d)(\d\d)_01D_05M_ORB.SP3"
        with ftputil.FTPHost('igs.ign.fr', 'anonymous', '') as host:
            ftp_folder = F"pub/igs/products/mgex/{gps_struct.week}"
            files = [
                (file,
                 re.findall(
                     file_regex,
                     file)[0]) for file in host.listdir(ftp_folder) if re.findall(
                    file_regex,
                    file)]
            files = [
                (file,
                 day_date_time +
                 timedelta(
                     hours=int(file_hour),
                     minutes=int(file_minute))) for (
                    file,
                    (file_hour,
                     file_minute)) in files]
            files = list(
                filter(
                    lambda file: file[1] >= start_time and file[1] < end_time,
                    files))
            files.sort(key=lambda x: x[1], reverse=True)
            for file in files:
                file_name = file[0]
                dest = os.path.join(dest_folder, file_name)
                print(
                    F"Downloading file {dest},from: {ftp_folder}/{file_name}")
                host.download(F"{ftp_folder}/{file_name}", dest)
                subprocess.check_call(['gunzip', '-f', dest])
                if dest.endswith(".gz"):
                    dest = dest[:-len('.gz')]

                downloaded_files.append(dest)
    print(downloaded_files)
    return downloaded_files


IGS_SP3_TYPES = [SP3Types.igu_hourly, SP3Types.igs_daily, SP3Types.igr_daily]


class IgsSP3Downloader:
    def __init__(self):
        self._fetcher = create_cddis_fetcher()

    def download(self, start_time, end_time, dest_folder, sp3_type):
        dest_paths = []
        for time in exo_range(start_time,
                              end_time + timedelta(days=1), timedelta(days=1)):
            gps_time = gpstime.from_utc(time)
            for sp3_file_time in sp3_file_times(time, sp3_type):
                if (sp3_file_time >= start_time and sp3_file_time < end_time):
                    sp3_file_name = sp3_filename(
                        time=sp3_file_time, sp3_type=sp3_type)
                    remote_path = F"archive/gnss/products/{gps_time.week}/{sp3_file_name}.Z"
                    dest_path = os.path.join(dest_folder, sp3_file_name)
                    self._fetcher.download(remote_path, dest_path + '.Z')
                    subprocess.check_output(
                        ['uncompress', '-f', dest_path + '.Z'])
                    dest_paths.append(dest_path)
        return dest_paths


class SP3Downloader:
    def __init__(self, **kwargs):
        self._kwargs = kwargs

    def download(self, sp3_type, start_time, end_time, dest_folder):
        if sp3_type in IGS_SP3_TYPES:
            return IgsSP3Downloader(
                **self._kwargs).download(
                sp3_type=sp3_type,
                start_time=start_time,
                end_time=end_time,
                dest_folder=dest_folder)
        elif sp3_type == SP3Types.wum_hourly:
            return download_wum_sp3(
                start_time=start_time,
                end_time=end_time,
                dest_folder=dest_folder)
        elif sp3_type in [SP3Types.cod_daily,
                          SP3Types.gfz_daily,
                          SP3Types.iac_daily,
                          SP3Types.jax_daily,
                          SP3Types.sha_daily,
                          SP3Types.grg_daily,
                          ]:
            return download_cod_iax_jax_sha_grg_sp3(
                start_time=start_time,
                end_time=end_time,
                dest_folder=dest_folder,
                sp3_type=sp3_type)
        else:
            raise Exception(F"SP3 type: {sp3_type} is not supported")


class SP3Archiver(TimeBasedFileArchiver):
    def __init__(self, sp3_type, s3_prefix, **kwargs):
        self._sp3_type = sp3_type
        super().__init__(s3_prefix, step=timedelta(days=1), **kwargs)

    def _for_each_time(self, time):
        for file_time in sp3_file_times(time=time, sp3_type=self._sp3_type):
            filename = sp3_filename(time=file_time, sp3_type=self._sp3_type)
            gps_time = gpstime.from_utc(file_time)
            yield {
                "time": file_time,
                "folder": str(gps_time.week),
                'key': F"{gps_time.week}/{filename}",
                'restore_file_name': filename,
            }

    def _download_file(self, x):
        new_file = SP3Downloader().download(
            sp3_type=self._sp3_type,
            dest_folder=self._workdir,
            start_time=x['time'],
            end_time=x['time'] +
            timedelta(
                seconds=1))
        assert len(
            new_file) == 1, F"only one file should have downloaded {new_file}"
        new_file_path = os.path.join(self._workdir, new_file[0])
        return new_file_path


Sp3IguHourlyArchiver = partial(SP3Archiver, sp3_type=SP3Types.igu_hourly)
Sp3IgsDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.igs_daily)
Sp3IgrDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.igr_daily)
Sp3WUMHourlyArchiver = partial(SP3Archiver, sp3_type=SP3Types.wum_hourly)
Sp3CodDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.cod_daily)
Sp3GfzDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.gfz_daily)
Sp3IacDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.iac_daily)
Sp3JaxDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.jax_daily)
Sp3ShaDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.sha_daily)
Sp3GrgDailyArchiver = partial(SP3Archiver, sp3_type=SP3Types.grg_daily)
