import ftputil
from datetime import timedelta
import os
import subprocess
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver


def dcb_filename(time, suffix):
    return F"P1C1{time.year-2000:02}{time.month:02}.{suffix}"


class DcbDownloader:
    def download(self, time, dest_folder, suffix):
        with ftputil.FTPHost("ftp.aiub.unibe.ch", 'anonymous', '') as host:
            ftp_path = F'CODE/{time.year}/{dcb_filename(time,suffix)}.Z'
            dest_path = os.path.join(dest_folder, dcb_filename(time, suffix))
            host.download(ftp_path, dest_path + '.Z')
            subprocess.check_output(['uncompress', '-f', dest_path + '.Z'])
            return dest_path


class DcbArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix, **kwargs):
        super().__init__(s3_prefix, step=timedelta(days=14), **kwargs)

    def _for_each_time(self, time):
        suffix = "DCB"
        yield {"time": time,
               'key': F"{time.year}/{dcb_filename(time,suffix= suffix)}",
               "suffix": suffix,
               'restore_file_name': dcb_filename(time, suffix=suffix)}

    def _download_file(self, x):
        new_file = DcbDownloader().download(
            dest_folder=self._workdir,
            time=x['time'],
            suffix=x['suffix'])
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
