import subprocess
import boto3
from .fetcher import Fetcher
import re
from datetime import datetime
from itertools import chain
from retrying import retry
import json
import os
from datetime import datetime, timezone, timedelta
import logging
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor
from ..range_s3_search import range_s3_search
from .. import s3


class S3ArchiveFetcher(Fetcher):
    def __init__(self, start_date, end_date, dest_dir, base_path):
        self._client = boto3.client('s3')
        self._base_path = base_path
        super(S3ArchiveFetcher, self).__init__(start_date, end_date, dest_dir)

    def download_upload_data_json(self, path):
        return json.loads(s3.get_object(path))

    def download_file(self, file_data, file):
        dest_file = os.path.join(self._dest_dir, file)
        print(F"downloading: {file_data['s3_path']} to {dest_file}", )
        s3.download_file(file_data['s3_path'], os.path.join(dest_file))
        print(F"done downloading: {file_data['s3_path']}", dest_file)

    def __call__(self):
        runs = range_s3_search(
            self._base_path,
            self._start_date,
            self._end_date)
        runs.sort(key=lambda x: x['time'])
        metas = []
        with ThreadPoolExecutor(max_workers=10) as e:
            for run in runs:
                run_time = run['time']
                run_path = run['path']
                metas.append(
                    dict(
                        run_path=run_path,
                        future=e.submit(
                            self.download_upload_data_json,
                            run_path +
                            '/upload-data.json')))
        metas = list(
            filter(lambda meta: meta['future'].exception() is None, metas))
        metas.sort(key=lambda x: x['future'].result()['time'])
        files = {}
        for meta in metas:
            run_path = meta['run_path']
            data = meta['future'].result()
            for file, file_meta_data in data['files'].items():
                files[file] = dict(
                    s3_path=F"{run_path}/{file}",
                    update_time=data['time'],
                    md5=file_meta_data['md5'])

        os.makedirs(self._dest_dir, exist_ok=True)
        with ThreadPoolExecutor(max_workers=10) as e:
            for file, file_data in files.items():
                e.submit(self.download_file, file_data, file)
        return files
