
import ftputil
from datetime import timedelta
import os
import subprocess
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver
from exo.utilities import gpstime
import requests
from enum import Enum


class IRI_DATA_TYPES(Enum):
    apf_107 = "apf_107"
    ig_rz = "ig_rz"


def iri_data_filenme(time, iri_data_type):
    if iri_data_type == iri_data_type.apf_107:
        return F"{time.year - 2000:02}{time.month:02}{time.day:02}_apf107.dat"
    if iri_data_type == iri_data_type.ig_rz:
        return F"{time.year - 2000:02}{time.month:02}{time.day:02}_ig_rz.dat"
    else:
        raise Exception(F"Not supported iri_data_types : {iri_data_type}")


class chain_project_fetcher:
  def download(self,file_name,dest_path):
    returns = requests.get(F"https://chain-new.chain-project.net/echaim_downloads/" + file_name,timeout=60)
    returns.raise_for_status()
    with open(dest_path,'wb') as f:
      f.write(returns.content)


class IriDataDownloader:
    def __init__(self):
        self._fetcher = chain_project_fetcher()

    def download(self, time, dest_folder, iri_data_type):
        gps_time = gpstime.from_utc(time)
        iri_file_name = iri_data_filenme(time=time, iri_data_type=iri_data_type)
        remote_path = F"{iri_file_name}.gz"
        dest_path = os.path.join(dest_folder, iri_file_name)
        print(remote_path)
        self._fetcher.download(file_name=remote_path, dest_path= dest_path + '.gz')
        subprocess.check_output(['gunzip',  dest_path + '.gz'])
        return dest_path


class IriDataArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix,iri_data_type ,**kwargs):
        self._iri_data_type = iri_data_type
        super().__init__(s3_prefix, step=timedelta(days=1), fill_thread=1, **kwargs)

    def _for_each_time(self, time):
        yield {"time": time,
               'key': F"{time.year}/{iri_data_filenme(time, iri_data_type=self._iri_data_type)}",
               'iri_data_type': self._iri_data_type,
               'restore_file_name': iri_data_filenme(time, iri_data_type=self._iri_data_type)}

    def _download_file(self, x):
        new_file = IriDataDownloader().download(
            dest_folder=self._workdir,
            time=x['time'],
            iri_data_type=x['iri_data_type'])
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
