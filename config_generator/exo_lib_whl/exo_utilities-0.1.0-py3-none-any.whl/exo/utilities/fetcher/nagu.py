import logging
import requests
from lxml import html
import os
from datetime import datetime, timedelta
import click
from concurrent.futures import ThreadPoolExecutor
import re


class NAGUFetcher:
    def __init__(self, output_folder):
        self._request_args = {
            'headers': {
                'User-agent': 'Mozilla/5.0'},
            'verify': False
        }
        self._executor = ThreadPoolExecutor(max_workers=40)
        self._output_folder = output_folder

    def _save_nagu_file(self, content, num):
        content = content.decode('utf-8')
        message_type = re.findall(r'NAGU TYPE:\s(.*)\r?\n', content)[0]
        message_type_extra = re.search(r'\(.*\)', message_type)
        if message_type_extra:
            message_type = message_type.replace(message_type_extra.group(), "")
        message_type = message_type.strip()
        output = F'{message_type}_{num}.txt'
        if self._output_folder:
            output = os.path.join(self._output_folder, output)
        logging.info(F'Saving: {output}')
        with open(output, 'w') as f:
            f.write(content)

    def download_active(self):
        response = requests.get(
            'https://www.gsc-europa.eu/system-status/user-notifications',
            **self._request_args
        )
        response.raise_for_status()
        data = html.fromstring(response.content)
        lines = data.xpath(
            '//*[@id="block-system-main"]/div/div[3]/div/table/tbody')[0]
        items = []
        for line in lines.getchildren():
            href = 'https://www.gsc-europa.eu' + \
                line.xpath("td[1]/a")[0].attrib['href']
            num = line.xpath("td[1]/a")[0].text
            items.append({
                'num': num,
                'follow_link': href,
            })
        for i in items:
            self._download(
                num=i['num'],
                follow_link=i['follow_link'])

    def _download(self, follow_link, num):
        response = requests.get(
            follow_link,
            **self._request_args)
        response.raise_for_status()
        follow_page = html.fromstring(response.content)
        download_link = [x for x in follow_page.xpath('//a') if 'href' in x.attrib and
                         str(num) in x.attrib['href'] and
                         (
            x.attrib['href'].startswith('https://www.gsc-europa.eu/sites/default/files/') or
            x.attrib['href'].startswith('http://www.gsc-europa.eu/sites/default/files/') or
            x.attrib['href'].startswith('http://gsc-europa.eu/sites/default/files/') or
            x.attrib['href'].startswith('http://www.gsa.europa.eu/sites/default/files') or
            x.attrib['href'].startswith('/sites/default/files')

        ) and
            (
            x.attrib['href'].endswith('txt') or
            x.attrib['href'].endswith('TXT')
        )][0].attrib['href']
        if download_link.startswith('/sites/default/files'):
            download_link = 'https://www.gsc-europa.eu/' + download_link
        response = requests.get(
            download_link,
            **self._request_args)
        response.raise_for_status()

        self._save_nagu_file(num=num, content=response.content)

    def download_archive(
            self,
            filter_publish_time_start_date=None,
            filter_publish_time_end_date=None):

        response = requests.get(
            'https://www.gsc-europa.eu/system-status/user-notifications-archive',
            **self._request_args)
        response.raise_for_status()
        data = html.fromstring(response.content)
        # snippet of the expected html for each table line
        #
        # <tr class="odd views-row-first">
        #          <td class="views-field views-field-view-node">
        #    <a href="/notice-advisory-to-galileo-users-nagu-2020014">2020014</a>          </td>
        #          <td class="views-field views-field-field-satellite-name">
        #    GSAT0103          </td>
        #          <td class="views-field views-field-field-date-of-start-event-utc-">
        #    <span class="date-display-single">2020-06-12 22:00</span>          </td>
        #          <td class="views-field views-field-field-nagu-date-of-publication-u">
        #    <span class="date-display-single">2020-06-13 12:55</span>          </td>
        #          <td class="views-field views-field-field-nagu-type">
        #    USABLE          </td>
        #          <td class="views-field views-field-field-nagu-subject">
        #    USABLE AS FROM 2020-06-12          </td>
        # </tr>
        table_lines = data.xpath(
            '//*[@id="block-system-main"]/div/div[3]/div/table/tbody')[0]

        items = []
        for line in table_lines.getchildren():
            href = line.xpath("td[1]/a")[0].attrib['href']
            publish_date = datetime.strptime(
                line.xpath('td[3]/span')[0].text, '%Y-%m-%d %H:%M')
            num = line.xpath("td[1]/a")[0].text
            follow_link = F"https://www.gsc-europa.eu/{href}"
            items.append({
                'num': num,
                'follow_link': follow_link,
                'publish_date': publish_date,
            })

        if filter_publish_time_start_date:
            items = [x for x in items if x['publish_date']
                     >= filter_publish_time_start_date]

        if filter_publish_time_end_date:
            items = [x for x in items if x['publish_date']
                     <= filter_publish_time_end_date]
        self._executor.map(
            lambda i: self._download(
                num=i['num'],
                follow_link=i['follow_link']),
            items)
