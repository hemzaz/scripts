import ftputil
from datetime import timedelta
import os
import subprocess
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver
from exo.utilities import gpstime
from exo.utilities.fetcher.cddis_fetcher import create_cddis_fetcher
from unlzw import unlzw
from enum import Enum

class IonexTypes(Enum):
    igr = "igr"
    c1p = "c1p"


def ionex_filename(time,file_type):
    gps_time = gpstime.from_utc(time)
    return F"{file_type.name}g{int(gps_time.day_in_year):03}0.{time.year-2000:02}i"



class IonexDownloader:
    def __init__(self,file_type):
        self._file_type = file_type
        self._downloader = create_cddis_fetcher()

    def download(self, time, dest_folder):
        gps_time = gpstime.from_utc(time)
        file_source_path = F'archive/gnss/products/ionex/{time.year:04}/{int(gps_time.day_in_year):03}/{ionex_filename(time,file_type=self._file_type)}.Z'
        dest_path = os.path.join(dest_folder, ionex_filename(time,file_type=self._file_type))
        dest_path_temp = dest_path+'.Z'
        self._downloader.download(file_source_path, dest_path_temp)
        with open(dest_path,'wb') as fout:
            fout.write(unlzw(open(dest_path_temp,'rb').read()))
        os.remove(dest_path_temp)
        return dest_path


class IonexArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix,ionex_type, **kwargs):
        self._ionex_type = ionex_type
        super().__init__(s3_prefix, step=timedelta(days=1), **kwargs)

    def _for_each_time(self, time):
        yield {"time": time,
               'key': F"{time.year:04}/{ionex_filename(time,file_type=self._ionex_type)}",
               'restore_file_name': ionex_filename(time,file_type=self._ionex_type)}

    def _download_file(self, x):
        new_file = IonexDownloader(file_type=self._ionex_type).download(
            dest_folder=self._workdir, time=x['time'])
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
