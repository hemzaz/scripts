import tempfile
from exo.utilities.s3_file_archiver import S3FileArchiver, FileNotFoundInArchive
from exo.utilities import exo_range
from multiprocessing import Pool
from datetime import datetime, timedelta
from exo.utilities import gpstime
import os
from functools import partial
import json

parallel = True if os.environ.get("PARALLEL", 'false').lower() in [
    'true', 'y', 'yes', '1', 't'] else False


class TimeBasedFileArchiver():
    def __init__(self, s3_prefix, step, *args, **kwargs):
        self._s3_prefix = s3_prefix
        self._step = step
        self._fill_thread = kwargs.get('fill_thread', 20)
        self._ignore_missing_when_fail = kwargs.get(
            'ignore_missing_when_fail', True)
        self._workdir = tempfile.mkdtemp('data')
        self._archiver = S3FileArchiver(
            s3_files_path=self._s3_prefix, source_directory=self._workdir)

    def _for_each_time(self, time):
        pass

    def _filter_duplication(self, data):
        result = dict()
        for x in data:
            result[x['key']] = x
        return list(result.values())

    def fill(self, start_time, delta):
        time = min(start_time, start_time + delta)
        end_time = max(start_time, start_time + delta)

        filled_files = []
        for day_iteration_time in exo_range(
            time -
            timedelta(
                hours=time.hour,
                minutes=time.minute,
                seconds=time.second,
                microseconds=time.microsecond),
                end_time,
                timedelta(
                days=1)):
            for for_each_time in self._for_each_time(day_iteration_time):
                if for_each_time['time'] >= time and for_each_time['time'] < end_time:
                    filled_files.append(for_each_time)
        filled_files = self._filter_duplication(filled_files)
        filled_files = self._filter_already_downloaded(filled_files)
        with Pool(self._fill_thread) as p:
            if parallel:
                p.map(self._upload, filled_files)
            else:
                for file in filled_files:
                    self._upload(file)

    def _filter_already_downloaded(self, from_list):
        returns_list = []
        for for_each_time in from_list:
            if not self._archiver.file_exists(for_each_time['key']):
                returns_list.append(for_each_time)
            else:
                print(F"already exist in archive: {for_each_time['key']}")
        return returns_list

    def restore(self, start_time, delta, dest_folder):
        os.makedirs(dest_folder, exist_ok=True)
        time = min(start_time, start_time + delta)
        end_time = max(start_time, start_time + delta)
        download_files = []
        for time in exo_range(time, end_time, timedelta(days=1)):
            for for_each_time in self._for_each_time(time):
                download_files.append(for_each_time)

        download_files = self._filter_duplication(download_files)
        if parallel:
            with Pool(40) as p:
                x = p.map(
                    partial(
                        self._download,
                        dest_folder=dest_folder),
                    download_files)
        else:
            x = [self._download(x, dest_folder=dest_folder)
                 for x in download_files]
            metadata_info = {"files": x}
            with open(os.path.join(dest_folder, 'metadata.json'), 'w') as f:
                f.write(json.dumps(metadata_info))
            return metadata_info

    def _download(self, download_file, dest_folder):
        time = download_file['time']
        key = download_file['key']

        restore_file_name = download_file['restore_file_name']
        try:
            if os.path.exists(os.path.join(dest_folder, restore_file_name)):
                return {
                    'file_allready_exits': True,
                    'file_name': restore_file_name,
                }
            else:

                x = self._archiver.get_file(key=key)
                with open(os.path.join(dest_folder, restore_file_name), 'wb') as f:
                    f.write(x['data'])
                return {
                    's3_path': x['s3_path'],
                    'file_name': restore_file_name,
                    'metadata': x['metadata']}
        except FileNotFoundInArchive as ex:
            print(ex)
            return dict(error=F"failed to find object {self._s3_prefix}/{key}")

    def _upload(self, x):
        time = x['time']
        try:
            print(x)
            new_file_path = self._download_file(x)
            self._archiver.upload_file(key=x['key'], file_path=new_file_path)
        except BaseException as ex:
            if self._ignore_missing_when_fail:
                print(F"file {x} wasen't found, {ex}")
            else:
                raise
