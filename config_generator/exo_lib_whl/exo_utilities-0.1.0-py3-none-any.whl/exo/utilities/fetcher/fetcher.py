

class Fetcher(object):
    def __init__(self, start_date, end_date, dest_dir):
        self._start_date = start_date
        self._end_date = end_date
        self._dest_dir = dest_dir
