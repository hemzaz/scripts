import os
import re
from datetime import timedelta
import ftputil
import requests
from more_itertools import last
from lxml import etree
from exo.utilities import gpstime
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver


class IGSHttpdownloader():
    def __init__(self):
        self._hostname = "https://files.igs.org/"

    def _http_get(self, path):
        url = self._hostname + path
        response = requests.get(url)
        response.raise_for_status()
        return response

    def download(self, path, dest_path):
        response = self._http_get(path)
        with open(dest_path, 'wb') as f:
            f.write(response.content)

    def list_files(self, path):
        response = self._http_get(path)
        htmlparser = etree.HTMLParser()
        tree = etree.fromstring(response.text, htmlparser)
        files = [html_node.text for html_node in tree.xpath(
            '/html/body/pre/a[@href]')]
        return files


def antex_filename(time):
    gps_time = gpstime.from_utc(time)
    return F"igs14_{gps_time.week}.atx"


class AntexDownloader:
    def __init__(self):
        self._host = IGSHttpdownloader()

    def download_latest(self, dest_folder):
        path = 'pub/station/general/pcv_archive/'
        files = self._host.list_files(path)
        antex_files = sorted(
            [file for file in files if re.search(r'igs14_\d{4}.atx', file)])
        file_to_downlaod = last(antex_files)
        print(F'downloading {file_to_downlaod}')
        self._host.download(
            path=path + file_to_downlaod,
            dest_path=os.path.join(
                dest_folder,
                file_to_downlaod))

    def download(self, time, dest_folder):
        ftp_path = F'pub/station/general/pcv_archive/{antex_filename(time)}'
        dest_path = os.path.join(dest_folder, antex_filename(time))
        self._host.download(ftp_path, dest_path)
        return dest_path


class AntexArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix, **kwargs):
        super().__init__(s3_prefix, step=timedelta(days=7), **kwargs)

    def _for_each_time(self, time):
        yield {"time": time,
               'key': antex_filename(time),
               'restore_file_name': antex_filename(time)}

    def _download_file(self, x):
        new_file = AntexDownloader().download(
            dest_folder=self._workdir, time=x['time'])
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
