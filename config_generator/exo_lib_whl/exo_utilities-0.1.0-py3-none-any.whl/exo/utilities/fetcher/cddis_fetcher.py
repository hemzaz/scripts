import tempfile
import subprocess
import retrying
import os
from abc import ABC, abstractmethod
from collections import namedtuple
from pathlib import Path
import yaml

CddisAuthInfo = namedtuple('CddisAuthInfo', ['username', 'password'])


class cddis_auth_source(ABC):
    @abstractmethod
    def active(self):
        pass

    @abstractmethod
    def get_user_and_password(self):
        pass


class cddis_env_source(cddis_auth_source):
    def active(self):
        return "CDDIS_USER" in os.environ and "CDDIS_PASSWORD" in os.environ

    def get_user_and_password(self):
        return CddisAuthInfo(
            username=os.environ['CDDIS_USER'],
            password=os.environ['CDDIS_PASSWORD'])


class cddis_file_source(cddis_auth_source):
    def _config_file_path(self):
        return os.path.join(str(Path.home()), '.cddis_auth.yaml')

    def active(self):
        return os.path.exists(self._config_file_path())

    def get_user_and_password(self):
        data = yaml.safe_load(open(self._config_file_path()))
        return CddisAuthInfo(
            username=data['username'],
            password=data['password'])


AuthSources = [cddis_env_source(), cddis_file_source()]


def create_cddis_fetcher():
    for auth_source in AuthSources:
        if auth_source.active():
            auth_info = auth_source.get_user_and_password()
            return CddisFetcher(
                username=auth_info.username,
                password=auth_info.password)
    raise Exception("Three is not available cddis auth information,")


class CddisFetcher():
    def __init__(self, username, password):
        self._cookie_file = tempfile.mktemp()
        self._netrc_file = tempfile.mktemp()
        with open(self._netrc_file, 'w') as f:
            f.write(
                F"machine urs.earthdata.nasa.gov login {username} password {password}")
        pass

    @retrying.retry(stop_max_attempt_number=3)
    def list(self, path):
        temp = tempfile.mktemp()
        path = F"https://cddis.nasa.gov/{path}/"
        command = [
            "curl",
            "--netrc-file",
            self._netrc_file,
            "-c",
            self._cookie_file,
            "-n",
            '-o', temp,
            '--ciphers', 'DEFAULT@SECLEVEL=1',
            "-L",
            F"{path}*?list"]
        subprocess.check_call(command)
        output = open(temp, 'rb').read()
        output = [x.split()[0] for x in output.decode(
            'utf-8').split("\n") if x and x[0] != "#"]
        return output

    def download(self, path, dest):
        data = self.get_file(path)
        with open(dest, 'wb') as f:
            f.write(data)

    # @retrying.retry(stop_max_attempt_number=3)
    def get_file(self, path):
        original_path = path
        path = F"https://cddis.nasa.gov/{path}"
        print(path)
        file_name = original_path.split('/')[-1]
        all_files = self.list('/'.join(original_path.split('/')[:-1]))
        if file_name not in all_files:
            raise Exception(F"{path} wasn't  found in cddis")
        temp = tempfile.mktemp()
        command = [
            "curl",
            "--netrc-file",
            self._netrc_file,
            "-c",
            self._cookie_file,
            '--ciphers', 'DEFAULT@SECLEVEL=1',
            "-n",
            "-L",
            path,
            "--output",
            temp]
        subprocess.check_output(command)
        output = open(temp, 'rb').read()
        return output
