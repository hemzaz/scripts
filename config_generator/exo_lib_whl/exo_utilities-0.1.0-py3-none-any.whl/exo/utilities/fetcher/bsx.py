import ftputil
from datetime import timedelta
import os
import gzip
import subprocess
from exo.utilities import gpstime
from exo.utilities.fetcher.cddis_fetcher import create_cddis_fetcher
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver


def bsx_filename(time):
    gps_time = gpstime.from_utc(time)
    return F"CAS0MGXRAP_{time.year}{int(gps_time.day_in_year):03}0000_01D_01D_DCB.BSX"

class BsxDownloader:
    def __init__(self):
        self._downloader = create_cddis_fetcher()
    def download(self, time, dest_folder):
        ftp_path = F'archive/gnss/products/bias/{time.year}/{bsx_filename(time)}.gz'
        dest_path = os.path.join(dest_folder, bsx_filename(time))
        self._downloader.download(ftp_path, dest_path + '.gz')
        
        with open(dest_path, 'wb') as f:
            data = gzip.open(dest_path + '.gz').read()
            f.write(data)
        os.remove(dest_path + '.gz')
        return dest_path


class BsxArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix, **kwargs):
        super().__init__(s3_prefix, step=timedelta(days=1), **kwargs)

    def _for_each_time(self, time):
        yield {"time": time,
               'key': F"{time.year}/{bsx_filename(time)}",
               'restore_file_name': bsx_filename(time)}

    def _download_file(self, x):
        new_file = BsxDownloader().download(
            dest_folder=self._workdir,
            time=x['time'],
            )
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
