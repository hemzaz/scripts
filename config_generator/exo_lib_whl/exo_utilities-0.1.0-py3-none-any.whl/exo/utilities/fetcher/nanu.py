import os
import requests
from lxml import html
import re
import logging


class NanuDownloader:
    def download(self, start_date, end_date, output_folder):
        params = (
            ('pageName', 'selectNanuByNumber'),
        )
        data = {
            'startDate': (start_date).strftime('%m/%d/%Y'),
            'endDate': (end_date).strftime('%m/%d/%Y'),
            'nanu': '0',
            'genNanu': '0',
            'btnGetNanus': '1'

        }
        response = requests.post(
            'https://www.navcen.uscg.gov/',
            params=params,
            data=data)
        response.raise_for_status()
        data = html.fromstring(response.text)
        nanus = [x.text for x in data.xpath('//*[@id="lblNanu"]/pre')]
        for nanu in nanus:
            self.save_nanu(nanu, output_folder=output_folder)

    def current_nanus(self, output_folder):
        x = requests.get(
            'https://www.navcen.uscg.gov/?pageName=currentNanus&format=txt')
        x.raise_for_status()
        res = re.split(r"\d{7}-+\r\n", x.content.decode('utf-8'))
        for nanu in res:
            if nanu:
                self.save_nanu(nanu, output_folder)

    def nanu_desc(self, nanu):
        full_number = re.findall(r'NANU NUMBER: (\d*)', nanu)[0]
        year = int(full_number[:4])
        num = int(full_number[4:])
        nanu_type = re.findall(r'NANU TYPE: (\S*)', nanu)[0]
        return dict(
            year=year,
            full_number=full_number,
            num=num,
            nanu_type=nanu_type)

    def save_nanu(self, nanu, output_folder):
        try:
            desc = self.nanu_desc(nanu)
            print(desc)
            with open(
                os.path.join(output_folder,
                             F"{desc['nanu_type']}_{desc['full_number']}.txt"), 'w') as file_to_write:
                file_to_write.write(nanu)
        except BaseException:
            logging.exception(F'error parsing nanu: {nanu}')
