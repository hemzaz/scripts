from exo.ssr.runs_utils import list_runs, \
    download_results, \
    download_products, \
    download_nav, \
    list_ts_runs, get_run_summary, download_corrections
from datetime import datetime
import logging
import os
import json
import shutil


class LatestOdFetcher:
    def __init__(self, s3_prefix, output_dir, start_date=None, end_date=None):
        self._output_dir = output_dir
        self._s3_prefix = s3_prefix
        self._start_date = start_date
        self._end_date = end_date

    def __call__(self):
        runs = list_runs(prefix=self._s3_prefix,
                         min_date=self._start_date,
                         max_date=self._end_date,
                         filter_summary_not_exists=True)
        run = runs[-1]
        run = run['path']
        logging.info(F"found od in path {run}")
        logging.info('downloading results')
        download_results(run, self._output_dir)
        logging.info('downloading products')
        download_products(run, self._output_dir)
        logging.info('downloading nav')
        download_nav(run, self._output_dir)
        metadata = {"od_source": run}
        with open(
                os.path.join(self._output_dir, "metadata.jsontmp"), 'w') as file_meta_data:
            json.dump(metadata, file_meta_data)
        shutil.move(os.path.join(self._output_dir, "metadata.jsontmp"),
                    os.path.join(self._output_dir, "metadata.json"))


class LatestTsFetcher:
    def __init__(self, s3_prefix, output_dir, start_date=None, end_date=None):
        self._output_dir = output_dir
        self._s3_prefix = s3_prefix
        self._start_date = start_date
        self._end_date = end_date

    def __call__(self):
        runs = list_ts_runs(prefix=self._s3_prefix,
                            min_date=self._start_date,
                            max_date=self._end_date,
                            filter_summary_not_exists=True)
        run = runs[-1]
        run = run['path']
        logging.info(F"found ts in path {run}")
        ts_summary = get_run_summary(run)
        od_run = ts_summary['od_metadata']['od_source']
        logging.info('download_corrections')
        download_corrections(run, self._output_dir)
        logging.info('download_results')
        download_results(run, self._output_dir)
        logging.info('download_products')
        download_products(od_run, self._output_dir)
        logging.info('download_nav')
        download_nav(od_run, self._output_dir)
        metadata = {"ts_source": run}
        with open(
                os.path.join(self._output_dir, "metadata.jsontmp"), 'w') as file_meta_data:
            json.dump(metadata, file_meta_data)
        shutil.move(os.path.join(self._output_dir, "metadata.jsontmp"),
                    os.path.join(self._output_dir, "metadata.json"))
