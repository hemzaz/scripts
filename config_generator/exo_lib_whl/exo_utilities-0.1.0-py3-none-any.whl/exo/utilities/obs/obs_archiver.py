import os
from exo.utilities.obs.rinex_file_name import rinex_file_name
from exo.utilities.obs.downloader import download
from exo.utilities import gpstime
from datetime import timedelta
from exo.utilities.fetcher.time_based_file_archiver import TimeBasedFileArchiver


class ObsArchiver(TimeBasedFileArchiver):
    def __init__(self, s3_prefix, receivers):
        super().__init__(s3_prefix, step=timedelta(days=1))
        self._receivers = receivers

    def _for_each_time(self, time):
        for receiver in self._receivers:
            gps_time = gpstime.from_utc(time)
            file_name = rinex_file_name(rcv=receiver, time=time)
            key = F"{gps_time.week}/{file_name}"
            yield {"time": time, "receiver": receiver, 'key': key, 'restore_file_name': file_name}

    def _download_file(self, x):
        new_file = download(
            dest_folder=self._workdir,
            reciver=x['receiver'],
            time=x['time'])
        new_file_path = os.path.join(self._workdir, new_file)
        return new_file_path
