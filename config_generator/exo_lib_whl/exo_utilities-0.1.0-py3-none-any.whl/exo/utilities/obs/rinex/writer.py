import collections
import os
from more_itertools import first, ichunked
from exo.utilities import gpstime
from datetime import datetime

SIGNAL_ORDER = ["C1", "P1", "L1", "S1", "D1", "C2", "P2", "L2", "S2",
                "D2", "C5", "L5", "S5", "D5", "C6", "L6", "S6", "D6",
                "C7", "L7", "S7", "D7", "C8", "L8", "S8", "D8"]


class RinexFileWriter:
    def __init__(self, output_folder, station, station_metadata_info, obs):
        self._output_folder = output_folder
        self._station = station
        self._station_metadata_info = station_metadata_info
        self._obs = collections.OrderedDict(obs)
        self._obs_file = None
        self._signals = None

    def _write_obs(self):
        for obs_time, obs_data in self._obs.items():
            sats = sorted(obs_data['data'].keys())
            # workaround formating 10.7f doesn't work well
            seconds = F"{(obs_time.second + obs_time.microsecond *1e6):11.7f}"[
                1:]
            sat_header = F" {obs_time.year-2000} {obs_time.month:2} {obs_time.day:02} {obs_time.hour:02} {obs_time.minute:02} {seconds}  0 {len(sats):2}"
            if len(sats) == 0:
                sat_header = sat_header + "\n"
            for i, sats_in_chunk in enumerate(ichunked(sats, 12)):
                if i == 0:
                    sat_header = sat_header + "".join(sats_in_chunk) + "\n"
                else:
                    sat_header = sat_header + " " * 32 + \
                        "".join(sats_in_chunk) + "\n"
            self._obs_file.write(sat_header)
            for sat in sats:
                sat_data = obs_data['data'][sat]
                signals = []
                for signal in self._get_signals():
                    if signal in sat_data:
                        signals.append(sat_data[signal])
                    else:
                        signals.append(None)
                for chunked_signals in ichunked(signals, 5):
                    chunked_signals = list(chunked_signals)
                    text = ""
                    first_signal = chunked_signals[0]
                    if first_signal is None:
                        text = text + " " * 14
                    else:
                        text = text + F" {first_signal:13.3f}"
                    text = text + \
                        "".join([F"{x:16.3f}" if x is not None else " " * 16 for x in chunked_signals[1:]])
                    self._obs_file.write(F"{text}  \n")

    def __call__(self):
        os.makedirs(self._output_folder, exist_ok=True)
        first_obs_time = first(self._obs.keys())
        day_in_year = int(gpstime.from_utc(first_obs_time).day_in_year)
        with open(
            os.path.join(
                self._output_folder,
                F"{self._station}{day_in_year:03}0.{first_obs_time.year - 2000}o"), 'w') as obs_file:
            self._obs_file = obs_file
            self._obs_file.write(self._get_obs_file_header())
            self._write_obs()

    def _get_signals(self):
        if self._signals is None:
            signals = set()
            for observation in self._obs.values():
                for sat in observation['data'].values():
                    signals = signals | set(sat.keys())
            all_signals = list(signals)
            fillter_signals = [signal for signal in signals if len(signal) < 3]
            if any(signal not in SIGNAL_ORDER for signal in fillter_signals):
                for signal in fillter_signals:
                    print(signal, signal not in SIGNAL_ORDER)
                raise Exception("Signal not in Signals Order")
            # [signal for signal in SIGNAL_ORDER if signal in fillter_signals]
            self._signals = SIGNAL_ORDER
        return self._signals

    def _get_obs_header(self):
        text = ""
        signals = self._get_signals()
        for i, chunked_signals in enumerate(
                list(list(signals)for signals in ichunked(signals, 9))):
            if i == 0:
                line = F"{len(signals):6}"
            else:
                line = " " * 6
            obs = "".join([F"{x:>6}" for x in chunked_signals])
            line = line + F"{obs:<54}# / TYPES OF OBSERV"
            text = text + line + "\n"
        return text

    def _get_first_obs_header_line(self):
        obs_first_time = first(self._obs)
        first_obs_text = "".join(
            F"{x:>6}" for x in [
                obs_first_time.year,
                obs_first_time.month,
                obs_first_time.day,
                obs_first_time.hour,
                obs_first_time.minute])
        first_obs_text = first_obs_text + \
            F"{obs_first_time.second + 1e6 * obs_first_time.microsecond:13.7f}     GPS         TIME OF FIRST OBS\n"
        return first_obs_text

    def _get_obs_file_header(self):
        now = datetime.now()
        date_string = F"{now:%d}-{now:%b}-{now:%y} {now:%H:%M:%S}".upper()
        text = F"        2           OBSERVATION DATA    M                   RINEX VERSION / TYPE\n" + \
               F"CCS                 EXO                 {date_string}  PGM / RUN BY / DATE\n" + \
               F"{self._station}                                                        MARKER NAME\n" \
               F"                                                            MARKER NUMBER\n" +  \
               F"TGO                 LEAR                                    OBSERVER / AGENCY\n"
        text = text + \
            "".join([F"{x:20}" for x in self._station_metadata_info['receiver'].split(', ')]) + "REC # / TYPE / VERS\n"
        antenna_text = "".join(
            [F"{x:20}" for x in self._station_metadata_info['antenna'].split(', ')])
        antenna_text = F"{antenna_text:60}ANT # / TYPE"
        text = text + antenna_text + "\n"
        antenna_text = "".join(
            [F"{x:20}" for x in self._station_metadata_info['antenna'].split(', ')])
        position_text = "".join(
            [F"{x:>14}" for x in self._station_metadata_info['position'].split(', ')])
        text = text + F"{position_text:60}APPROX POSITION XYZ\n"
        antena_delta_text = "".join(
            [F"{float(x):>14.4f}" for x in self._station_metadata_info['delta'].split(', ')])
        text = text + F"{antena_delta_text:60}ANTENNA: DELTA H/E/N\n"
        text = text + self._get_obs_header()
        text = text + self._get_first_obs_header_line()
        text = text + "                                                            END OF HEADER\n"
        return text
