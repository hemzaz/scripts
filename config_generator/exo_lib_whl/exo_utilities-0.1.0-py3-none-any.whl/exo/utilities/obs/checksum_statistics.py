
import pandas
import datetime
time_betweeen_obs = datetime.timedelta(seconds=30)


def get_stats_from_obs_checkpoint(data):
    receivers = {}
    for receiver, data in data['stations'].items():
        epochs = []
        for year, year_data in data.items():
            for day, day_data in year_data.items():
                for epoch in day_data['epochs']:
                    formated_time = datetime.datetime.strptime(
                        epoch['epoch'], "%Y-%m-%dT%H:%M:%S.%f")
                    epochs.append(formated_time)
        epochs.sort()
        df = pandas.DataFrame.from_dict(epochs)
        df_diff = df.diff()
        receivers[receiver] = dict(
            first_epoch=epochs[0],
            last_epoch=epochs[-1],
            max_outage_s=df_diff.max()[0].total_seconds(),
            total_obs_count=len(epochs),
            number_of_observation_jumps=int((df_diff > time_betweeen_obs).value_counts().get(True, pandas.Series(0)).iloc[0]),
            total_missing_time_seconds=df_diff[df_diff > time_betweeen_obs].sum()[0].total_seconds(),
            total_missing_obs=df_diff[df_diff > time_betweeen_obs].sum()[0] / time_betweeen_obs,
        )
    return receivers
