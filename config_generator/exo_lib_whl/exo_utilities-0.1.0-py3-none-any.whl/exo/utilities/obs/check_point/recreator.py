from . reader import ObsCheckPointReader
from .. storage.fetcher import ObsFetcher
from .. rinex.writer import RinexFileWriter
import concurrent.futures


class ObsCheckPointRecrator:
    def __init__(
            self,
            check_point_file,
            output_folder,
            long_term_storage_s3_prefix):
        self._check_point_file = check_point_file
        self._output_folder = output_folder
        self._long_term_storage_s3_prefix = long_term_storage_s3_prefix

    def _fetch(self,station,station_info,year,day_info,day):
        print(F"processing stations {station}:{year}:{day}")
        data = ObsFetcher(
            s3_prefix=self._long_term_storage_s3_prefix).get_data(
            station, epochs=day_info['epochs'])
        RinexFileWriter(
            output_folder=self._output_folder,
            station=station,
            station_metadata_info=day_info['station info'],
            obs=data)()

    def __call__(self):
        check_point_json = ObsCheckPointReader(self._check_point_file)()
        todos = []
        for station, station_info in check_point_json['stations'].items():
            
            for year, year_info in station_info.items():
                days = list(year_info.items())
                days.sort(key=lambda x: x[0])
                for day, day_info in days:
                    todos.append(dict(station=station,
                        station_info=station_info,year=year,day_info=day_info,day=day))
        with concurrent.futures.ThreadPoolExecutor(max_workers=80) as executor:
            list(executor.map(lambda x: self._fetch(**x),todos))
        
                    
