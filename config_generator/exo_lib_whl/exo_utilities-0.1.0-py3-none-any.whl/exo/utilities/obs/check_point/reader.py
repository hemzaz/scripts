from datetime import datetime
import json


class ObsCheckPointReader():
    def __init__(self, file_name):
        self._file_name = file_name

    def _convert_epochs_to_datetime(self, epochs):
        for epoch in epochs:
            epoch['epoch'] = datetime.strptime(
                epoch['epoch'], "%Y-%m-%dT%H:%M:%S.%f")

    def __call__(self):
        check_point_json = json.load(open(self._file_name))
        for station, station_info in check_point_json['stations'].items():
            for year, year_info in station_info.items():
                for day, day_info in year_info.items():
                    epochs = day_info['epochs']
                    self._convert_epochs_to_datetime(epochs)
        return check_point_json
