from datetime import timedelta, datetime
from exo.utilities import gpstime
from exo.utilities import s3
import re
import json
import gzip
DATE_REGEX = r"\d\d\d\d-\d\d-\d\dT\d\d-\d\d-\d\d"
S3_FILE_REGEX = F"([A-Za-z0-9]+)-c({DATE_REGEX})-s({DATE_REGEX})-e({DATE_REGEX}).gz"


class LongTermStorageObsFetcher():
    def __init__(self, station, epochs, s3_prefix):
        self._station = station
        self._epochs = epochs
        self._epochs_time_set = set([item['epoch'] for item in self._epochs])
        self._s3_prefix = s3_prefix

    def _first_epoch(self):
        return self._epochs[0]['epoch']

    def _last_epoch(self):
        return self._epochs[-1]['epoch']

    def _download_relevent_files(self, relevate_files):
        for relevent_file in relevate_files:
            print(F"download {relevent_file['file_path']}")
            loaded_data = json.loads(
                gzip.decompress(
                    s3.get_object(
                        relevent_file['file_path'])))
            relevent_file['data'] = loaded_data
        return relevate_files

    def _find_relevent_s3_files(self):
        relevate_files = []
        current_day = self._first_epoch()
        while (current_day < self._last_epoch() + timedelta(days=1)):
            current_gps_time = gpstime.from_utc(current_day)
            s3_files_path = Fr"{self._s3_prefix}/{current_day.year}/{int(current_gps_time.day_in_year):03}"
            files = s3.list_files(s3_files_path)
            for file in files:
                station, create_time, start_time, end_time = re.findall(
                    pattern=S3_FILE_REGEX, string=file)[0]
                create_time, start_time, end_time = [datetime.strptime(
                    time_str, "%Y-%m-%dT%H-%M-%S") for time_str in [create_time, start_time, end_time]]
                if station == self._station and end_time >= self._first_epoch(
                ) and start_time <= self._last_epoch():
                    relevate_files.append(dict(
                        file_path=F"{s3_files_path}/{file}",
                        create_time=create_time,
                        start_time=start_time,
                        end_time=end_time,
                    )
                    )
            current_day = current_day + timedelta(days=1)
            return relevate_files

    def __call__(self):
        relevent_files = self._find_relevent_s3_files()
        files = self._download_relevent_files(relevent_files)
        obs = {}
        for file in files:
            for item in file['data']['items']:
                time = datetime.strptime(item['epoch'], "%Y-%m-%dT%H:%M:%S.%f")
                if time not in self._epochs_time_set:
                    continue
                obs[time] = dict(
                    data=item['data'],
                    metadata=item['metadata']
                )
        return obs
