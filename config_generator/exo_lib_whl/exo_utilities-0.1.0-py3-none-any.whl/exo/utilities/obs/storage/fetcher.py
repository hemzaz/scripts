from . longterm import LongTermStorageObsFetcher
import os
def str_to_bool(s):
    return s.lower() in [
        'true',
        '1',
        't',
        'y',
        'yes',
        'yeah',
        'yup',
        'certainly',
        'uh-huh']

class ObsFetcher():
    def __init__(self, s3_prefix):
        self._s3_prefix = s3_prefix

    def get_data(self, station, epochs):
        
        obs = LongTermStorageObsFetcher(
            s3_prefix=self._s3_prefix,
            station=station,
            epochs=epochs)()
        if not str_to_bool(os.environ.get('DISABLE_CHECK',"true")):
            need_to_exists_epochs = set()
            for key in epochs:
                need_to_exists_epochs.add(key['epoch'])
            for epoch in obs.keys():
                need_to_exists_epochs.discard(epoch)
            if need_to_exists_epochs:
                raise Exception(
                    F"Not all epochs have been {station} found in storage: example {list(need_to_exists_epochs)[0:10]}")
        return obs
