from exo.gnss_utils.crt2rnx import crx2rnx_path
from exo.gnss_utils.gfzrnx import gfzrnx_path
import re
import os
import subprocess
from .rinex_file_name import rinex_file_name
from exo.utilities import gpstime
from exo.utilities.fetcher.cddis_fetcher import create_cddis_fetcher
import ftputil
FTP_SERVER = 'cddis.gsfc.nasa.gov'
URL_GNSS_OBS = 'archive/gnss/data/daily'
OBS_NAME_END = '0000_01D_30S_MO.crx.gz'


def download(dest_folder, reciver, time):
    return _DownloadObs(time).download_obs_rcv(reciver, dest_folder)


class _DownloadObs():
    def __init__(self, time):
        self._time = time
        self._fetcher = create_cddis_fetcher()

    def _gps_time(self):
        return gpstime.from_utc(self._time)

    def download_obs_rcv(self, rcv, dest_folder):
        assert isinstance(rcv, str)
        assert len(rcv) == 4, "rcv should be 4 chars"
        re_expression = F"^{rcv}.*_R_{self._time.year}{'{:03.0f}'.format(self._gps_time().day_in_year)}{OBS_NAME_END}$"
        obs_files_dir = F"{URL_GNSS_OBS}/{self._time.year}/{'{:03.0f}'.format(self._gps_time().day_in_year)}/{'{:02d}'.format(self._time.year-2000)}d"
        r = re.compile(re_expression, re.IGNORECASE)
        all_obs_files = self._fetcher.list(obs_files_dir)
        obs_file = list(filter(r.match, all_obs_files))
        if len(obs_file) > 0:
            obs_file = obs_file[0]
            obs_out = os.path.join(dest_folder, obs_file)
            self._fetcher.download(F"{obs_files_dir}/{obs_file}", obs_out)
            rnx_filename = rinex_file_name(rcv=rcv, time=self._time)
            crx_filename = F"{rcv}{'{:03.0f}'.format(self._gps_time().day_in_year)}0.{'{:02d}'.format(self._time.year-2000)}d"
            subprocess.check_call(
                F"gunzip -c -- {dest_folder}/{obs_file}  > {dest_folder}/{crx_filename}",
                shell=True)
            subprocess.check_call(
                F"{crx2rnx_path()} {dest_folder}/{crx_filename} -f", shell=True)
            subprocess.check_call(
                F"{gfzrnx_path()} -finp {dest_folder}/{rnx_filename} -fout {dest_folder}/{rnx_filename} -vo 2 -f -q",
                shell=True)
            os.remove(F"{dest_folder}/{obs_file}")
            os.remove(F"{dest_folder}/{crx_filename}")
        return F"{rnx_filename}"
