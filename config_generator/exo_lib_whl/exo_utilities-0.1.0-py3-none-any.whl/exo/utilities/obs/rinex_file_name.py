from exo.utilities import gpstime


def rinex_file_name(rcv, time):
    assert len(rcv) == 4, "receiver name should be 4 chars"
    gps_time = gpstime.from_utc(time)
    return F"{rcv.upper()}{'{:03.0f}'.format(gps_time.day_in_year)}0.{'{:02d}'.format(time.year-2000)}o"
