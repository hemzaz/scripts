import boto3
sns = boto3.client('sns')

def publish(arn,message):
  sns.publish(
        TopicArn=arn,
        Message=message,
    )