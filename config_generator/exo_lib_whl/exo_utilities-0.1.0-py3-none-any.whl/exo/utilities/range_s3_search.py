from .s3 import list_dir
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from itertools import chain


def _check_time(range_1, range_2):
    latest_start = max(range_1[0], range_2[0] if range_2[0] else range_1[0])
    earliest_end = min(range_1[1], range_2[1] if range_2[1] else range_1[1])
    return latest_start < earliest_end


def _filter(data, start_date, end_date):
    for item in data:
        if _check_time((item['start'], item['end']), (start_date, end_date)):
            yield item


def _filter_run(item, start_date, end_date):
    if start_date is not None and item['time'] < start_date:
        return False
    if end_date is not None and item['time'] > end_date:
        return False
    return True


def _month(year):
    months = []
    for x in list_dir(year['path']):
        year_start = year['start'].year
        year_end = year_start
        month_start = int(x)
        month_end = month_start + 1
        if month_end > 12:
            month_end = 1
            year_end = year_end + 1
        months.append(
            {
                'path': F"{year['path']}/{x}",
                'start': datetime(
                    year_start,
                    month_start,
                    1),
                'end': datetime(
                    year_end,
                    month_end,
                    1)})
    return months

import re
CALIBRATION_ID_TO_TIME_REGEX = r'(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d)-(\d\d)-(\d\d)'

def _parse_time_from_calibration_id(id):
    return  datetime(*[int(x) for x in re.findall(CALIBRATION_ID_TO_TIME_REGEX,id)[0]])

def _is_time_id(id):
    if re.findall(CALIBRATION_ID_TO_TIME_REGEX, id):
        return True
    return False

def _calibration_id(month,max_calibration_time =  timedelta(days=6)):
    calibrations = []
    for x in list_dir(month['path']):
        calibration_time = _parse_time_from_calibration_id(x)
        
        calibrations.append({
            'path': F"{month['path']}/{x}",
            'start': calibration_time,
            'end': calibration_time +max_calibration_time})
    return calibrations



def _days(month):
    days = []
    for x in list_dir(month['path']):
        day = month['start'] + timedelta(days=int(x) - 1)
        days.append({
            'path': F"{month['path']}/{x}",
            'start': day,
            'end': day + timedelta(days=1)})
    return days


def _runs(day):
    runs = []
    for run in list_dir(day['path']):
        hour, minute, second = [int(x) for x in run.split('-')]
        path = F"{day['path']}/{run}"
        run_time = day['start'] + \
            timedelta(hours=hour, minutes=minute, seconds=second)
        runs.append(dict(path=path, time=run_time))
    return runs

def _runs_with_full_time(path):
    runs = list_dir(path)
    results = []
    for run in runs:
        if _is_time_id(run):
            time = _parse_time_from_calibration_id(run)
            results.append(dict(time=time,path=F"{path}/{run}"))
    return results

def iterator(path,start_date=None,end_date=None,reverse=False):
    
    years = list_dir(path)
    years = [{'path': F'{path}/{x}',
              'start': datetime(int(x),
                                1,
                                1),
              'end': datetime(int(x) + 1,
                              1,
                              1)} for x in years]
    years = list(_filter(years, start_date, end_date))
    years.sort()
    for year in years:
        months = _month(year)
        months.reverse()
        for month in _filter(months, start_date, end_date):
            days = _days(month)
            days.reverse()
            for day in _filter(days,start_date,end_date):
                runs = _runs(day)
                runs.reverse()
                for run in runs:
                    if _filter_run(run,start_date,end_date):
                        yield run



def list_relevent_runs_by_calibration_id(path,start_date,end_date,thread_count = 10):
    years = list_dir(path)
    years = [{'path': F'{path}/{x}',
              'start': datetime(int(x),
                                1,
                                1),
              'end': datetime(int(x) + 1,
                              1,
                              1)} for x in years]
    with ThreadPoolExecutor(thread_count) as executor:              
        years = list(_filter(years, start_date, end_date))
        months = list(chain(*executor.map(_month, years)))
        months = list(_filter(months, start_date, end_date))
        calibrations = list(chain(*executor.map(_calibration_id, months)))
        calibrations = list(_filter(calibrations, start_date, end_date))
        runs = list(chain(*executor.map(_runs_with_full_time, [x['path'] for x in calibrations])))
        runs = [run for run in runs if _filter_run(run, start_date, end_date)]
        return runs




def range_s3_search(path, start_date=None, end_date=None, thread_count=10):

    years = list_dir(path)
    years = [{'path': F'{path}/{x}',
              'start': datetime(int(x),
                                1,
                                1),
              'end': datetime(int(x) + 1,
                              1,
                              1)} for x in years]
    years = list(_filter(years, start_date, end_date))

    with ThreadPoolExecutor(thread_count) as executor:
        months = list(chain(*executor.map(_month, years)))
        months = list(_filter(months, start_date, end_date))
        days = list(chain(*executor.map(_days, months)))
        days = list(_filter(days, start_date, end_date))
        runs = list(chain(*executor.map(_runs, days)))
        runs = [run for run in runs if _filter_run(run, start_date, end_date)]
        
        return runs
