import os
import re
from datetime import datetime
from deepmerge import always_merger
from pandas import DataFrame

NAV_DATA_FIELDS = ['clock_bias',
                   'clock_drift',
                   'clock_drift_rate'] + ['iode'] + ['crs',
                                                     'delta_n',
                                                     'm0',
                                                     'cuc',
                                                     'e',
                                                     'cus',
                                                     'sqrt_a',
                                                     'toe'] + ['cic',
                                                               'omega0',
                                                               'cis',
                                                               'i0',
                                                               'crc',
                                                               'omega',
                                                               'omega_dot',
                                                               'idot'] + ['codes_on_l2',
                                                                          'gpsweek',
                                                                          'l2p_flag',
                                                                          'sv_accuracy',
                                                                          'sv_health',
                                                                          'tgd'] + ['iodc',
                                                                                    'tot',
                                                                                    'fit_interval']


def nav_statistics(nav_folder):
    files = os.listdir(nav_folder)
    nav_files = sorted([file_name for file_name in files if re.match(
        r'BRDC00IGS_R_\d{4}\d{3}0000_01D_MN.rnx', file_name)])
    data = {}
    for nav_file in nav_files:
        always_merger.merge(
            data,
            nav_reader(
                open(
                    os.path.join(
                        nav_folder,
                        nav_file)))())
    output = {}
    for sat, sat_data in data.items():
        df = DataFrame.from_dict(sat_data, orient='index')
        timing = df.index.to_series()
        diff_index = df.index.to_series().diff()
        output[sat] = dict(
            min_sat_ephem=timing.min(),
            max_sat_ephem=timing.max(),
            min_diff=diff_index.min(),
            max_diff=diff_index.max(),
        )
    return output


class nav_reader:
    def __init__(self, file):
        text = file.read()
        header, data_raw = text.split('END OF HEADER\n')
        self._header = header[:-1]
        self._data = {}
        data_raw = data_raw[:-1]
        data_raw_lines = data_raw.split('\n')
        n = 8
        samples = [data_raw_lines[index: index + n]
                   for index in range(0, len(data_raw_lines), n)]
        for sample_lines in samples:
            first_line = sample_lines[0]
            sat = first_line[:3]
            time = datetime(*[int(x) for x in first_line[4:23].split(' ')])
            nums = first_line[23:]
            data = [float(nums[index: index + 19])
                    for index in range(0, len(nums), 19)]
            for line in range(1, 8):
                nums = sample_lines[line][4:]
                data = data + [float(nums[index: index + 19])
                               for index in range(0, len(nums), 19)]
            sample = dict(zip(NAV_DATA_FIELDS, data))
            if sat not in self._data:
                self._data[sat] = {}
            self._data[sat][time] = sample

    def __call__(self):
        return self._data
