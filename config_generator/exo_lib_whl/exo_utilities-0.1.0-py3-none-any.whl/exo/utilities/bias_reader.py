from statemachine import StateMachine, State
from datetime import timedelta,datetime
from collections import namedtuple

class BaisReaderFactory:
  def __init__(self,*args,**kwargs):
    self._args = args
    self._kwargs = kwargs
  def __call__(self):
    return _BaisReader(*self._args,**self._kwargs)

class _BaisReader(StateMachine):
  search_start_line = State('search_for_state_machine',initial=True)
  item_header_reader = State('item_header_reader')
  sat_reader = State('sat_reader')
   
  read_item_header = search_start_line.to(item_header_reader)
  read_sat = item_header_reader.to(sat_reader)
  reset = sat_reader.to(search_start_line)
  
  def __init__(self,frequency_labels,item_header_parser = None,sat_extra_info = [],sat_items_name='signals_info', *args,**kwargs):
    self._sat_items_name = sat_items_name
    self._frequency_labels = frequency_labels
    self._sat_extra_info = sat_extra_info
    self._item_header_parser = item_header_parser
    super().__init__(*args,**kwargs)

  def read(self,data):
    self._results = []
    for line in data.split('\n'):
      self._newline(line)
    return self._results


  def _newline(self,line):
    if self.current_state == self.search_start_line:
      if line[:1] == '>':
        splited = line.split(' ')
        self._current_item = {
          'time': datetime(*[int(x) for x in splited[2:7]]) +timedelta(seconds = float(splited[7])),
          'num_of_sats':int(splited[9]),
          'ssr_update_interval' : int(splited[8]),
          'sat_info': {}
        }
        self._num_of_expected_sat = int(splited[9])
        self.read_item_header()
        if not self._item_header_parser:
          self.read_sat()
    elif self.current_state == self.item_header_reader:
        self._current_item = {**self._current_item,**self._item_header_parser.parse(line)}
        self.read_sat()
    elif self.current_state == self.sat_reader:
      for x in range(4):
        line= line.replace('  ',' ')
      line_info = line.split(' ')
      current_item_index = 0
      sat = line_info[current_item_index]
      current_item_index += 1
      sat_extra_info = [(x.name,x.type(line_info[i+current_item_index]))for i,x in enumerate(self._sat_extra_info)]
      current_item_index+=len(self._sat_extra_info)

      number_of_frequency = int(line_info[current_item_index])
      current_item_index += 1
      
      frequncies_infomation = {}
      for x in range(number_of_frequency):
        frequncy = line_info[current_item_index]
        current_item_index += 1
        values = line_info[current_item_index: current_item_index + len(self._frequency_labels)]
        for i,value in enumerate(values):
          expected_type = self._frequency_labels[i].type
          if expected_type == expected_type:
            values[i] = expected_type(value)
          else:
            raise Exception("not implemented type conversion")
        frequncy_info = dict(zip([x.name for x in self._frequency_labels],values
              ))
        current_item_index +=len(self._frequency_labels)
        frequncies_infomation[frequncy] = frequncy_info
      self._current_item['sat_info'][sat] = {**{ self._sat_items_name: frequncies_infomation},**dict(sat_extra_info)}
      self._num_of_expected_sat -=1
      if self._num_of_expected_sat == 0:
        self._results.append(self._current_item)
        self.reset()
    else:
      raise Exception("not implemented")

LabelItem = namedtuple('LabelItem',['name','type'])

class MWBItemReader():
    def parse(self,data):
      return dict(zip(['dispersive_bias_consistency_indicatory','mw_consistency_indicator'],[int(x) for x in data.split(' ')]))


mw_bais_reader = BaisReaderFactory(item_header_parser=MWBItemReader(),
    sat_extra_info = [
      LabelItem(name='yaw_angle_deg',type=float),
      LabelItem(name='yaw_rate_deg_s',type=float),
    ],
    frequency_labels=[
      LabelItem(name='phase_bias_m',type=float),
      LabelItem(name='signal_integer_indicator',type=int),
      LabelItem(name='signal_wide_lane_integer_indicator',type=int),
      LabelItem(name='signal_discontinuity_counter',type=int),
    ])()
apc_bias_reader = BaisReaderFactory(
    frequency_labels=[
      LabelItem(name='x',type=float),
      LabelItem(name='y',type=float),
    ])()

dcb_bias_reader = BaisReaderFactory(
    frequency_labels=[
      LabelItem(name='code_bias_m',type=float),
    ])()
sigma_bias_reader = BaisReaderFactory(
    frequency_labels=[
      LabelItem(name='sigma_code_bias_m',type=float),
    ])()