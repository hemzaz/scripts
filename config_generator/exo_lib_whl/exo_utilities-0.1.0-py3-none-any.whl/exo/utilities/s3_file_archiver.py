import logging

from exo.utilities import s3
import time
import json
import zlib
from more_itertools import first
import hashlib
import os
from multiprocessing import Pool
from functools import partial
from retrying import retry
import re
JSON_NAME = "upload-data.json"
TIME_STAMP_FORMAT = '%Y/%m/%d/%H-%M-%S'
ARCHIVE_FILE_VERSION = 1


class Search():
    def __init__(self, regex, sort_key, condition=None):
        self._regex = regex
        self._sort_key = sort_key
        self._condition = condition

    def check_condition(self, name, full_s3_path):
        return re.match(
            self._regex, name) and (
            self._condition is None or self._condition(
                name=name, full_s3_path=full_s3_path))


class PathSearcher():
    def __init__(self, base_path, reverse=True):
        self._base_path = base_path
        self._reverse = reverse
        self._folders = []
        self._file_search = None

    def files(self, file_regex, file_sort_func=None):
        assert not self._file_search, "please set file only once"
        self._file_search = Search(
            file_regex,
            file_sort_func,
            self._file_condition)
        return self

    def add_folder(self, folder_regex, sort_func):
        self._folders.append(Search(regex=folder_regex, sort_key=sort_func))
        return self

    def _file_condition(self, full_s3_path, name):
        directory_postfix_length = 1
        key_without_base_path = full_s3_path[len(
            self._base_path) + directory_postfix_length:]
        for version in s3.list_dir(full_s3_path):
            folder_prefix = F"{key_without_base_path[:-(len(name)+directory_postfix_length)]}/"
            if folder_prefix == "/":
                folder_prefix = ""
            upload_data_file_path = F"{full_s3_path}/{version}/{folder_prefix}upload-data.json"
            if s3.object_exists(upload_data_file_path):
                return True
        return False

    def _find(self, search_by, current_path):
        search = search_by[0]
        files = s3.list_dir(current_path)
        files.sort(key=search._sort_key, reverse=self._reverse)
        for file in files:
            full_s3_path = F"{current_path}/{file}"
            if search.check_condition(name=file, full_s3_path=full_s3_path):
                if len(search_by) == 1:
                    yield full_s3_path[len(self._base_path) + 1:]
                else:
                    for found in self._find(
                            search_by=search_by[1:], current_path=F"{current_path}/{file}"):
                        yield found

    def __iter__(self):
        full_path = self._base_path
        search_by = self._folders + [self._file_search]

        for found in self._find(search_by, full_path):
            yield(found)


def uncommpress_file(compress, object_data):
    if compress == "zlib":
        object_data = zlib.decompress(object_data)
    elif compress == "none":
        pass
    else:
        raise Exception("compress not supported")
    return object_data


class FileNotFoundInArchive(Exception):
    pass


class S3FileArchiver:
    def __init__(
            self,
            source_directory=None,
            s3_logs_path=None,
            s3_files_path=None,
            labels={},
            compress=True):
        self._source_directory = source_directory
        self._s3_logs_path = s3_logs_path
        self._s3_files_path = s3_files_path
        self._labels = labels
        self._compress = compress
        self.creation_time = time.strftime(TIME_STAMP_FORMAT, time.gmtime())

    @property
    def _location_in_logs_bucket(self):
        return F"{self._s3_logs_path}/{self.creation_time}/{JSON_NAME}"

    def upload_directory(self):
        uploaded_files = {}
        for root, dirs, files in os.walk(self._source_directory):
            for filename in files:
                absolute_path_of_file = os.path.join(root, filename)
                file_key_name = os.path.relpath(
                    absolute_path_of_file, self._source_directory)
                file_directory = os.path.relpath(root, self._source_directory)
                uploaded_files[file_key_name] = self.upload_file(
                    key=file_key_name, file_path=absolute_path_of_file)
        if self._s3_logs_path:
            self._upload_json_per_run(uploaded_files=uploaded_files)

    def search(self, reverse=True):
        assert not isinstance(reverse, str)
        return PathSearcher(
            self._s3_files_path,
            reverse=reverse)

    def upload_file(self, key, file_path):
        file_sha256 = sha256_for_file(file_path)
        s3_file_path_per_file = self._get_s3_path(
            key=key,
            file_sha256=file_sha256)

        json_file = self._create_json_per_file(
            os.path.split(key)[1], file_sha256, s3_file_path_per_file)
        summary_path = self._get_summary_path(key=key, file_sha256=file_sha256)
        if not s3.object_exists(
                s3_file_path_per_file) or not s3.object_exists(summary_path):
            logging.info("Uploading %s" % s3_file_path_per_file)
            print("Uploading %s" % s3_file_path_per_file)
            if self._compress:
                with open(file_path, 'rb') as f:
                    compress_data = zlib.compress(f.read())
                    s3.write_to_key(data=compress_data,
                                    path=s3_file_path_per_file)
            else:
                s3.upload_file(file_name=file_path, to=s3_file_path_per_file)

            s3.write_to_key(data=json.dumps(json_file),
                            path=summary_path)
        return json_file

    def _get_summary_path(self, key, file_sha256):
        s3_file_path_per_file = self._get_s3_path(
            key=key, file_sha256=file_sha256)
        return '/'.join(s3_file_path_per_file.split('/')
                        [:-1]) + '/upload-data.json'

    def file_exists(self, key):
        return True if self.get_versions(key) else False

    def get_versions(self, key):
        returns = []

        versions = s3.list_dir(F"{self._s3_files_path}/{key}")
        versions = [
            F"{self._s3_files_path}/{key}/{version}" for version in versions]
        for version in versions:
            if s3.object_exists(
                    F"{version}/{self._folder_to_key(key)}upload-data.json"):
                returns.append(version)
        return returns

    def _folder_to_key(self, key):
        folders = key.split('/')[:-1]
        if not folders:
            return ""
        else:
            return '/'.join(folders) + '/'

    @retry(stop_max_attempt_number=2)
    def get_file(self, key):
        versions = self.get_versions(key)
        if not versions:
            raise FileNotFoundInArchive(
                F"{key} wasn't found in archive: {self._s3_files_path}")
        selected_version = versions[0]
        json_data = json.loads(s3.get_object(
            F"{selected_version}/{self._folder_to_key(key)}upload-data.json"))
        files = [(key,) for key, data in json_data['files'].items()][0]
        file_info = first(json_data['files'].values())
        object_data = s3.get_object(file_info['s3_location'])
        compress = file_info.get('compress', "none").lower()
        object_data = uncommpress_file(
            compress=compress, object_data=object_data)
        return dict(
            data=object_data,
            s3_path=file_info['s3_location'],
            metadata=json_data)

    def _get_s3_path(self, key, file_sha256):
        return F"{self._s3_files_path}/{key}/{file_sha256}/{key}"

    def _upload_json_per_run(self, uploaded_files):
        runs_bucket_json = json.dumps(
            self._create_json_logs_bucket(
                uploaded_files=uploaded_files))
        return s3.write_to_key(
            data=runs_bucket_json,
            path=self._location_in_logs_bucket)

    def _create_json_per_file(self, filename, file_sha256, s3_path):
        json_files = {}
        json_files.update(self._create_file_template(
            filename, file_sha256, s3_path))
        return self._create_json(json_files)

    @retry(stop_max_attempt_number=2)
    def _upload_json_per_file(
            self,
            dest_path_per_file,
            json_file,
            file_directory):
        print(
            F"where to write: {self._s3_files_path}/{dest_path_per_file}/{file_directory}/{JSON_NAME}")
        if file_directory == ".":
            s3.write_to_key(
                data=json_file,
                path=F"{self._s3_files_path}/{dest_path_per_file}/{JSON_NAME}")
        else:
            s3.write_to_key(
                data=json_file,
                path=F"{self._s3_files_path}/{dest_path_per_file}/"
                     F"{file_directory}/{JSON_NAME}")

    def _update_file_uploaded(self, filename, file_sha256, s3_path):
        if self._uploaded_files is not None:
            self._uploaded_files.update(
                self._create_file_template(filename, file_sha256, s3_path))

    def _create_file_template(self, file_name, sha256, s3_location):
        """Create a json template for a every file created"""
        file_template = {
            file_name: {
                "sha256": sha256,
                "s3_location": s3_location,
                "compress": "zlib" if self._compress else "None",
            }
        }
        return file_template

    def _create_json(self, files):
        """Create a upload-data.json file using a template"""
        json_template = {
            "metadata": {
                "location_in_logs_bucket": self._location_in_logs_bucket,
                "file_version": ARCHIVE_FILE_VERSION,
                "labels": self._labels,

            },
            "files": files,
        }
        return json_template

    def _create_json_logs_bucket(self, uploaded_files):
        json_template = {
            "metadata": {
                "file_version": ARCHIVE_FILE_VERSION,
                "labels": self._labels,
            },
            "files": uploaded_files,
        }
        return json_template


def sha256_for_file(file_path):
    sha256_hash = hashlib.sha256()
    with open(file_path, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
        return sha256_hash.hexdigest()


@retry(stop_max_attempt_number=2)
def download_file_from_metadata(file_info, dest_folder):
    if 's3_path' not in file_info:
        return
    s3_path = file_info['s3_path']
    file_name = file_info['file_name']
    file_metadata = list(file_info['metadata']['files'].values())[0]
    dest_file = os.path.join(dest_folder, file_name)
    if os.path.exists(dest_file):
        sha256 = file_metadata['sha256']
        if sha256_for_file(dest_file) == sha256:
            return
    file_data = s3.get_object(s3_path)
    print(s3_path)
    compression = file_metadata.get('compress', 'none')
    if compression == 'zlib':
        file_data = zlib.decompress(file_data)
    elif compression == 'none':
        raise Exception('Unsupported compression')
    os.makedirs(os.path.split(os.path.join(
        dest_folder, file_name))[0], exist_ok=True)
    with open(os.path.join(dest_folder, file_name), 'wb') as f:
        f.write(file_data)


def download_files_from_metadata_json(s3_path, folder):
    data = json.loads(s3.get_object(s3_path))
    files = data['files']

    with Pool(10) as p:
        p.map(partial(download_file_from_metadata, dest_folder=folder), files)
