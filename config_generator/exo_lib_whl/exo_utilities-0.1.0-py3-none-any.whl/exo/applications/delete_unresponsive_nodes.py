import boto3
from kubernetes import client, config
from datetime import datetime, timezone, timedelta
import click
from ..utilities import click_types
# Configs can be set in Configuration class directly or using helper utility


def str_to_bool(s):
    return s.lower() in [
        'true',
        '1',
        't',
        'y',
        'yes',
        'yeah',
        'yup',
        'certainly',
        'uh-huh']


config.load_kube_config()


@click.command()
@click.option('--startup-time', default='15m', type=click_types.TimeDelta())
@click.option('--ready-condition-last-update-time',
              default='5m', type=click_types.TimeDelta())
@click.option('--node-tag', type=(str, str), multiple=True)
def cli(node_tag, **kwargs):
    run(node_tags=dict(node_tag), **kwargs).check_nodes()


class run:
    def __init__(
            self,
            node_tags,
            startup_time,
            ready_condition_last_update_time):
        self._startup_time = startup_time
        self._node_tags = node_tags
        self._ready_condition_last_update_time = ready_condition_last_update_time

    def check_nodes(self):
        print('check_node')
        v1 = client.CoreV1Api()
        now = datetime.now(tz=timezone.utc)
        nodes = v1.list_node()
        for node in nodes.items:
            ready_condition = [
                condition for condition in node.status.conditions if condition.type == 'Ready'][0]
            ready_status = str_to_bool(ready_condition.status)
            created_diff = now - node.metadata.creation_timestamp
            if not ready_status and
                created_diff > self._startup_time and now - ready_condition.last_heartbeat_time > :
                    print(F"{node.metadata.name} is failing test killing")

                    pass
            else:
                print(F"{node.metadata.name} is ok")
                from IPython import embed
                embed()
                break


def terminate_instance(private_dns_name, required_tags={}):
    ec2 = boto3.resource('ec2')
    for inst in ec2.instances.all():
        inst_tags = dict((x['Key'], x['Value']) for x in inst.tags)
        if inst.private_dns_name == private_dns_name and \
                required_tags.items() <= inst_tags.items():
            inst.terminate()


if __name__ == '__main__':
    # terminate_instance('ip-10-1-194-18.us-east-2.compute.internal')
    cli()
