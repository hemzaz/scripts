from datetime import timedelta
import click
import functools
from multiprocessing import Pool
import subprocess
import os
import re
from exo.utilities.obs.downloader import download
from exo.utilities.click_types import DateTime, TimeDelta, S3Path
from exo.utilities import exo_range
from exo.utilities import gpstime

RECEIVERS = {
    "mvp": [
        'ALBH',
    ],
    'foc': [
        'AIRA',
        'AJAC',
        'ALBH',
        'ALIC',
        'AREG',
        'ASCG',
        'AUCK',
        'BOAV',
        'BRAZ',
        'BRST',
        'BZRG',
        'CAS1',
        'CCJ2',
        'CEDU',
        'CHPG',
        'CHTI',
        'CIBG',
        'COCO',
        'CPVG',
        'CUUT',
        'DARW',
        'DAV1',
        'DRAO',
        'DUBO',
        'DUND',
        'DYNG',
        'FFMJ',
        'FLIN',
        'GAMB',
        'GAMG',
        'GRAC',
        'HARB',
        'HOB2',
        'HOFN',
        'ISHI',
        'ISTA',
        'JFNG',
        'KAT1',
        'KERG',
        'KIR0',
        'KIR8',
        'KIRI',
        'KIT3',
        'KITG',
        'KOUG',
        'KRGG',
        'KUJ2',
        'LAUT',
        'LHAZ',
        'LMMF',
        'LPGS',
        'MAC1',
        'MAJU',
        'MAR6',
        'MAR7',
        'MARS',
        'MATE',
        'MAW1',
        'MCHL',
        'MELI',
        'METG',
        'MIZU',
        'MOBS',
        'MQZG',
        'MRO1',
        'NICO',
        'NIUM',
        'NKLG',
        'NRC1',
        'NRMG',
        'OBE4',
        'OHI3',
        'ONS1',
        'ONSA',
        'OUS2',
        'OWMG',
        'PADO',
        'PARK',
        'PICL',
        'PNGM',
        'POAL',
        'POTS',
        'POVE',
        'PRDS',
        'PTGG',
        'REUN',
        'REYK',
        'RGDG',
        'RIO2',
        'SALU',
        'SASK',
        'SAVO',
        'SCH2',
        'SCTB',
        'SEYG',
        'SGOC',
        'SGPO',
        'SPT0',
        'STJ3',
        'STJO',
        'STK2',
        'STR1',
        'STR2',
        'SUTM',
        'SYDN',
        'SYOG',
        'THTG',
        'TID1',
        'TLSE',
        'TLSG',
        'TONG',
        'TOW2',
        'TSK2',
        'UFPR',
        'ULAB',
        'UNSA',
        'URUM',
        'UTQI',
        'VIS0',
        'WARK',
        'WGTN',
        'WIND',
        'WTZR',
        'WUH2',
        'XMIS',
        'YAR2',
        'YAR3',
        'YARR',
        'YELL']}


def _download(x, dest_folder):
    download(time=x[0], reciver=x[1], dest_folder=dest_folder)


@click.command()
@click.option('--start-time', type=DateTime(), required=True)
@click.option('--delta', type=TimeDelta(), default="1d")
@click.option('--receivers-list',
              type=click.Choice(list(RECEIVERS.keys())), default="mvp")
@click.argument('dest-folder')
def cli(start_time, delta, receivers_list, dest_folder):
    receivers = RECEIVERS[receivers_list]
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)
    step = timedelta(days=1)
    time = min(start_time, start_time + delta)
    end_time = max(start_time, start_time + delta)
    to_download = []
    for time in exo_range(time, end_time, step):
        for rcv in receivers:
            to_download.append((time, rcv))

    with Pool(40) as p:
        p.map(
            functools.partial(
                _download,
                dest_folder=dest_folder),
            to_download)
