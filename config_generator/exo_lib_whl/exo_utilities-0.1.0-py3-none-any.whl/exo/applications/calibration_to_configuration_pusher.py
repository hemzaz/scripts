import click
import json
import requests
from . configuration_api.api import Api


@click.command()
@click.option('--host', default="http://calibrations-api.foc-staging.lear-exo.com")
@click.argument('data')
def cli(host, data):
    data = json.loads(data)
    id = data['time'].replace(':', "-")
    data['id'] = id
    Api(url=host).push(id=id, time=data['time'], data=data)