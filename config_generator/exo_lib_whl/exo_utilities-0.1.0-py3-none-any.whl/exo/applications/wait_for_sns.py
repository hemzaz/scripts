import time
import threading
import click

import boto3
import uuid
from IPython import embed
from contextlib import contextmanager
from contextlib import ExitStack
import json
import os
import time
from subprocess import CalledProcessError
from prometheus_client import start_http_server,Gauge,Counter
import sys
from functools import partial
import subprocess

sqs = boto3.resource('sqs')
sns = boto3.resource('sns')
sts = boto3.client("sts")



@contextmanager
def sqs_queue(name, **kwargs):
    queue = None
    try:
        queue = sqs.create_queue(QueueName=name, **kwargs)
        print(F"queue created {queue.attributes['QueueArn']}")
        yield queue
    finally:
        if queue != None:
            queue.delete()


@contextmanager
def sns_subsciption(topic_arn, **kwargs):
    topic = sns.Topic(topic_arn)
    topic.load()
    try:
        subscription = topic.subscribe(**kwargs)
        yield subscription
    finally:
        if subscription != None:
            subscription.delete()


@contextmanager
def sqs_ephemeral_connection(topic_arn):
    queue_name = F"{topic_arn.split(':')[-1]}-{uuid.uuid4().urn.split(':')[-1][:8]}"
    policy_document = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "MyPolicy",
                "Effect": "Allow",
                "Principal": {"AWS": "*"},
                "Action": "SQS:SendMessage",
                "Resource": F"arn:aws:sqs:{sqs.meta.client.meta.region_name}:{sts.get_caller_identity()['Account']}:{queue_name}",
                "Condition": {
                    "ArnEquals": {
                        "aws:SourceArn": topic_arn
                    }
                }
            }
        ]
    }
    tags = dict(
            Ephemeral='true',
            Pod=os.environ.get('POD_NAME',"UNKNWOWN"),
            Zone=os.environ.get('ZONE',"UNKNWOWN"),
            Namespace=os.environ.get('NAMESPACE',"UNKNWOWN"),
            Cluster=os.environ.get('CLUSTER',"UNKNWOWN"),
            CreateTime=str(time.time()),
        )
    with sqs_queue(name=queue_name, Attributes={'Policy': json.dumps(policy_document)}, tags=tags) as queue:
        with sns_subsciption(topic_arn=topic_arn, Protocol="sqs", Endpoint=queue.attributes['QueueArn']) as subscription:
            yield queue

is_thread_running = Gauge('is_thread_running', 'is application running',['thread_name'])

@contextmanager
def thread_worker(func,name):
    class Handler:
        def __init__(self, func,name):
            self._func = func
            self._running = True
            self._name = name

        def __call__(self):
            with is_thread_running.labels(self._name).track_inprogress():
                while(self._running):
                    self._func()

        def close(self):
            self._running = False

    handler = Handler(func=func,name = name)
    thread = threading.Thread(target=handler)
    thread.start()
    yield None
    handler.close()
    thread.join()


class SnsWorker(object):
    def __init__(self, func, topic_arn):
        self._func = func
        self._topic_arn = topic_arn
        self._running = True
        self._exitstack = None

    def __exit__(self, *args, **kwargs):
        self._running = False
        if self._exitstack != None:
            self._exitstack.close()
            self._exitstack = None


    def _work(self):
        while(self._running):
            receive_kwargs = dict(
                MaxNumberOfMessages=1
            )
            messages = self._queue.receive_messages(**receive_kwargs)
            if (messages):
                for message in messages:
                    self._func(message=json.loads(message.body)['Message'])
                response =self._queue.delete_messages(
                    Entries= [ dict(Id=message.message_id,ReceiptHandle=message.receipt_handle) for message in messages]
                )
                
                print(response)


    def __enter__(self):
        with ExitStack() as stack:
            self._queue = stack.enter_context(
                sqs_ephemeral_connection(self._topic_arn))
            stack.enter_context(thread_worker(self._work,"sns_worker"))
            self._exitstack = stack.pop_all()
            return "OK"

last_run_time = Gauge('last_time_application_tried_to_run', 'last time application tried to run')
is_application_running = Gauge('is_application_running', 'is application running')
successfull_runs_counter = Counter('successfull_runs_counter',"number of successfull_runs")
unsuccessfull_runs_counter = Counter('unsuccessfull_runs_counter',"number of unsuccessfull_runs")



def call_application(command,message):
    last_run_time.set_to_current_time()
    try:
        with is_application_running.track_inprogress():
            subprocess.check_call(command,
                    shell=True,
                     stdout=sys.stdout, stderr=sys.stderr)
        successfull_runs_counter.inc()
    except CalledProcessError:
        unsuccessfull_runs_counter.inc()
        print("error when calling application")





@click.command()
@click.option('--topic', required=True)
@click.option('--run-command-on-startup', default=False,type =bool)
@click.argument('command')
def cli(topic, command,run_command_on_startup):
    start_http_server(8081)

    call_application_with_command = partial(call_application,command=command)
    with SnsWorker(func=call_application_with_command, topic_arn=topic) as worker:
        if run_command_on_startup:
            call_application_with_command(message = "")
        print('start waiting')
        while(True):
            time.sleep(2000)