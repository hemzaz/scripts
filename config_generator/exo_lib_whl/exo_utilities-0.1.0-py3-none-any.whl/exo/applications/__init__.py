from kubernetes import config
import os

def kube_load_config():
  if os.getenv('KUBERNETES_SERVICE_HOST'): 
    config.load_incluster_config()
  else:
    config.load_kube_config()
    