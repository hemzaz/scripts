import click
from exo.utilities.nav_reader import nav_statistics
from pprint import pprint


@click.command()
@click.argument('nav-folder')
def cli(nav_folder):
    output = nav_statistics(nav_folder)
    pprint(output)

if __name__ == '__main__':
    cli()
