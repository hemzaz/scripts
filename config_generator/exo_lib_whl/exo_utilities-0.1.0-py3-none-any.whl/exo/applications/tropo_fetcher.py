import logging
import time
from datetime import datetime, timedelta

import click
from exo.applications.tropo_fetcher_classes import (TropoFileA, TropoFileB1,
                                                    TropoFileB2)
from exo.utilities.click_types import DateTime
logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


@click.command()
@click.option('--init-date', type=DateTime(),
              default=F"{datetime.utcnow():%Y-%m-%dT%H:%M:%S}")
@click.option('--extra-run', type=int, default=0,
              help="additional run with hours shift before init-date")
@click.option('--s3-path', type=str, default="s3://lear-exo-dror",
              help="S3 path (e.g. s3://lear/myFolder")
@click.option('--force/--no-force', default=False,
              help="Enforce writing existing files on S3")
@click.option('--partial/--no-partial', default=False,
              help="Read partial source file (stream=true)")
@click.option('--save-local/--no-save-local', default=False,
              help="Save file to local machine")
def cli(init_date, extra_run, s3_path, force, partial, save_local):
    logger.info("Starting Tropo Fetcher:")
    logger.info("=" * 23)

    logger.info('S3-path= %s' % s3_path)
    logger.info('force= %s' % force)
    logger.info('partial= %s' % partial)
    logger.info('save-local= %s' % save_local)

    S3_FILE_PATH = s3_path  # "s3://lear-exo-dror"
    date_init = init_date
    logger.info(F'date_init= {date_init}')

    # Get the latest running time for the current time
    current_run_hour = date_init.hour // 6 * 6
    current_run_date = datetime(
        date_init.year,
        date_init.month,
        date_init.day,
        current_run_hour,
        0,
        0,
        0)
    logger.info(F'current_run_hour= {current_run_hour}')
    logger.info(F'current_run_date= {current_run_date}')

    runs_list = [current_run_date]
    if extra_run != 0:
        extra_run_date = current_run_date - timedelta(hours=extra_run)
        runs_list.append(extra_run_date)
        logger.info(F'extra_run_date= {extra_run_date}')

    logger.info(
        F'Running dates list contains ({str(len(runs_list))}) items(s):')
    for runs_list_item in runs_list:
        logger.info("Running date= " + str(runs_list_item))
        for tropo_file_fetcher in (TropoFileA, TropoFileB1, TropoFileB2):
            tropo_file = tropo_file_fetcher(s3_path=S3_FILE_PATH,
                                            partial_load=partial,
                                            force_writing_on_S3=force,
                                            save_local=save_local,
                                            current_run_date=runs_list_item)
            logger.info("Saving files for type= " + tropo_file._file_type)
            tropo_file.save()
