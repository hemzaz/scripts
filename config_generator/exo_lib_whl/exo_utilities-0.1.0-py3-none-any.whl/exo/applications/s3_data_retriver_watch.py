import click
from exo.applications.s3_data_retriver import FTP_PRODUCTS


@click.command()
@click.option('--rabbitmq-server',
              default='amqp://user:1234@172.20.157.247:5672/')
@click.option('--s3-products-prefix',
              default='s3://lear-exo/zone/p/Archive/Sync/products')
@click.option('--products',
              type=(click.STRING, click.Choice(FTP_PRODUCTS)),
              multiple=True,
              default=FTP_PRODUCTS)
@click.option('--s3-od-prefix', default='s3://lear-exo/zone/staging/od')
@click.option('--s3-ts-prefix', default='s3://lear-exo/zone/staging/ts/gps')
@click.argument('dest_dir')
def fetch(
        dest_dir,
        s3_products_prefix,
        products,
        rabbitmq_server,
        s3_od_prefix,
        s3_ts_prefix):
    start_http_server(3333)
    READY.set(0)
    while(True):
        try:
            parameters = pika.URLParameters(rabbitmq_server)
            connection = pika.BlockingConnection(parameters)
            channel = connection.channel()
            for exchange, product in products:
                if product == "Od":
                    fetcher = DownloadLatestOd(output_dir=os.path.join(
                        dest_dir, 'od'), s3_prefix=s3_od_prefix)
                elif product == "Ts":
                    fetcher = DownloadLatestTs(output_dir=os.path.join(
                        dest_dir, 'ts'), s3_prefix=s3_ts_prefix)
                else:
                    fetcher = DownloadProductsFromS3(
                        dest_dir=os.path.join(dest_dir, product),
                        product=product,
                        s3_products_prefix=s3_products_prefix)
                fetcher()
                on_exchage_message(exchange, channel, fetcher)
            READY.set(1)
            print('waiting')
            channel.start_consuming()
        except KeyboardInterrupt as ex:
            break
        except pika.exceptions.AMQPChannelError as err:
            print("Caught a channel error: {}, stopping...".format(err))
            break
        except pika.exceptions.AMQPConnectionError:
            print("Connection was closed, retrying...")
            continue
