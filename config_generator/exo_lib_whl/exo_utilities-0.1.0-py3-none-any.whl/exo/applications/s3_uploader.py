import click
from exo.utilities.s3_file_archiver import S3FileArchiver, JSON_NAME
from exo.utilities import click_types


@click.group()
def cli():
    """ Uploading a file or directory to S3 using your own credential """
    pass


@cli.command()
@click.option('--label', '-l', type=click_types.Label(), multiple=True,
              help=F"Labels that will be added to {JSON_NAME}")
@click.option('--compress', default=True, type=bool)
@click.argument("source_directory", type=click.Path(exists=True))
@click.argument("s3_logs_path", type=click_types.S3Path())
@click.argument("s3_files_path", type=click_types.S3Path())
def upload(label, *args, **kwargs):
    labels = dict(label)
    S3FileArchiver(labels=labels, *args, **kwargs).upload_directory()


@cli.command()
@click.option('--regex', '-r', default=".*")
@click.argument("s3_files_path", type=click_types.S3Path())
def list(s3_files_path, regex):
    archiver = S3FileArchiver(s3_files_path=s3_files_path)
    regex.split('/')
    search = archiver.search()
    folders = regex.split('/')[:-1]
    for folder in folders:
        search.add_folder(folder_regex=folder, sort_func=lambda x: x)
    search.files(regex.split('/')[-1])
    for m in search:
        print(m)


if __name__ == '__main__':
    cli()
