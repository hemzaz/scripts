import json
import logging
import os
import time
from datetime import datetime, timedelta
from json import dumps
from pathlib import PurePath, PurePosixPath
from collections import namedtuple

import click
from exo.utilities.click_types import DateTime
from exo.utilities.s3 import (download_file, list_files, object_exists,
                              put_tags, write_to_key)
from prometheus_client import push_to_gateway, Gauge, CollectorRegistry, registry

logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


def get_number_of_files_to_retrieve():
    B1_files = 30
    B2_files = 30
    A_files = 1
    return (B1_files + B2_files + A_files) * 2


def get_ensemble_start_date(correction_start_date):
    ensemble_start_hour = correction_start_date.hour // _forecast_step * _forecast_step
    return datetime(
        correction_start_date.year,
        correction_start_date.month,
        correction_start_date.day,
        ensemble_start_hour,
        0,
        0,
        0)


def get_ensemble_end_date(correction_end_date):
    ensemble_end_hour = correction_end_date.hour // _forecast_step * _forecast_step
    ensemble_end_date = datetime(
        correction_end_date.year,
        correction_end_date.month,
        correction_end_date.day,
        ensemble_end_hour,
        0,
        0,
        0)
    if correction_end_date > ensemble_end_date:
        ensemble_end_date += timedelta(hours=_forecast_step)
    return ensemble_end_date


def get_list_of_files_in_S3(complete_path_list):
    files = dict()
    for fp in complete_path_list:
        files_list = list_files(fp)
        for x in files_list:
            files[x] = fp
    return files


_correction_window_in_hours = 1
_forecast_step = 3

patternMatcher = namedtuple(
    "pattern_matcher", ['pattern', "file_type", "time_type"])


class retrieval():
    def _get_complete_path_list(self):
        complete_path_list = []
        for cdl in self._complete_dates_list:
            a_file_path = F'{self._s3_path}/{cdl.strftime("%Y")}/{cdl.strftime("%Y%m%d")}'
            if a_file_path not in complete_path_list:
                complete_path_list.append(a_file_path)
        return complete_path_list

    def _found_good_version(self, versions, files):
        for version in versions:
            files_to_load = self._search_matchings_files(
                files=files, version=version)
            logger.info(
                F'Files_to_load with version {version}: {len(files_to_load)}')
            if len(files_to_load) == get_number_of_files_to_retrieve():
                logger.info(f'All files were found for version {version}')
                return version, files_to_load
        raise Exception('No good version')

    def _if_file_is_not_metadata_file(self, file_name):
        return (PurePosixPath(file_name).suffix[1:]).isdigit()

    def _get_versions_list(self, correction_start_date, current_start_path):
        A_files_list = list_files(
            current_start_path,
            file_prefix=F'{"A"}_{correction_start_date.strftime("%Y%m%d_%H")}.')

        A_files_list = [file_name for file_name in A_files_list if self._if_file_is_not_metadata_file(file_name)]
        versions = [PurePosixPath(f).suffix[1:] for f in A_files_list]
        versions.sort(reverse=True)
        return versions

    def _search_matchings_files(self, files, version):
        files_to_load = dict()
        match_pattern_list = []
        match_pattern_list.append(patternMatcher(pattern=F'A_{self._correction_start_date.strftime("%Y%m%d_%H")}.{version}', file_type="A", time_type="start"))
        match_pattern_list.append(patternMatcher(pattern=F'A_{self._correction_end_date.strftime("%Y%m%d_%H")}.{version}', file_type="A", time_type="end"))
        match_pattern_list.append(patternMatcher(pattern=F'B1_{self._ensemble_start_date.strftime("%Y%m%d_%H")}_*.{version}', file_type="B1", time_type="start"))
        match_pattern_list.append(patternMatcher(pattern=F'B2_{self._ensemble_start_date.strftime("%Y%m%d_%H")}_*.{version}', file_type="B2", time_type="start"))
        match_pattern_list.append(patternMatcher(pattern=F'B1_{self._ensemble_end_date.strftime("%Y%m%d_%H")}_*.{version}', file_type="B1", time_type="end"))
        match_pattern_list.append(patternMatcher(pattern=F'B2_{self._ensemble_end_date.strftime("%Y%m%d_%H")}_*.{version}', file_type="B2", time_type="end"))

        for match_pattern in match_pattern_list:
            for f in files:
                if PurePath(f).match(match_pattern.pattern):
                    files_to_load[f] = dict(s3_path=F"{files[f]}/{f}", name=f, file_type=match_pattern.file_type, time_type=match_pattern.time_type)
        return files_to_load

    def _get_file_names_for_config(self, files_to_load):
        b1_start_files = [x['name'] for x in files_to_load.values(
        ) if x['file_type'] == 'B1' and x['time_type'] == 'start']
        b2_start_files = [x['name'] for x in files_to_load.values(
        ) if x['file_type'] == 'B2' and x['time_type'] == 'start']
        b1_end_files = [x['name'] for x in files_to_load.values(
        ) if x['file_type'] == 'B1' and x['time_type'] == 'end']
        b2_end_files = [x['name'] for x in files_to_load.values(
        ) if x['file_type'] == 'B2' and x['time_type'] == 'end']

        b1_time_1 = dict()
        for c, file_name in enumerate(b1_start_files):
            b1_time_1[F'f_B1_time_1_member_{c+1:02d}'] = file_name

        b2_time_1 = dict()
        for c, file_name in enumerate(b2_start_files):
            b2_time_1[F'f_B2_time_1_member_{c+1:02d}'] = file_name

        b1_time_2 = dict()
        for c, file_name in enumerate(b1_end_files):
            b1_time_2[F'f_B1_time_2_member_{c+1:02d}'] = file_name

        b2_time_2 = dict()
        for c, file_name in enumerate(b2_end_files):
            b2_time_2[F'f_B2_time_2_member_{c+1:02d}'] = file_name

        config_files = dict(
            f_A_time_1=[x for x in files_to_load.values(
            ) if x['file_type'] == 'A' and x['time_type'] == 'start'][0]['name'],
            f_A_time_2=[x for x in files_to_load.values() if x['file_type'] == 'A' and x['time_type'] == 'end'][0]['name'])

        config_files.update(b1_time_1)
        config_files.update(b2_time_1)
        config_files.update(b1_time_2)
        config_files.update(b2_time_2)

        return config_files

    def __init__(self, date_init, s3_path, write_path, registry, labels_dict):
        self._s3_path = s3_path

        correction_start_hour = date_init.hour
        self._correction_start_date = datetime(
            date_init.year,
            date_init.month,
            date_init.day,
            correction_start_hour, 0, 0, 0)
        self._correction_end_date = self._correction_start_date + \
            timedelta(hours=_correction_window_in_hours)

        logger.info(F'correction_start_hour= \t{correction_start_hour}')
        logger.info(
            F'correction_start_date (A) = \t{self._correction_start_date}')
        logger.info(F'correction_end_date (A) = \t{self._correction_end_date}')

        self._ensemble_start_date = get_ensemble_start_date(
            self._correction_start_date)
        self._ensemble_end_date = get_ensemble_end_date(
            self._correction_end_date)

        logger.info(
            F'ensemble_start_date (B1,B2) = \t{self._ensemble_start_date}')
        logger.info(F'ensemble_end_date (B1,B2) = \t{self._ensemble_end_date}')

        # Collect the complete list of dates
        self._complete_dates_list = [
            self._correction_start_date,
            self._correction_end_date,
            self._ensemble_start_date,
            self._ensemble_end_date]
        # We may have more then one folder with forcasts (e.g.
        # ../2021/20210419, ../2021/20210420)
        complete_path_list = self._get_complete_path_list()
        versions = self._get_versions_list(
            correction_start_date=self._correction_start_date, current_start_path=complete_path_list[0])
        logger.info(F'Versions list {versions}')
        logger.info("=" * 30)
        if not versions:
            raise Exception(
                F"No files were found for correction_start_date : {self._correction_start_date}")
        files = get_list_of_files_in_S3(complete_path_list)
        version, files_to_load = self._found_good_version(
            versions=versions, files=files)
        # Count the files for each version (first to have 122 files)
        logger.info(F'Starting to download files for version {version}:')
        for c, f in enumerate(list(files_to_load.values())):
            logger.info(f'[{c+1:3d}]\t name: {f["name"]} \t path: {f["s3_path"]}')
            download_file(key=f['s3_path'], dest_file=os.path.join(
                write_path, f['name']))

        # Update the tags of the downloaded files
        for file in files_to_load.values():
            put_tags(path=file['s3_path'], tags=dict(used="true"))

        version_time = datetime.strptime(version, "%Y%m%d%H")
        version_age_in_hours = int(timedelta.total_seconds(
            self._correction_start_date - version_time)/3600)

        keys = list(labels_dict.keys())
        labels_values = list(labels_dict.values())
        gauge = Gauge('version_age_in_hours', 'version age in hours',
                      labelnames=keys, registry=registry)
        gauge = gauge.labels(*labels_values)
        gauge.set(version_age_in_hours)

        logger.info(f'version_age_in_hours = {version_age_in_hours}')

        config_files = self._get_file_names_for_config(files_to_load)

        with open(os.path.join(write_path, 'metadata.json'), 'w') as s:
            s.write(dumps(
                dict(
                    files=list(files_to_load.values()),
                    config=dict(
                        startdate=F"{self._correction_start_date:%Y-%m-%d %H:%M:%S}",
                        run_init_time=F'{version_time:%Y-%m-%d %H:%M:%S}',
                        version_age_in_hours=F'{version_age_in_hours}',
                        files=config_files))))

        logger.info('Download all files, and tagged them in S3')

def normalized_labels(labels):
    return dict((key.replace('-', '_').replace('/','_'), value)
                for key, value in labels.items())


@click.command()
@click.option('--start-date', type=DateTime(),
              default=F"{datetime.utcnow():%Y-%m-%dT%H:%M:%S}")
@click.option('--s3-path',
              type=str,
              default="s3://lear-exo-foc-staging-tropo-inputs-gefs/v1",
              help="S3 path (e.g. 's3://lear-exo-foc-staging-tropo-inputs-gefs/v1'")
@click.option('--local-path', type=str, default=".",
              help="Local path (e.g. '/tropo'")
@click.option('--pushgateway', default=None, help="gateway url (e.g. 'http://pushgateway.foc-staging.lear-exo.com')")
@click.option('--labels', default="{}", help="Pushgateway labels as json (e.g. '{\"key\":\"value\"}')")
def cli(start_date, s3_path, local_path, pushgateway, labels):
    logger.info("Starting Tropo retrieval:")
    logger.info("=" * 30)
    logger.info('S3-path= %s' % s3_path)
    date_init = start_date
    logger.info(F'start-date= {date_init}')
    registry = CollectorRegistry()
    labels_dict = normalized_labels(json.loads(labels))
    if pushgateway and not labels_dict:
        raise Exception("Please set labels")
    logger.info(F'push_to_gateway = {pushgateway}')
    logger.info(F'Registry = {registry}')

    retrieval(date_init=date_init, s3_path=s3_path,
              write_path=local_path, registry=registry, labels_dict=labels_dict)

    if pushgateway is not None:
        push_to_gateway(pushgateway, job="tropo_retrival", registry=registry)
        logger.info("Connected to the pushgateway")
