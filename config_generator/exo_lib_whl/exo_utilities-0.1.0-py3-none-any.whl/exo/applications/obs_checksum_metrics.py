import click
import json
import datetime
import pandas
from exo.utilities.obs.checksum_statistics import get_stats_from_obs_checkpoint
from pprint import pprint


@click.command()
@click.argument('file')
def cli(file):
    data = json.load(open(file))
    stats = get_stats_from_obs_checkpoint(data)
    pprint(stats)


if __name__ == '__main__':
    cli()
