from boto3.dynamodb.conditions import Key
import click
import boto3
import gzip
from exo.utilities import click_types
from IPython import embed
import json
import binascii
dynamodb = boto3.resource('dynamodb')


def format_datetime_to_dymamodb(data):
    return F"{data:%Y-%m-%dT%H:%M:%S}.000"


def read_obs_from_table(start_date, end_date, station, table):
    items = []
    start_date_str = format_datetime_to_dymamodb(start_date)
    while True:
        x = table.query(KeyConditionExpression=Key('Station').eq(station) & Key(
            'Epoch').between(start_date_str, format_datetime_to_dymamodb(end_date)))
        items = items + x['Items']
        print(start_date_str)
        if len(x['Items']) and 'LastEvaluatedKey' in x:
            start_date_str = x['LastEvaluatedKey']['Epoch']
        else:
            break
    return items


def read_nav_from_table(start_date, end_date, sat_id, table):
    items = []
    start_date_str = format_datetime_to_dymamodb(start_date)
    while True:
        x = table.query(KeyConditionExpression=Key('Id').eq(sat_id) & Key(
            'Epoch').between(start_date_str, format_datetime_to_dymamodb(end_date)))
        items = items + x['Items']
        print(start_date_str)
        if len(x['Items']) and 'LastEvaluatedKey' in x:
            start_date_str = x['LastEvaluatedKey']['Epoch']
        else:
            break
    return items


@click.group()
@click.option('--zone', default="foc-staging")
@click.pass_context
def cli(ctx, zone):
    ctx.ensure_object(dict)
    ctx.obj['zone'] = zone
    pass


@cli.command('obs')
@click.option('--station', required=True)
@click.option('--start-date', type=click_types.DateTime(), required=True)
@click.option('--end-date', type=click_types.DateTime(), required=True)
@click.argument('output_file')
@click.pass_context
def query_obs(ctx, station, start_date, end_date, output_file):
    if start_date >= end_date:
        raise Exception("Start date should be bigger then end_date")

    table = dynamodb.Table(F"{ctx.obj['zone']}Observations")
    items = read_obs_from_table(
        start_date=start_date,
        end_date=end_date,
        station=station,
        table=table)
    for item in items:
        item['data'] = json.loads(gzip.decompress(item['data'].value))
        item['data_source'] = json.loads(item['data_source'])
    with open(output_file, 'w') as f:
        f.write(json.dumps(items))


@cli.command('nav')
@click.option('--start-date', type=click_types.DateTime(), required=True)
@click.option('--end-date', type=click_types.DateTime(), required=True)
@click.option('--sat-id', required=True, help="G01 or J01 or E01")
@click.argument('output_file')
@click.pass_context
def query_nav(ctx, sat_id, start_date, end_date, output_file):
    table = dynamodb.Table(F"{ctx.obj['zone']}Ephemeris")
    if start_date >= end_date:
        raise Exception("Start date should be bigger then end_date")
    items = read_nav_from_table(
        start_date=start_date,
        end_date=end_date,
        sat_id=sat_id,
        table=table)
    for item in items:
        item['data'] = json.loads(item['data'])
        item['data_source'] = json.loads(item['data_source'])
        item['Raw'] = binascii.b2a_hex(item['Raw'].value).decode('utf-8')
    with open(output_file, 'w') as f:
        f.write(json.dumps(items))


if __name__ == '__main__':
    query()
