import click
import yaml
from exo.utilities.s3_file_archiver import S3FileArchiver
from more_itertools import first
import re
from datetime import datetime
import os
import json
import logging
import click_log
import itertools
from functools import partial
from exo.utilities.s3 import get_object
from exo.utilities.s3_file_archiver import uncommpress_file
from exo.calibration.calibration_runs_utils import get_latest_done,get_products_json

logger = logging.getLogger(__name__)
click_log.basic_config(logger)


@click.command()
@click.option('--config', type=click.Path(), required=True)
@click.argument('download_folder', type=click.Path())
@click_log.simple_verbosity_option(logging.getLogger())
def cli(config, download_folder):
    config = yaml.safe_load(open(config))
    RealtimeProductsDownloader(config, download_folder).download()


USER_NOTICE_REGEX = r".*_(\d{4})(\d{3}).txt"


class RealtimeProductsDownloader():

    def __init__(self, config, download_folder):
        self._config = config
        self._now = None
        self._downloading_folder = download_folder
        self._files_to_download_archiver = None
        self._downloaded_files_metadata = None
        self._calibration_products_json = None
        self._extra_files_to_download = None
        self._methods = {
            'antex': {
                "realtime": self._add_latest_antex_file_to_download_queue,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path="^Antex")
            },
            'user_notice': {
                "realtime": self._add_user_notice_to_download_queue_in_the_last_2_years,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path="^(nanu|nagu)")
            },
            'dcb' : {
                "realtime": self._add_latest_dcb_weekly_file_to_download_queue,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=r"^DCB/.*\.DCB"),
            },
            'bsx': {
                "realtime": self._add_latest_bsx_weekly_file_to_download_queue,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=r"^DCB/.*\.BSX"),
            },
            'erp': {
                "realtime" : self._add_first_n_erp_daily_file_to_download_queue,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=r"^ERP/.*\.erp"),
            },
            "sinex": {
                "realtime" : self._add_latest_sinex_weekly_file_to_download_queue,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=r"^Sinex/igs\d{2}P\d{4}\.ssc"),
            },
            "ocean_load": {
                "realtime": self._add_latest_ocean_load_file_to_download_queue,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=r"^olp/"),
            },
            "iri_data_apf_107" : {
                "realtime": self._add_latest_iri_data_apf107,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=r"^iri_data/index/ig_rz.dat"),
            },
            "iri_data_ig_rz" : {
                "realtime": self._add_latest_iri_data_ig_rz,
                'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=r"^iri_data/index/apf107.dat"),
            },
        }
        
        for product in ['ccir','igrf','mcsat','ursi']:
            self._methods[F"iri_data_{product}"]= {
                    "realtime": partial(self._add_all,
                        s3_path_func= partial( lambda config,product: config['products'][F'iri_data_{product}'],
                            config=self._config,product=product),
                        dest_path=os.path.join(
                        "iri_data",product)),
                    'calibration': partial(self._add_files_from_calibration,regex_on_dest_path=rF"^iri_data/{product}/")

                }

    def _add_latest_iri_data_apf107(self,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products'][F"iri_data_apf_107"]['s3_path'])
        latest = first(file_archiver.search().add_folder(r'\d\d\d\d',sort_func=lambda x: int(x)).files(r"\d{6}_apf107.dat"))
        self._append_files_to_download_archiver(
            file_archiver=file_archiver,
            key=latest,
            relative_dest_path=os.path.join("iri_data",'index', "apf107.dat"))
    
    def _add_latest_iri_data_ig_rz(self,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products'][F"iri_data_ig_rz"]['s3_path'])
        latest = first(file_archiver.search().add_folder(r'\d\d\d\d',sort_func=lambda x: int(x)).files(r"\d{6}_ig_rz.dat"))
        self._append_files_to_download_archiver(
            file_archiver=file_archiver,
            key=latest,
            relative_dest_path=os.path.join("iri_data",'index', "ig_rz.dat"))

    def _append_files_to_download_archiver(
            self,
            key,
            relative_dest_path,
            file_archiver):
        self._files_to_download_archiver.append(
            dict(
                key=key,
                relative_dest_path=relative_dest_path,
                file_archiver=file_archiver))

    def _user_notice_sort_function(self, key):
        return re.findall(USER_NOTICE_REGEX, key)[0]

    def _add_user_notice_to_download_queue_in_the_last_2_years(self,**kwargs):
        user_notices_types = ['nanu', 'nagu']
        for user_notice_type in user_notices_types:
            nanu_file_archive = S3FileArchiver(
                s3_files_path=self._config['products'][user_notice_type]['s3_path'])
            for file_name in nanu_file_archive.search().files(
                    USER_NOTICE_REGEX, file_sort_func=self._user_notice_sort_function):
                year, user_notice_count = [
                    int(x) for x in re.findall(
                        USER_NOTICE_REGEX, file_name)[0]]
                if year >= self._now.year - 1:
                    self._append_files_to_download_archiver(
                        file_archiver=nanu_file_archive,
                        key=file_name,
                        relative_dest_path=F"{user_notice_type}/{file_name}")
                else:
                    break

    def _download_files(self):
        for file_to_download in self._extra_files_to_download:
            file_metadata = first(file_to_download['file_metadata']['files'].values())
            s3_location = file_metadata['s3_location']
            content = get_object(s3_location)
            content = uncommpress_file(file_metadata['compress'], content)
            file_full_dest_path = os.path.join(
                self._downloading_folder,
                file_to_download['relative_dest_path'])
            directory = os.path.split(file_full_dest_path)[0]
            os.makedirs(directory,exist_ok=True)
            with open(file_full_dest_path, 'wb') as f:
                f.write(content)
            self._downloaded_files_metadata.append(
                dict(
                    file_metadata=file_to_download['file_metadata'],
                    relative_dest_path=file_to_download['relative_dest_path']))

        for file_to_download in self._files_to_download_archiver:
            logger.info(F'downloading {file_to_download["key"]}')
            downloaded_file = file_to_download['file_archiver'].get_file(
                file_to_download['key'])
            file_full_dest_path = os.path.join(
                self._downloading_folder,
                file_to_download['relative_dest_path'])
            os.makedirs(os.path.split(file_full_dest_path)[0], exist_ok=True)
            with open(file_full_dest_path, 'wb') as f:
                f.write(downloaded_file['data'])
            self._downloaded_files_metadata.append(
                dict(
                    file_metadata=downloaded_file['metadata'],
                    relative_dest_path=file_to_download['relative_dest_path']))

    def _write_metadata_file(self):
        with open(os.path.join(self._downloading_folder, 'metadata.json'), 'w') as f:
            f.write(json.dumps(dict(files=self._downloaded_files_metadata)))

    def _add_latest_antex_file_to_download_queue(self,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products']['antex']['s3_path'])
        latest = first(file_archiver.search().files(r"igs14_\d\d\d\d.atx"))
        self._append_files_to_download_archiver(
            file_archiver=file_archiver,
            key=latest,
            relative_dest_path=os.path.join("Antex", F"{latest}"))

    def _add_latest_dcb_weekly_file_to_download_queue(self,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products']['dcb']['s3_path'])
        latest = first(
            file_archiver.search().add_folder(
                folder_regex=r"\d{4}",
                sort_func=lambda x: int(x)).files(r"P1C1\d\d\d\d.DCB"))
        self._append_files_to_download_archiver(
            file_archiver=file_archiver,
            key=latest,
            relative_dest_path=os.path.join("DCB", latest.split('/')[-1]))

    def _add_latest_bsx_weekly_file_to_download_queue(self,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products']['bsx']['s3_path'])
        latest = first(
            file_archiver.search().add_folder(
                folder_regex=r"\d{4}",
                sort_func=lambda x: int(x)).files(r"CAS0MGXRAP_\d{11}_01D_01D_DCB\.BSX"))
        self._append_files_to_download_archiver(
            file_archiver=file_archiver,
            key=latest,
            relative_dest_path=os.path.join("DCB", latest.split('/')[-1]))

    def _add_first_n_erp_daily_file_to_download_queue(self, number_of_days,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products']['erp']['s3_path'])
        latest_n = itertools.islice(
            file_archiver.search().add_folder(
                folder_regex=r"\d{4}",
                sort_func=lambda x: int(x)).files(r"igr\d\d\d\d\d.erp"), number_of_days)
        for key in latest_n:
            self._append_files_to_download_archiver(
                file_archiver=file_archiver,
                key=key,
                relative_dest_path=os.path.join("ERP", key.split('/')[-1]))

    def _add_latest_sinex_weekly_file_to_download_queue(self,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products']['sinex']['s3_path'])
        latest = first(
            file_archiver.search().add_folder(
                folder_regex=r"\d{4}",
                sort_func=lambda x: int(x)).files(r"igs\d{2}P\d{4}.ssc"))
        self._append_files_to_download_archiver(
            file_archiver=file_archiver,
            key=latest,
            relative_dest_path=os.path.join("Sinex", latest.split('/')[-1]))

    def _add_latest_ocean_load_file_to_download_queue(self,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=self._config['products']['ocean_load']['s3_path'])
        latest = first(file_archiver.search().files(
            r"\d\d\d\d-\d\d-\d\d-oload_EXO.blq"))
        self._append_files_to_download_archiver(
            file_archiver=file_archiver,
            key=latest,
            relative_dest_path=os.path.join(
                "olp",
                'oload_EXO.blq'))

    def _calib_products_json(self):
        if not self._calibration_products_json:
            self._calibration_products_json = get_products_json(os.environ["CALIBRATION_S3_PATH"])
        return self._calibration_products_json


    def _add_files_from_calibration(self,regex_on_dest_path,**kwargs):
        calib_products_json = self._calib_products_json()
        files = [file_info for file_info in calib_products_json['files'] if re.findall(regex_on_dest_path,file_info['relative_dest_path'])]
        self._extra_files_to_download.extend(files)

    def _add_all(self,s3_path_func,dest_path,**kwargs):
        file_archiver = S3FileArchiver(
            s3_files_path=s3_path_func()['s3_path'])
        for key in file_archiver.search().files(".*"):
            self._append_files_to_download_archiver(
                file_archiver=file_archiver,
                key=key,
                relative_dest_path=os.path.join(
                    dest_path,
                    key))
        
    def download(self):
        self._files_to_download_archiver = []
        self._extra_files_to_download = []
        self._downloaded_files_metadata = []
        self._now = datetime.utcnow()
        for item in self._config['downloads']:
            self._methods[item['type']][item['source']](**item)
        self._download_files()
        self._write_metadata_file()
