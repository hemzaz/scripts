import click
import logging
from exo.utilities.s3_diff_saver import s3_diff_saver
logging.getLogger().setLevel(logging.INFO)


@click.group()
def cli():
    pass


@cli.command()
@click.option('--exculde')
@click.argument('folder')
@click.argument('diff_folder')
@click.argument('s3_path')
def save(folder, diff_folder, exculde, s3_path):
    s3_diff_saver(folder, diff_folder, exculde=exculde).create_diff(s3_path)


@cli.command()
@click.argument('folder')
@click.argument('s3_path')
def recreate(folder, s3_path):
    s3_diff_saver(folder, None).recreate(s3_path)
