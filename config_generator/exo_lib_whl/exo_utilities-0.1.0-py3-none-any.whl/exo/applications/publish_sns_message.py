#!/usr/bin/env python3
import os
import click
import boto3


@click.command()
@click.argument('message')
@click.option('-t', '--topic', required=True)
@click.option('-r', '--region', default='us-east-2')
def publish_sns_message(message, region, topic):
    # Create an SNS client
    sns = boto3.client('sns', region_name=region)

    # Publish a simple message to the specified SNS topic
    response = sns.publish(
        TopicArn=topic,
        Message=message,
    )

    # Print out the response
    click.echo(response)


if __name__ == "__main__":
    publish_sns_message()
