import io
import logging
import os
import json
from abc import ABC, abstractmethod, abstractproperty
from datetime import datetime, timedelta

import requests
from retrying import retry
from exo.utilities.s3 import object_exists, write_to_key
logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

class FileGotEmpty(Exception):
    pass

def retry_if_file_empty_exception(exception):
    return isinstance(exception, FileGotEmpty)


class TropoFile(ABC):
    def __init__(
            self,
            s3_path,
            partial_load,
            force_writing_on_S3,
            save_local,
            current_run_date):
        self._s3_path = s3_path
        self._partial = partial_load
        self._force = force_writing_on_S3
        self._save_local = save_local
        self._current_run_date = current_run_date

# region abstract methods and properties
    @property
    def _file_path(self):
        pass

    @property
    def _file_type(self):
        pass

    @property
    def _min_forecast(self):
        pass

    @property
    def _max_forecast(self):
        pass

    @property
    def _min_member(self):
        pass

    @property
    def _max_member(self):
        pass

    @abstractmethod
    def get_file_name_for_type(self, forecast):
        pass

    @abstractmethod
    def get_remote_file_name(self, forecast):
        pass

    @abstractmethod
    def save(self):
        pass


    def _get_default_metadata_tags(self):
        tags = json.loads(os.environ.get('LABELS_JSON','{}'))
        pod_name = os.environ.get('POD_NAME','')
        if pod_name:
            tags['pod_name'] = pod_name
        node_name = os.environ.get('NODE_NAME','')
        if node_name:
            tags['node_name'] = node_name
        return tags


    def write_to_key(self,data, path,remote_path):
        write_to_key(data,path=path,tags= dict(used="false"))
        write_to_key(json.dumps(dict(tags=  self._get_default_metadata_tags(),remote_path = remote_path)),path =F"{path}.metadata")


    @retry(stop_max_attempt_number=8,wait_exponential_multiplier=100, wait_exponential_max=60000,retry_on_exception=retry_if_file_empty_exception)
    def download_file(self, file_name):
        with requests.get(file_name, stream=True) as r:
            r.raise_for_status()
            data = io.BytesIO()

            for chunk in r.iter_content(chunk_size=int(1e6)):
                data.write(chunk)
                if self._partial:
                    return data
            if data.tell()<=0:
                raise FileGotEmpty("Sorry {file_name} got empty")
            return data


class TropoFileA(TropoFile):

    @property
    def _file_path(self):
        A_FILE_PATH = "https://nomads.ncep.noaa.gov/pub/data/nccf/com/gfs/prod/"
        return F'{A_FILE_PATH}gfs.{self._current_run_date.strftime("%Y%m%d")}/{self._current_run_date.hour:02d}/atmos/'

    @property
    def _file_type(self):
        return "A"

    @property
    def _min_forecast(self):
        return 6


    @property
    def _max_forecast(self):
        return 19

    def get_file_name_for_type(self, forecast):
        local_file_date = self._current_run_date
        local_file_date += timedelta(hours=forecast)
        local_file_name = F'{local_file_date.strftime("%Y")}/{local_file_date.strftime("%Y%m%d")}/{self._file_type}_{local_file_date.strftime("%Y%m%d_%H")}.{self._current_run_date.strftime("%Y%m%d%H")}'
        return local_file_name

    def get_remote_file_name(self, forecast):
        return F'gfs.t{self._current_run_date.hour:02d}z.pgrb2.0p25.f{forecast:03d}'

    def save(self):
        logger.info(F'Folder name {self._file_type}: {self._file_path}')
        for forecast in range(self._min_forecast, self._max_forecast + 1):
            file_name = self.get_remote_file_name(forecast)
            local_file_name = self.get_file_name_for_type(forecast)

            if self._save_local:
                file_name_to_write = local_file_name
            else:
                file_name_to_write = F'{self._s3_path}/{local_file_name}'
                # If the file exists - continue
                if self._force == False and object_exists(file_name_to_write):
                    logger.info(F'File already exists: {file_name_to_write}')
                    continue

            # TODO: Use python retrying library
            try:
                data = self.download_file(self._file_path + file_name)
                data.seek(0)
            except Exception as err:
                logger.warning(F'Could not download the file: {err}')
                continue

            if self._save_local:
                # Verify that the daily folder exists
                # from IPython import embed; embed()
                dest_folder = os.path.split(local_file_name)[0]
                if not os.path.exists(dest_folder):
                    os.makedirs(dest_folder, exist_ok=True)
                open(file_name_to_write, 'wb').write(data.read())
            else:
                # save to S3
                self.write_to_key(data, path=file_name_to_write,remote_path = self._file_path + file_name)

            logger.info(
                F'The source file:\t {file_name} Saved to:\t{file_name_to_write}')


class TropoFileB(TropoFile):

    @property
    @abstractmethod
    def _file_path(self):
        pass

    @property
    @abstractmethod
    def _file_type(self):
        pass

    @property
    def _min_forecast(self):
        return 6

    @property
    def _max_forecast(self):
        return 21

    @property
    def _forecast_step(self):
        return 3

    @property
    def _min_member(self):
        return 1

    @property
    def _max_member(self):
        return 30

    def get_file_name_for_type(self, forecast, member):
        local_file_date = self._current_run_date
        local_file_date += timedelta(hours=forecast)
        local_file_name = F'{local_file_date.strftime("%Y")}/{local_file_date.strftime("%Y%m%d")}/{self._file_type}_{local_file_date.strftime("%Y%m%d_%H")}_{member:02d}.{self._current_run_date.strftime("%Y%m%d%H")}'
        return local_file_name

    @abstractmethod
    def get_remote_file_name(self, forecast, member):
        pass

    def save(self):
        logger.info(F'Folder name {self._file_type}: {self._file_path}')
        for member in range(self._min_member, self._max_member + 1):
            for forecast in range(
                    self._min_forecast,
                    self._max_forecast + 1,
                    self._forecast_step):
                file_name = self.get_remote_file_name(forecast, member)
                local_file_name = self.get_file_name_for_type(forecast, member)

                if self._save_local:
                    file_name_to_write = local_file_name
                else:
                    file_name_to_write = F'{self._s3_path}/{local_file_name}'
                    # If the file exists - continue
                    if self._force == False and object_exists(
                            file_name_to_write):
                        logger.info(
                            F'File already exists: {file_name_to_write}')
                        continue

                # TODO: Use python retrying library
                try:
                    data = self.download_file(self._file_path + file_name)
                    data.seek(0)
                except Exception as err:
                    logger.warn(F'Could not download the file: {err}')
                    continue

                if self._save_local:
                    # from IPython import embed; embed()
                    # Verify that the daily folder exists
                    dest_folder = os.path.split(local_file_name)[0]
                    if not os.path.exists(dest_folder):
                        os.makedirs(dest_folder, exist_ok=True)
                    open(file_name_to_write, 'wb').write(data.read())
                else:
                    self.write_to_key(data, path=file_name_to_write,
                        remote_path = self._file_path + file_name)

                logger.info(
                    F'The source file:\t {file_name} Saved to:\t{file_name_to_write}')


class TropoFileB1(TropoFileB):

    @property
    def _file_path(self):
        B_FILE_PATH = "https://nomads.ncep.noaa.gov/pub/data/nccf/com/gens/prod/"
        return F'{B_FILE_PATH}gefs.{self._current_run_date.strftime("%Y%m%d")}/{self._current_run_date.hour:02d}/atmos/pgrb2ap5/'

    @property
    def _file_type(self):
        return "B1"

    def get_remote_file_name(self, forecast, member):
        return F'gep{member:02d}.t{self._current_run_date.hour:02d}z.pgrb2a.0p50.f{forecast:03d}'


class TropoFileB2(TropoFileB):

    @property
    def _file_path(self):
        B_FILE_PATH = "https://nomads.ncep.noaa.gov/pub/data/nccf/com/gens/prod/"
        return F'{B_FILE_PATH}gefs.{self._current_run_date.strftime("%Y%m%d")}/{self._current_run_date.hour:02d}/atmos/pgrb2bp5/'

    @property
    def _file_type(self):
        return "B2"

    def get_remote_file_name(self, forecast, member):
        return F'gep{member:02d}.t{self._current_run_date.hour:02d}z.pgrb2b.0p50.f{forecast:03d}'
