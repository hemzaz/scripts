
from . dal import Dal
from . app import flask_app



import boto3
sns = boto3.resource('sns')

import datetime


def _on_change(sns_topic):
  print(sns_topic.publish(Message="Something Changed"))

DAL = None
import click
import yaml
from functools import partial
@click.command()
@click.option('--config',required=True)
def cli(config):
  global DAL
  config = yaml.safe_load(open(config).read())
  app.DAL = Dal(config)
  app.on_change = partial(_on_change,sns.Topic(config['topics']['on_active_calibration_changed_sns_arn']))
  flask_app.run(host= '0.0.0.0',debug=True)
