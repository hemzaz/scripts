
from flask import Flask,abort
from flask_restplus import Api, Resource
from flask_restplus import fields
from .dal import AlreadyExistsException, NoActiveCalibrationException
import json
from flask import abort
from datetime import datetime
flask_app = Flask(__name__)
api = Api(app = flask_app)

ns = api.namespace('api', description='Main APIs')

DAL = None
on_change = None
def _on_change():
  if on_change!=None:
    on_change()


calibration = api.model('Calibration', {
    'active_start_time': fields.String,
    'configuration_id' : fields.String,
    'json_data': fields.String,
})

short_calibration = api.model('short_calibration', {
    'active_start_time': fields.String,
    'configuration_id' : fields.String,
})

history_request = api.model('history_request', {
    'start_time': fields.String,
    'end_time': fields.String,
})

def dal_to_configuration(dal_object):
  return dict(
    active_start_time = dal_object['ActiveStartTime'],
    configuration_id  = dal_object['ConfigurationID'],
    json_data = dal_object['DATA'])

@ns.route("/health")
class health(Resource):
  def get(self):
    return "OK",200


@ns.route("/active")
class active(Resource):
  @ns.marshal_list_with(calibration)
  def get(self):
    try:
      return dal_to_configuration(DAL.get_active())
    except NoActiveCalibrationException as ex:
      abort(400, 'No Active calibration set')
    


  
  @ns.expect(calibration)
  def put(self):
    try:
      DAL.add(time=datetime.strptime(api.payload['active_start_time'],'%Y-%m-%dT%H:%M:%S'),
           data = json.loads(api.payload['json_data']), configuration_id=api.payload['configuration_id'])
      _on_change()
    except AlreadyExistsException as ex:
      abort(403,ex)
    return {},201




@ns.route("/history")
class history(Resource):
  @ns.marshal_list_with(short_calibration)
  @ns.expect(history_request)
  def put(self):
    start_time = datetime.strptime(api.payload['start_time'],'%Y-%m-%dT%H:%M:%S')
    end_time = datetime.strptime(api.payload['end_time'],'%Y-%m-%dT%H:%M:%S')
    data = DAL.get_history(start_time = start_time,end_time = end_time)
    return data

