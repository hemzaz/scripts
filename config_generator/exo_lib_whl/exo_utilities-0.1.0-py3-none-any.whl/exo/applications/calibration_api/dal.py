from flask import abort
import boto3
import json
from datetime import timedelta
from boto3.dynamodb.conditions import Key
dynamodb = boto3.resource('dynamodb')


class AlreadyExistsException(Exception):
  pass

class NoActiveCalibrationException(Exception):
  pass

class Dal:
  def __init__(self,config):
    self.active_calibrations_table = dynamodb.Table(config['tables']['active_calibrations_table_arn'].split('/')[-1])


  def add(self, time, configuration_id, data):
    try:
      response = self.active_calibrations_table.put_item(
         Item={
                'Id': "active",
                'ActiveStartTime':time.isoformat(),
                'ConfigurationID': configuration_id,
                'DATA' : json.dumps(data),
              },
        ConditionExpression='attribute_not_exists(Id)'
      )
    except dynamodb.meta.client.exceptions.ConditionalCheckFailedException:
      raise ConfigurationAlreadyExistsException(F"Configuration Allready exists: id {time}")


  def get_active(self):
    response = self.active_calibrations_table.query(
        KeyConditionExpression=Key('Id').eq('active'),
        ScanIndexForward=False,
        Limit=1
    )
    if len(response['Items'])==0:
      raise NoActiveCalibrationException()
    return response['Items'][0]

  def get_history(self,start_time,end_time):
    if end_time < start_time:
      abort(400,"start_time > endtime")
#    if end_time - start_time > timedelta(days=90):
#      abort(400,"request to long max time is 90 days")
    first_response = self.active_calibrations_table.query(Limit=1,ScanIndexForward=False,
        KeyConditionExpression=(Key('Id').eq('active') & Key('ActiveStartTime').lt(date_to_isodate(start_time))),
    )
    data = [dict(active_start_time = item['ActiveStartTime'],configuration_id=item['ConfigurationID']) for item in first_response['Items']]
    response = self.active_calibrations_table.query(
        KeyConditionExpression=(Key('Id').eq('active') & Key('ActiveStartTime').between(date_to_isodate(start_time), date_to_isodate(end_time))),
    )
    return data + [dict(active_start_time = item['ActiveStartTime'],configuration_id=item['ConfigurationID']) for item in response['Items']]
    
  def list_all_active_configuration(self):
    data = self.active_calibrations_table.query(IndexName='Active',KeyConditionExpression=Key('Active').eq('true'))
    return dict([(item['Id'],item) for item in data['Items']])

def date_to_isodate(date):
    return F"{date:%Y-%m-%dT%H:%M:%S}"