import requests
import json
from datetime import datetime


class NoActiveCalibrationSet(Exception):
    pass
KNOWN_RESPONSES = {
         400 : {
                "No Active calibration set": NoActiveCalibrationSet
         }
            
        }

def _check_response(response):
    if response.status_code in KNOWN_RESPONSES and 'message' in response.json() and \
        response.json()['message'] in KNOWN_RESPONSES[response.status_code]:
        raise KNOWN_RESPONSES[response.status_code][response.json()['message']]()
    response.raise_for_status()

        

class Api:
    def __init__(self, hostname):
        
        self._hostname = hostname

    def get_current(self):
        response = requests.get(F"{self._hostname}/api/active")
        _check_response(response)
        response.raise_for_status()
        return response.json()

    def get_history(self,start_time,end_time):
        response = requests.put(F"{self._hostname}/api/history",json = dict(
            start_time=F"{start_time:%Y-%m-%dT%H:%M:%S}",
            end_time=F"{end_time:%Y-%m-%dT%H:%M:%S}"))
        _check_response(response)
        return response.json()

    def set_current(self, configuration_id, data):
        data = {
            "configuration_id": configuration_id,
            "active_start_time": datetime.utcnow().isoformat().split('.')[0],
            "json_data": json.dumps(data),
        }

        url = F"{self._hostname}/api/active"
        response = requests.put(url, json=data)
        _check_response(response)


#if __name__ == '__main__':
#    x = Api('http://active-calibration.foc-staging.lear-exo.com')
#    from datetime import timedelta
#    now = datetime.utcnow()
#    print(x.get_history(start_time = now-timedelta(days=1),end_time  = now))