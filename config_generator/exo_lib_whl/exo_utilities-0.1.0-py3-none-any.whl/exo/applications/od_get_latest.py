import click
from datetime import datetime
from IPython import embed;
from exo.utilities import s3
import tarfile
import io
import os
import json
import shutils


class Searcher:
  def __init__(self,calibration_id,od_s3_prefix):
      self._calibration_id = calibration_id
      self._calibration_time = datetime.strptime(calibration_id,"%Y-%m-%dT%H-%M-%S")
      self._calibration_s3_path = F"{od_s3_prefix}/{self._calibration_time:%Y/%m}/{self._calibration_id}"
  
  def get_latest_od_for_calibration(self):
      all_dirs = s3.list_dir(self._calibration_s3_path)
      all_dirs.sort(reverse=True)
      sucessful_runs = [F"{self._calibration_s3_path}/{dir_name}" for dir_name in all_dirs if s3.object_exists(F"{self._calibration_s3_path}/{dir_name}/summary.json")]
      if not sucessful_runs:
        raise Exception("not valid runs")
      return sucessful_runs[0]

  def downloader(self,output_path,run_s3_path):
      data = s3.get_object(F'{run_s3_path}/merge.tar.gz')
      tar_open = tarfile.open(fileobj=io.BytesIO(data))
      tar_open.extractall(path=output_path)
      run_info = s3.get_object(F'{run_s3_path}/run_info.json')
      with open(os.path.join(output_path,'metadata.json.temp'),'wb') as f:
        f.write(run_info)
      os.rename(os.path.join(output_path,'metadata.json.temp'),os.path.join(output_path,'metadata.json'))

@click.command()
@click.option('--od-s3-prefix',default="s3://lear-exo-foc-staging-ssr-od/runs-v3")
@click.option('--calibration-id',default="2021-03-31T00-00-00")
@click.option('--output-path',default="/tmp/output")
def cli(od_s3_prefix,calibration_id,output_path):
  os.makedirs(output_path,exist_ok=True)
  latest_old_run = max([ int(x) for x in os.listdir(output_path)]  + [-1])
  searcher = Searcher(calibration_id=calibration_id,od_s3_prefix = od_s3_prefix)
  current_latest = searcher.get_latest_od_for_calibration()
  need_to_download=True
  try:
    old_json_data=json.load(open(os.path.join(output_path,F"{latest_old_run:04}",'metadata.json')))
    if  old_json_data['s3_run_path'] == current_latest:
      need_to_download = False
  except:
    pass
  if need_to_download:
    searcher.downloader(output_path=os.path.join(output_path,F"{latest_old_run + 1:04}"),run_s3_path= current_latest)





  pass