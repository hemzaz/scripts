from flask_restplus import fields
from flask_restplus import Resource, Namespace

ns = Namespace('sync_id', description='Main APIs')
from datetime import datetime
history_request = ns.model('history_request', {
    'start_time': fields.String,
    'end_time': fields.String,
})

sync_id = ns.model('sync_id', {
    'id': fields.String,
})


range_result_item = ns.model('range_result_item', {
    'active_start_time': fields.String,
    'sync_id': fields.String,
})

@ns.route("/current")
class current_id(Resource):
  @ns.marshal_with(sync_id)
  def get(self):
    return dict(id = get_dal().get_current_calibration_id())

@ns.route("/range")
class range(Resource):
  @ns.marshal_list_with(range_result_item)
  @ns.expect(history_request)
  def put(self):
    start_time = datetime.strptime(ns.payload['start_time'],'%Y-%m-%dT%H:%M:%S')
    end_time = datetime.strptime(ns.payload['end_time'],'%Y-%m-%dT%H:%M:%S')
    return get_dal().get_history(start_time=start_time,end_time=end_time)