from . app import api
from datetime import datetime
from flask_restplus import  Resource, Namespace,fields

ns = Namespace('ssr', description='Main APIs')

history_request = ns.model('history_request', {
    'start_time': fields.String,
    'end_time': fields.String,
})


ssr_orbit_info = ns.model('ssr_orbit_info',dict(
          delta_radial_m = fields.Float,
          delta_along_track_m = fields.Float,
          delta_cross_track_m = fields.Float,
          dot_delta_radial_m_sec = fields.Float,
          dot_delta_along_track_m_sec = fields.Float,
          dot_delta_cross_track_m_sec = fields.Float,

  ))

ssr_clocks_info = ns.model('ssr_clocks_info',dict(
          delta_clock_c0_m = fields.Float,
          delta_clock_c1_m_sec= fields.Float,
          delta_clock_c2_m_sec2= fields.Float,
  ))

ssr_sat_info = ns.model('ssr_sat_info',dict(
          clock = fields.Nested(ssr_clocks_info),
          orbit = fields.Nested(ssr_orbit_info),
          sat_id = fields.String,
          nav_id = fields.String,
  ))

ssr_item = ns.model('ssr_item',dict(
          sats_info = fields.List(fields.Nested(ssr_sat_info)),
          time = fields.String,
          s3_source_path = fields.String,
  ))

ssr_response =  ns.model('ssr_response',dict(
      data=fields.List(fields.Nested(ssr_item))
    ))

#mw_response = ns.model('mw_response', dict(
#    sats_info =  fields.List(fields.Nested(mw_item)))
#)

@ns.route("/ssr/<string:calibration_id>")
class ssr(Resource):
  @ns.expect(history_request)
  @ns.marshal_with(ssr_response)
  def put(self,calibration_id):
    start_time = datetime.strptime(api.payload['start_time'],'%Y-%m-%dT%H:%M:%S')
    end_time = datetime.strptime(api.payload['end_time'],'%Y-%m-%dT%H:%M:%S')
    data = get_dal().get_corrections(calibration_id=calibration_id,start_time=start_time,end_time=end_time)
    items = []
    for key,value in data.items():
      sats_info = []
      for sat_id,sat_data in value['sats_info'].items():
        sat_data['sat_id'] = sat_id
        sats_info.append(sat_data)
      value['time'] = datetime.strftime(key,'%Y-%m-%dT%H:%M:%S')
      value['sats_info'] = sats_info
      items.append(value)
    return dict(data=items)
