from . app import api
from datetime import datetime
from flask_restplus import  Resource, Namespace,fields

ns = Namespace('on_new_data', description='Main APIs')

dal = None
@ns.route("/on_new_data_sns")
class on_new_data_sns(Resource):
  def get(self):
    return { "arn": get_dal().on_new_data_sns_arn()}
    
