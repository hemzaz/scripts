from flask_restplus import  Resource, Namespace,fields
ns = Namespace('sync_data', description='Main APIs')

x_y_model = ns.model('x_y', dict(
     x = fields.Float,
     y = fields.Float
    ))

short_calibration = ns.model('short_calibration', {
    'active_start_time': fields.String,
    'configuration_id' : fields.String,
})



mw_signal_info = ns.model('mw_signal_info',dict(
          phase_bias_m =fields.Float,
          signal_integer_indicator= fields.Integer,
          signal_wide_lane_integer_indicator = fields.Integer,
          signal_discontinuity_counter = fields.Integer,
          signal= fields.String,
          rinex_signal_id = fields.String,
  ))
mw_item = ns.model('mw_item',dict(
  signals_info= fields.List(fields.Nested(mw_signal_info)),
   yaw_angle_deg = fields.Float,
   yaw_rate_deg_s = fields.Float,
   sat_id = fields.String,
   dispersive_bias_consistency_indicatory =fields.Integer,
   mw_consistency_indicator = fields.Integer,
  ))

mw_response = ns.model('mw_response', dict(
    sats_info =  fields.List(fields.Nested(mw_item)))
)

code_bias_signal_item = ns.model('code_bias_signal_item', dict(
     code_bias_m = fields.Float,
     signal_id = fields.String,
     rinex_signal_id = fields.String,
    ))

code_bias_model = ns.model('code_bias_model', dict(
     signals_info = fields.List(fields.Nested(code_bias_signal_item)),
     sat_id = fields.String
    ))
code_bias_response =  ns.model('code_bias_response',dict(
      data=fields.List(fields.Nested(code_bias_model))
    ))
apc_signals_info = ns.model('apc_signals_info',dict(
      signal=fields.String,
      rinex_signal_id =fields.String,
      bias = fields.Nested(x_y_model),
      sigma = fields.Nested(x_y_model),
    ))
apc_sat_info = ns.model('apc_sat_info',dict(
      sat_id=fields.String,
      signals_info = fields.List(fields.Nested(apc_signals_info))
    ))
apc_response =  ns.model('apc_response',dict(
      data=fields.List(fields.Nested(apc_sat_info))
    ))

iono_delta_code_bias_item = ns.model('iono_delta_code_bias_item', dict(
     signal_id = fields.String,
     rinex_signal_id = fields.String,
     code_bias_m = fields.Float,
     sigma_code_bias_m = fields.Float,
    ))

iono_delta_code_bias_model = ns.model('iono_delta_code_bias_model', dict(
     signals_info = fields.List(fields.Nested(iono_delta_code_bias_item)),
     sat_id = fields.String
    ))
iono_delta_code_bias_response = ns.model('iono_delta_code_bias_response',dict(
      data=fields.List(fields.Nested(iono_delta_code_bias_model))
    ))

@ns.route('/mw/<string:sync_id>')
class mw(Resource):
  @ns.marshal_with(mw_response)
  def get(self,sync_id):
    return {'sats_info':get_dal().get_mw(sync_id)}

@ns.route('/apc/<string:sync_id>')
class apc(Resource):
  @ns.marshal_with(apc_response)
  def get(self,sync_id):
    x =get_dal().get_apc(sync_id)
    return dict(data=x)

@ns.route('/dcb/<string:sync_id>')
class dcb(Resource):
  @ns.marshal_with(code_bias_response)
  def get(self,sync_id):
    return dict(data=get_dal().get_dcb(sync_id))

@ns.route('/iono_code_bias/<string:sync_id>')
class iono_code_bias(Resource):
  @ns.marshal_with(iono_delta_code_bias_response)
  def get(self,sync_id):
    data = get_dal().get_iono_delta_code_bias(sync_id)
    return dict(data=data)

modipmap_response =  ns.model('modipmap_response',dict(
      dateValidityStart = fields.String,
      dateValidityEnd = fields.String,
      magneticPoleLat = fields.Float,
      magneticPoleLon  = fields.Float,
      latitude_resolution =fields.Integer,
      longitude_resolution = fields.Integer,
      modipMap =fields.List( fields.Float),
    ))

@ns.route('/modipmap/<string:sync_id>')
class modipmap(Resource):
  @ns.marshal_with(modipmap_response)
  def get(self,sync_id):
    data = get_dal().get_modipmap(sync_id)
    return data







