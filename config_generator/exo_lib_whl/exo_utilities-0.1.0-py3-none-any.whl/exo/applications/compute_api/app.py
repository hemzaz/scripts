
from flask import Flask,abort
from flask_restplus import Api, Resource,reqparse
from flask_restplus import fields
from flask_restplus.fields import datetime_from_iso8601
import json
from flask import abort
from datetime import datetime
from json import JSONEncoder
_DAL = None
import flask
class DateTimeEncoder(JSONEncoder):
        #Override the default method
        def default(self, obj):
            if isinstance(obj, (date, datetime)):
                return F"{obj:%Y-%m-%dT%H:%M:%S}"

def get_dal():
  return _DAL
  
flask_app = Flask(__name__)
api = Api(app = flask_app)
flask_app.config['RESTPLUS_JSON'] = {'cls': DateTimeEncoder}
from ..compute_api import sync_ns, general_ns, sync_data_ns, ssr_ns, nav_ns, tropo_ns,on_new_data
sync_ns.get_dal = get_dal
sync_data_ns.get_dal = get_dal
ssr_ns.get_dal = get_dal
nav_ns.get_dal = get_dal
tropo_ns.get_dal = get_dal
on_new_data.get_dal = get_dal
api.add_namespace(general_ns.ns,path = "/v1/general")
api.add_namespace(sync_ns.ns,path = "/v1/sync_api")
api.add_namespace(sync_data_ns.ns,path = "/v1")
api.add_namespace(ssr_ns.ns,path = "/v1")
api.add_namespace(nav_ns.ns,path = "/v1")
api.add_namespace(tropo_ns.ns,path = "/v1")
api.add_namespace(on_new_data.ns,path = "/v1")