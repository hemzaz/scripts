from . app import api
from datetime import datetime
from flask import redirect
from flask_restplus import  Resource, Namespace,fields

ns = Namespace('tropo', description='Main APIs')

@ns.route("/tropo/<string:year>/<string:month>/<string:day>/<string:hour>/output.tar.gz")
class tropo(Resource):
  def get(self,year,month,day,hour):
    time = datetime(*[ int(i) for i in  [year,month,day,hour]])
    x = get_dal().get_tropo_results(time = time)
    return redirect(x,302)
