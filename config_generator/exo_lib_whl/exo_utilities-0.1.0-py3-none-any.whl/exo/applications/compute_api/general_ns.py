from . app import api
from flask_restplus import  Resource, Namespace
ns = Namespace('general', description='Main APIs')



@ns.route("/health")
class health(Resource):
  def get(self):
    return "OK",200
