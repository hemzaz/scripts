from . app import api
from datetime import datetime
from flask_restplus import  Resource, Namespace,fields

ns = Namespace('ephemeris', description='Main APIs')


ephemeris_flavor = ns.model('ephemeris_flavor', {
    'flavor': fields.String,
})
@ns.route("/nav/<string:sat_id>/<string:unique_id>")
class nav(Resource):
  @ns.expect(ephemeris_flavor)
  def put(self,sat_id,unique_id):
    flavor = api.payload.get('flavor','')
    data = get_dal().get_nav(sat_id=sat_id,unique_id=unique_id,flavor=flavor)
    return data

@ns.route("/nav_latest/<string:sat_id>")
class latest(Resource):
  @ns.expect(ephemeris_flavor)
  def put(self,sat_id):
    flavor = api.payload.get('flavor','')
    data = get_dal().get_nav_latest(sat_id=sat_id,flavor=flavor)
    return data