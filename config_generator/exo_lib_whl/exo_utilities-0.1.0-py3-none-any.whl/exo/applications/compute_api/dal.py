from deepmerge import always_merger
from exo.utilities.bias_reader import *
from exo.utilities.bias_reader import dcb_bias_reader, sigma_bias_reader
from flask import abort
import json
import re
from datetime import timedelta
import flask.logging as logging
import requests
import logging
from exo.utilities import s3
from exo.utilities.bias_reader import mw_bais_reader
import tarfile
import io
import functools
from exo.ssr.utils import CorrectionsFetcher
from boto3.dynamodb.conditions import Key
from exo.applications.calibration_api.api import Api as CalibrationApi
import boto3
from flask import abort
cache = functools.partial(functools.lru_cache, 4)




class Dal:
    def __init__(self, config):
        self._active_calibration_api = CalibrationApi(config['active_calibration_api'])
        self._calibration_s3_path = config['calibration_s3_path']
        self._tropo_s3_path = config['tropo_s3_path']
        self._on_new_data_sns_arn = config['on_new_data_sns_arn']
        self._ssr_correction_fetcher = CorrectionsFetcher(config['ts_s3_path'])
        dynamodb = boto3.resource('dynamodb')
        self._nav_table = dynamodb.Table(config['nav_dynamo_db_arn'].split('/')[1]) 

    def on_new_data_sns_arn(self):
      return self._on_new_data_sns_arn


    def get_current_calibration_id(self):
        data =self._active_calibration_api.get_current()
        return data['configuration_id']
    
    def get_history(self,start_time,end_time):
        data = self._active_calibration_api.get_history(start_time=start_time,end_time=end_time)
        for x in data:
            x['sync_id'] = x['configuration_id']
            del x['configuration_id']
        return data
        
    
    def _calibration_id_s3_path(self, calibration_id):
        return F'{self._calibration_s3_path}/{calibration_id[0:4]}/{calibration_id[5:7]}/{calibration_id[8:10]}/{calibration_id[11:]}'

    def get_mw(self, calibration_id):
        calibration_path = self._calibration_id_s3_path(calibration_id)
        mwb_galileo = mw_bais_reader.read(s3.get_object(F"{calibration_path}/galileo-mwb-bias.txt").decode('utf-8'))[0]
        mwb_gps = mw_bais_reader.read(s3.get_object(F"{calibration_path}/gps-mwb-bias.txt").decode('utf-8'))[0]
        results = []
        for mwb in [mwb_gps, mwb_galileo]:
            for key, value in mwb['sat_info'].items():
                item = value
                sat_id = key
                item['signals_info'] = [{**value, **{'signal': get_signal_from_rinex_id(sat_id=sat_id,rinex_signal_id=key),'rinex_signal_id':key}}for key, value in value['signals_info'].items()]
                item['sat_id'] = key
                for value_to_copy_from_item_to_sat in ['dispersive_bias_consistency_indicatory', 'mw_consistency_indicator']:
                    item[value_to_copy_from_item_to_sat] = mwb[value_to_copy_from_item_to_sat]

                results.append(item)
        return results


    def get_modipmap(self, calibration_id):
        calibration_path = self._calibration_id_s3_path(calibration_id)
        tar_file = tarfile.open(fileobj=io.BytesIO(s3.get_object(F'{calibration_path}/modipmapapp.tar.gz')))
        file_name = [x.name for x in tar_file.getmembers() if re.findall(r"ModipMapCorrections_.*\.json$",x.name)][0]
        return json.loads(tar_file.extractfile(file_name).read())

    def get_apc(self, calibration_id):
        calibration_path = self._calibration_id_s3_path(calibration_id)
        tar_file = tarfile.open(fileobj=io.BytesIO(s3.get_object(F"{calibration_path}/iono-apc.tar.gz")))
        apc_bias = apc_bias_reader.read(tar_file.extractfile(
            './apc_bias.txt').read().decode('utf-8'))[0]
        apc_bias_sigma = apc_bias_reader.read(tar_file.extractfile(
            './apc_bias_sigma.txt').read().decode('utf-8'))[0]
        results = []
        for sat_id, sat_info in apc_bias['sat_info'].items():
            signal_results = []
            for rinex_signal_id, signal_info in sat_info['signals_info'].items():
                signal_result = {}
                signal_result['signal'] = get_signal_from_rinex_id(sat_id, rinex_signal_id)
                signal_result['rinex_signal_id'] = rinex_signal_id
                signal_result['bias'] = signal_info
                signal_result['sigma'] = apc_bias_sigma['sat_info'][sat_id]['signals_info'][rinex_signal_id]
                signal_results.append(signal_result)
            results.append(dict(sat_id=sat_id, signals_info=signal_results))
        return results

    def get_iono_delta_code_bias(self, calibration_id):
        calibration_path = self._calibration_id_s3_path(calibration_id)
        print(F"{calibration_path}/iono-deltassrcodebias.tar.gz")
        tar_file = tarfile.open(fileobj=io.BytesIO(s3.get_object(F"{calibration_path}/iono-deltassrcodebias.tar.gz")))
        print(tar_file)
        sigma = sigma_bias_reader.read(tar_file.extractfile(
            './delta_code_sigma.txt').read().decode('utf-8'))[0]
        bias = dcb_bias_reader.read(tar_file.extractfile(
            './delta_code_bias.txt').read().decode('utf-8'))[0]
        merged = always_merger.merge(bias, sigma)
        results = []
        for sat_id, sat_info in merged['sat_info'].items():
            signal_results = []
            for rinex_signal_id, signal_info in sat_info['signals_info'].items():
                signal_result = {}
                signal_result['signal_id'] = get_signal_from_rinex_id(sat_id, rinex_signal_id)
                signal_result['rinex_signal_id'] = rinex_signal_id
                signal_result['code_bias_m'] = signal_info['code_bias_m']
                signal_result['sigma_code_bias_m'] = signal_info['sigma_code_bias_m']
                signal_results.append(signal_result)
            results.append(dict(sat_id=sat_id, signals_info=signal_results))
        return results

    def get_dcb(self, calibration_id):
        calibration_path = self._calibration_id_s3_path(calibration_id)
        tar_file = tarfile.open(fileobj=io.BytesIO(s3.get_object(F"{calibration_path}/results-ssr-code-bias.tar.gz")))
        dcb = dcb_bias_reader.read(tar_file.extractfile(
            './code_bias.txt').read().decode('utf-8'))[0]
        results = []
        for sat_id, sat_info in dcb['sat_info'].items():
            signals_info = []
            for rinex_signal_id, signal_info in sat_info['signals_info'].items():
                signals_info.append({**signal_info, **dict(rinex_signal_id=rinex_signal_id, signal_id=get_signal_from_rinex_id(sat_id, rinex_signal_id))})
            results.append(dict(signals_info=signals_info, sat_id=sat_id))
        return results
        
    def get_nav(self,sat_id,unique_id,flavor):
        sat_id = sat_id + flavor
        data = self._nav_table.query(KeyConditionExpression=Key('Id').eq(sat_id) & Key(
            'Epoch').eq(unique_id))
        item =  json.loads(data['Items'][0]['data'])
        item['epoch'] = data['Items'][0]['Epoch']
        for key in item.keys():
            if key in nav_convert_fields:
                item[key] = nav_convert_fields[key](item[key])
            else:
                raise Exception(F"{key}")
        return item

    def get_nav_latest(self,sat_id,flavor):
        sat_id = sat_id + flavor
        data = self._nav_table.query(KeyConditionExpression=Key('Id').eq(sat_id),
          ScanIndexForward=False,
          Limit=1)
        item =  json.loads(data['Items'][0]['data'])
        item['epoch'] = data['Items'][0]['Epoch']
        for key in item.keys():
            if key in nav_convert_fields:
                item[key] = nav_convert_fields[key](item[key])
            else:
                raise Exception(F"{key}")
        return item

    def get_corrections(self,calibration_id,start_time,end_time):
        return self._ssr_correction_fetcher.get_corrections_from_ts(
            calibration_id=calibration_id,start_time=start_time,end_time=end_time)

    def get_tropo_results(self,time):
      output_path = F"{self._tropo_s3_path}/{time:%Y/%m/%d/%H}/output.tar.gz"
      if not s3.object_exists(output_path):
        abort(404)
      return s3.generate_presigned_url(output_path,timeout=300)

def bool_convert(x):
    if int(x):
        return True
    else:
        return False

nav_convert_fields = {
  "epoch": str,
  "accuracy": float, 
  "af0": float, 
  "af1": float, 
  "af2": float, 
  "bgdE5a": float, 
  "bgdE5b": float, 
  "cic": float,
  "cis": float, 
  "crc": float, 
  "crs": float, 
  "cuc": float, 
  "cus": float, 
  "datasource": int, 
  "deltaN": float, 
  "dvsE1b": float, 
  "dvsE5a": float, 
  "dvsE5b": float, 
  "e": float, 
  "fitInt": float, 
  "health": int, 
  "healthE1b": int, 
  "healthE5a": float, 
  "healthE5b": int, 
  "i0": float, 
  "id": id, 
  "idot": float, 
  "iodc":int , 
  "iode": int, 
  "iode": int, 
  "l2code": float,
  "l2flag": int, 
  "m0": float, 
  "omega": float, 
  "omega0": float, 
  "omegaDot": float, 
  "rootA": float, 
  "sisa": int, 
  "system": str, 
  "tgd": float,
  "toc": float, 
  "toe": float, 
  "tom": float, 
  "type": str, 
  "ura": int, 
  "week": int, 
}


def get_signal_from_rinex_id(sat_id, rinex_signal_id):
    for signal in signals_mapping[_get_constation_from_sat_id(sat_id)]:
        if signal['rinex_map'] == rinex_signal_id:
            return signal['signal']
    raise Exception(F"Not implamented {rinex_signal_id} to sat {sat_id}")



def _get_constation_from_sat_id(sat_id):
    if sat_id[0] == 'G':
        return 'GPS'
    elif sat_id[0] == 'E':
        return 'GALILEO'


signals_mapping = dict(
    GPS=[
        dict(rinex_map='1P', signal='L1 P'),  # 1
        dict(rinex_map='1W', signal='L1 Z-tracking or similar'),  # 2
        dict(rinex_map='1C', signal='L1 C/A'),  # 0
        dict(rinex_map='1X', signal='L1C-(D+P)'),  # // ntrip_id 3
        dict(rinex_map='2P', signal='L2 P'),
        dict(rinex_map='2W', signal='L2 Z-tracking or similar'),
        dict(rinex_map='2C', signal='L2 C/A'),
        dict(rinex_map='2D', signal='TBD'),
        dict(rinex_map='2S', signal='L2 L2C(M)'),
        dict(rinex_map='2L', signal='L2 L2C(L)'),
        dict(rinex_map='2X', signal='L2 L2C(M+L)'),
        dict(rinex_map='5I', signal='L5 I'),
        dict(rinex_map='5Q', signal='L5 Q'),
        dict(rinex_map='5X', signal='L5 I+Q'),
    ],
    GALILEO=[
        dict(rinex_map='1B', signal='E1 B I/NAV OS/CS/SoL'),
        dict(rinex_map='1C', signal='E1 C no data'),
        dict(rinex_map='1X', signal='E1 B+C'),
        dict(rinex_map='1Z', signal='E1 A+B+C'),
        dict(rinex_map='1A', signal='E1 A'),
        dict(rinex_map='5I', signal='E5A I'),
        dict(rinex_map='5Q', signal='E5A Q'),
        dict(rinex_map='5X', signal='E5A I+Q'),
        dict(rinex_map='7I', signal='E5B I'),
        dict(rinex_map='7Q', signal='E5B Q'),
        dict(rinex_map='7X', signal='E5B I+Q'),
        dict(rinex_map='6B', signal='E6 B'),
        dict(rinex_map='6C', signal='E6 C'),
        dict(rinex_map='6X', signal='E6 B+C'),
        dict(rinex_map='6Z', signal='E6 A+B+C'),
        dict(rinex_map='6A', signal='E6 A'),
        dict(rinex_map='8I', signal='E5 I'),
        dict(rinex_map='8Q', signal='E5 Q'),
        dict(rinex_map='8X', signal='E5 I+Q'),

    ]
)


if __name__ == '__main__':
    import yaml
    dal = Dal(yaml.safe_load(open('examples/compute_api.yaml').read()))
    dal.get_nav('E36','2021-05-04T10:50:00.000')
