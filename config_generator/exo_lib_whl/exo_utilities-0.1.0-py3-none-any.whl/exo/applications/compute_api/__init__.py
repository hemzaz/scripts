
from . dal import Dal
from . app import flask_app



import boto3
sns = boto3.resource('sns')

from datetime import date, datetime


from json import JSONEncoder
class DateTimeEncoder(JSONEncoder):
        def default(self, obj):
            if isinstance(obj, (date, datetime)):
                return obj.isoformat()

flask_app.config.update(   RESTPLUS_JSON = {'separators': (', ', ': '),
                    'indent': 2,
                    'cls': DateTimeEncoder})
DAL = None
import click
import yaml
from functools import partial
@click.command()
@click.option('--config',required=True)
def cli(config):
  global DAL
  config = yaml.safe_load(open(config).read())
  app._DAL = Dal(config)
  flask_app.run(host= '0.0.0.0',debug=True)