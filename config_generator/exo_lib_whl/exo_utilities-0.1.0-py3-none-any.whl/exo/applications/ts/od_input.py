import os
import shutil
from contextlib import contextmanager
from retrying import retry
from exo.utilities.prometheus import GetPrometheusInputs
from exo.utilities.highrate_app_utils.softlink import softlink
import logging
logger = logging.getLogger(__name__)

class OdInput():
  def __init__(self,working_folder,run_folder):
    self._run_folder = run_folder
    self._working_folder = working_folder
  
  @retry(stop_max_delay=2 * 60 * 1000,wait_fixed=2000)
  def _get_current_id(self):
    try:
      dirs = os.listdir(self._source_od_dir())
      dirs = [dir_name for dir_name in dirs  
      if os.path.exists(os.path.join(self._source_od_dir(),dir_name,'metadata.json'))]
      dirs.sort(reverse=True)
      return dirs[0]
    except Exception as ex:
      logger.info('waiting for od',ex)
      raise

  def _source_od_dir(self):
    return os.path.join(self._working_folder,'od')

  @contextmanager
  def prepare(self):
    current_id_path = self._get_current_id()
    od_dirs = os.listdir(self._source_od_dir())
    dirs_to_delete = [nav_dir for nav_dir in od_dirs if int(nav_dir) < int(current_id_path)]
    for dir_to_delete in dirs_to_delete:
      path = os.path.join(
          self._source_od_dir(),
          dir_to_delete)
      shutil.rmtree(path)
    with softlink(os.path.join(
        self._source_od_dir(),current_id_path  ),os.path.join(self._run_folder,'results-od-merge')):
      yield None
