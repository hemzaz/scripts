import click
import json
import pandas
import datetime
from matplotlib import pyplot as plt

def get_info(data):
  results = {}
  for receiver, data in data['stations'].items():
      epochs = []
      for year, year_data in data.items():
          for day, day_data in year_data.items():
              for epoch in day_data['epochs']:
                  formated_time = datetime.datetime.strptime(
                      epoch['epoch'], "%Y-%m-%dT%H:%M:%S.%f")
                  epochs.append(formated_time)
      epochs.sort()
      epochs_set = set(epochs)
      current_time = epochs[0]
      end_time = epochs[-1]
      avalible = []
      unavalible = []
      avalible_count = 0
      unavalible_count = 0
      while current_time<= end_time:
        if current_time in epochs_set:
          avalible_count = avalible_count +1
          unavalible_count = 0
        else:
          avalible_count = 1
          unavalible_count = unavalible_count +1
        avalible.append((current_time, avalible_count))
        unavalible.append((current_time, unavalible_count))
        current_time = current_time + datetime.timedelta(seconds=30)
      results[receiver] = dict(
        avalible = avalible,
        unavalible = unavalible,
        )
  return results

@click.group()
def cli():
  pass

@cli.command()
@click.argument('filename')
def describe(filename):
  data = json.load(open(filename))
  data = get_info(data)
  for receiver, receiver_data in data.items():

      df = pandas.DataFrame.from_dict(receiver_data['unavalible'])
      df = df.set_index(0)
      
      break

import matplotlib.pyplot as plt

@cli.command()
@click.argument('filename')
def graph(filename):
  data = json.load(open(filename))
  fig, ax = plt.subplots()

  for receiver, data in get_info(data).items():
      df = pandas.DataFrame.from_dict(data['unavalible'])
      df = df.set_index(0)
      df[receiver] = df[1]

      df.plot(ax=ax, y = receiver)

  def on_pick(event):
      # On the pick event, find the original line corresponding to the legend
      # proxy line, and toggle its visibility.
      legline = event.artist
      origline = lined[legline]
      print(event.artist)
      visible = not origline.get_visible()
      origline.set_visible(visible)
      # Change the alpha on the line in the legend so we can see what lines
      # have been toggled.
      legline.set_alpha(1.0 if visible else 0.2)
      fig.canvas.draw()
  
  fig.canvas.mpl_connect('pick_event', on_pick)
  plt.show()


if __name__ == '__main__':
  cli()