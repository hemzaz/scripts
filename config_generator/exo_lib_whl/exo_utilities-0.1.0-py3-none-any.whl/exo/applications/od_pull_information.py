import os
import click
import click_config_file
import yaml
import logging
from exo.utilities.click_types import S3Path
from exo.applications.od_fetcher.products_fetcher import ProductsFetcher
from exo.applications.od_fetcher.nav_fetcher import NavFetcher
from exo.applications.od_fetcher.logs_fetcher import OdLogsFetcher, CleanObsLogsFetcher
from exo.applications.od_fetcher.obs_check_point_fetcher import ObsCheckPointFetcher
from exo.applications.od_fetcher.cleanobs_fetcher import CleanobsFetcher
from exo.applications.od_fetcher.summary import SummaryFetcher, ConfigFetcher
from exo.applications.od_fetcher.results import MergeFetcher, PropFetcher, EstFetcher


class CallList():
    def __init__(self, callList):
        self._call_list = callList
        pass

    def __call__(self, *args, **kwargs):
        def _lambada():
            for fetcher in self._call_list:
                fetcher(*args, **kwargs)()
        return _lambada


fetchers = {
    "products": ProductsFetcher,
    "nav": NavFetcher,
    "cleanobs": CleanobsFetcher,
    "obs": ObsCheckPointFetcher,
    "logs": CallList([OdLogsFetcher, CleanObsLogsFetcher]),
    "summary": SummaryFetcher,
    "results": CallList([MergeFetcher, PropFetcher, EstFetcher]),
    "result_merge": MergeFetcher,
    "result_prop": PropFetcher,
    "result_est": EstFetcher,
    "config": ConfigFetcher,
}


def yaml_config_provider(file_path, cmd_name):
    if not os.path.exists(file_path):
        return {}
    with open(file_path) as config_data:
        return yaml.safe_load(config_data.read())


@click.command()
@click.option('--what-to-download', "-w",
              type=click.Choice(fetchers.keys()),
              multiple=True,
              default=['nav', 'obs', 'products', 'logs', 'config'],
              )
@click.option('--output-dir', '-o', default=".")
@click.option('--obs-longterm-storage-s3_prefix', type=S3Path(dirs=False))
@click.argument("s3_prefix", type=S3Path(dirs=False))
@click_config_file.configuration_option(provider=yaml_config_provider)
def cli(what_to_download, **kwargs):
    for x in what_to_download:
        print(F'downloading {x}')
        fetchers[x](**kwargs)()


if __name__ == '__main__':
    cli()
