from kubernetes import client
import logging
from datetime import datetime
logger = logging.getLogger(__name__)
import uuid

class ResourceOperator:
    def __init__(self, namespace,api = None):
        self._namespace = namespace
        self._api = api if api!=None else client.CoreV1Api()

    def _check_if_exists(self, name):
        return any([x.metadata.name == name for x in self.list()])

    def check_if_need_patch(self,data):
        name = data['metadata']['name']
        current_item = [x for x in self.list() if x.metadata.name == name ][0]
        return  current_item.metadata.annotations['configuration-operator/sha'] != data['metadata']['annotations']['configuration-operator/sha']

    def create_or_patch(self, data):
        if not self._check_if_exists(data['metadata']['name']):
            logger.info(F"created resource {data['metadata']['name']}")
            self.create(data)
        elif self.check_if_need_patch(data):
            logger.info(F"patch resource {data['metadata']['name']}")
            self.patch(data)
        else:
            logger.info(F"already up to date resource {data['metadata']['name']}")
          


class ConfigmapOperator(ResourceOperator):
    def list(self):
        return self._api.list_namespaced_config_map(namespace=self._namespace).items

    def create(self, data):
        self._api.create_namespaced_config_map(
            namespace=self._namespace,
            body=data)

    def patch(self, data):
        self._api.patch_namespaced_config_map(
            namespace=self._namespace,
            body=data,
            name=data['metadata']['name'])

    def delete(self, name):
        self._api.delete_namespaced_config_map(
            namespace=self._namespace, name=name)


class CronjobOperator(ResourceOperator):
    def __init__(self,namespace):
        super().__init__(namespace,
         api=client.BatchV1beta1Api())
        self._batch_v1 = client.BatchV1Api()

    def list(self):
        return self._api.list_namespaced_cron_job(namespace=self._namespace).items

    def create(self, data):
        self._api.create_namespaced_cron_job(
            namespace=self._namespace,
            body=data)
        self._initaite_job(self._namespace,data['metadata']['name'])

    def _initaite_job(self,namespace,job_name):

        cron_job = self._api.read_namespaced_cron_job(job_name, namespace)
        name = F"{cron_job.metadata.name}-{int(datetime.utcnow().timestamp())}"
        logger.info(F"Created job {name} for cronjob {job_name}")
        extra_annotation = {"cronjob.kubernetes.io/instantiate": "startup"}
        job = client.V1Job(
            api_version='batch/v1',
            kind='Job',
            metadata=client.models.V1ObjectMeta(
                name=name,
                labels = {**(cron_job.spec.job_template.metadata.labels if cron_job.spec.job_template.metadata.labels != None else {}),
                **extra_annotation},
                annotations = {**(cron_job.spec.job_template.metadata.  labels if cron_job.spec.job_template.metadata.annotations !=None else {}),
                **extra_annotation},
            ),
            spec=cron_job.spec.job_template.spec
        )
        result = self._batch_v1.create_namespaced_job(namespace, job)

    def patch(self, data):
        self._api.patch_namespaced_cron_job(
            namespace=self._namespace,
            body=data,
            name=data['metadata']['name'])
        self._initaite_job(self._namespace,data['metadata']['name'])

    def delete(self, name):
        self._api.delete_namespaced_cron_job(
            namespace=self._namespace, name=name)


class StatefulsetOperator(ResourceOperator):
    def __init__(self,namespace):
        super().__init__(namespace, api=client.AppsV1Api())

    def list(self):
        return self._api.list_namespaced_stateful_set(namespace=self._namespace).items

    def create(self, data):
        self._api.create_namespaced_stateful_set(
            namespace=self._namespace,
            body=data)

    def patch(self, data):
        self._api.patch_namespaced_stateful_set(
            namespace=self._namespace,
            body=data,
            name=data['metadata']['name'])

    def delete(self, name):
        self._api.delete_namespaced_stateful_set(
            namespace=self._namespace, name=name)

class ServiceOperator(ResourceOperator):

    def list(self):
        return self._api.list_namespaced_service(namespace=self._namespace).items

    def create(self, data):
        self._api.create_namespaced_service(
            namespace=self._namespace,
            body=data)

    def patch(self, data):
        self._api.patch_namespaced_service(
            namespace=self._namespace,
            body=data,
            name=data['metadata']['name'])

    def delete(self, name):
        self._api.delete_namespaced_service(
            namespace=self._namespace, name=name)

from munch import Munch,munchify
class CustomResourceOperator(ResourceOperator):
    def __init__(self,group,version,plural,namespace,*args,**kwargs):
        self._args = dict(
            group = group,
            version = version,
            plural = plural,
            namespace = namespace,
        )
        super().__init__(namespace,api=client.CustomObjectsApi())

    def list(self):
        return munchify(self._api.list_namespaced_custom_object(**self._args))['items']
        

    def create(self, data):
        self._api.create_namespaced_custom_object(
            body=data,**self._args)

    def patch(self, data):
        self._api.patch_namespaced_custom_object(
            body=data,
            name=data['metadata']['name'],
            **self._args)

    def delete(self, name):
        self._api.delete_namespaced_custom_object(
             name=name,**self._args)





def get_resource_operators(namespace):
    return {
        "ConfigMap": ConfigmapOperator(namespace=namespace),
        "CronJob": CronjobOperator(namespace=namespace),
        "StatefulSet": StatefulsetOperator(namespace=namespace),
        "Service": ServiceOperator(namespace=namespace),
        "ServiceMonitor":CustomResourceOperator(namespace=namespace,group="monitoring.coreos.com",version="v1",plural="servicemonitors")
    }
