import click
import yaml
import json
import requests
from IPython import embed; 

from .main import Main

from .. import kube_load_config
import logging
logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.INFO)
kube_load_config()

@click.command()
@click.option('--config',required=True)
def cli(config):
  Main(config = yaml.safe_load(open(config).read())
      )()





