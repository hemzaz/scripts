import yaml
from kubernetes import client as kube_client
from . resource_operators import get_resource_operators
from ..configuration_api.api import Api
from hashlib import sha3_256
import logging
import json
import jinja2
import base64

logger = logging.getLogger(__name__)

class Main:

    def _read_templates(self):
        v1 = kube_client.CoreV1Api()
        configmaps = v1.list_namespaced_config_map(namespace=self._namespace)
        templates = []
        for configmap in configmaps.items:
            annotations = configmap.metadata.annotations
            if not annotations:
                continue
            if 'configuration-operator/is-template' in annotations and \
                'configuration-operator/id' in annotations and \
                    annotations['configuration-operator/id'] == self._operator_id:
                templates.append(
                    dict(name=configmap.metadata.name,
                         template=configmap.data["template"],
                         annotations=configmap.metadata.annotations)
                )
        return templates

    def __init__(self, config):
        self._config = config
        self._namespace = config['namespace']
        self._operators = get_resource_operators(self._namespace)
        self._configurations_api = Api(
            url=config['configuration-api'])
        self._operator_id = config['operator-id']
    
    def _check_if_metadata_needed_restriction_is_pass(self,template,configuration):
        if 'configuration-operator/needed-metadata' in template['annotations']:
            needed_metadatas = template['annotations']['configuration-operator/needed-metadata'].split(',')
            for needed_metadata in needed_metadatas:
                needed_key = needed_metadata
                needed_value = ""
                if len(needed_metadata.split('=')) > 1:
                    needed_key = needed_metadata.split('=')[0]
                    needed_value = needed_metadata.split('=')[1]
                if needed_key not in configuration['metadata']:
                    return False
                if needed_value and configuration['metadata'][needed_key]!= needed_value:
                    return False
        return True
    
    def __call__(self):
        self._configurations = self._configurations_api.read_configurations()
        self._templates = self._read_templates()
        resources_to_be_created = []
        for configuration in self._configurations:
            data_values = Struct(**configuration['data'])
            for template in self._templates:
                if not self._check_if_metadata_needed_restriction_is_pass(template=template,configuration = configuration):
                    continue
                environment = jinja2.Environment( 
                  trim_blocks=True,
                  block_start_string='@@',
                  block_end_string='@@',
                  variable_start_string='@=',
                  variable_end_string='=@')
                environment.filters['b64encode'] = lambda x: base64.b64encode(x.encode('utf-8')).decode('utf-8')
                environment.filters['lower'] = lambda x: x.lower()
                data = dict(
                        Values=data_values,
                        configuration_json = json.dumps(configuration['data']),
                        configuration_id=configuration['id'],
                        template_id=template['name'],
                        unique_id=F"{template['name']}-{configuration['id']}".lower().replace(':', "-")
                    )
                text = environment.from_string(template['template']).render(data)
                resource_to_be_created = yaml.safe_load(text)
                annotations_dict = dic_return_or_create_new(dic_return_or_create_new(
                    resource_to_be_created, 'metadata'), 'annotations')
                metadata_dict = dic_return_or_create_new(
                    dic_return_or_create_new(resource_to_be_created, 'metadata'), 'labels')
                resource_text = yaml.dump(resource_to_be_created)
                sha = sha3_256()
                sha.update(resource_text.encode('utf-8'))
                values_to_add = {
                    'configuration-operator/id': self._operator_id,
                    'configuration-operator/created': "true",
                    'configuration-operator/sha': sha.hexdigest()[:8],
                    'configuration-operator/template-name': template['name'],
                    'configuration-operator/configuration-id': configuration['id'].lower().replace(':', "-"),
                }
                for key, value in values_to_add.items():
                    metadata_dict[key] = value
                    annotations_dict[key] = value
                resources_to_be_created.append(resource_to_be_created)

        for resource_to_be_created in resources_to_be_created:
            self._operators[resource_to_be_created['kind']].create_or_patch(
                resource_to_be_created)

        for kind, operator in self._operators.items():
            items = operator.list()
            allowed_names_for_kind = [x['metadata']['name']
                                      for x in resources_to_be_created if x['kind'] == kind]
            for item in items:
                
                if item.metadata.annotations != None and \
                    'configuration-operator/id' in item.metadata.annotations and \
                    item.metadata.annotations['configuration-operator/id'] == self._operator_id and \
                    'configuration-operator/created' in item.metadata.annotations and \
                        item.metadata.name not in allowed_names_for_kind:
                    logger.info(F'delete {kind} {item.metadata.name}')
                    operator.delete(name=item.metadata.name)


def dic_return_or_create_new(data, key):
    if key not in data:
        data[key] = {}
    return data[key]


class Struct:
    def __init__(self, **entries):
        for key,value in entries.items():
            if isinstance(value,dict):
                entries[key]=Struct(**value)
        self.__dict__.update(entries)
