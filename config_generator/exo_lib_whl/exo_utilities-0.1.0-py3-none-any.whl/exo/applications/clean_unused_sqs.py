import click
import boto3
import json
import time
import botocore
from IPython import embed;
import os
from kubernetes import client, config

from . import kube_load_config

kube_load_config()

api = client.CoreV1Api()
sqs = boto3.resource('sqs')
sns = boto3.resource('sns')

def check_pod_exists(pod_name,namespace):
    try:
      api.read_namespaced_pod(
        name=pod_name,
        namespace=namespace)
      return True;
    except client.exceptions.ApiException as ex:
      if (json.loads(ex.body)['code'] == 404):
        return False
      raise




@click.command()
@click.argument('sns_topic')
def cli(sns_topic):
  prefix = sns_topic.split(':')[-1]
  for queue in sqs.queues.filter(QueueNamePrefix=prefix):
    print(F"checking {queue.url}")
    try:
      tags = queue.meta.client.list_queue_tags(QueueUrl = queue.url)['Tags']
      if not 'Ephemeral' in tags.keys():
        print('queue ok')
        continue
      if check_pod_exists(
          pod_name=tags.get('Pod',"UNKNWON"),
          namespace=tags.get("Namespace","UNKNWON")):
        continue
      else:
        if (time.time() - float(tags['CreateTime'])) > 30 * 60:
          print(F"{queue.url} delete")
          queue.delete()
          print(F"{queue.url} delete done")
    except sqs.meta.client.exceptions.QueueDoesNotExist:
      pass
    except Exception as ex:
      print(ex)

  topic = sns.Topic(sns_topic)
  topic.load()
  for subscription in topic.subscriptions.all():
    if subscription.attributes['Protocol'] == 'sqs':
      try:
        subscriptionEndpointsSplit = subscription.attributes['Endpoint'].split(':')
        queue =  sqs.get_queue_by_name(
          QueueName=subscriptionEndpointsSplit[-1],
          QueueOwnerAWSAccountId = subscriptionEndpointsSplit[-2])
        queue.load()
      except sqs.meta.client.exceptions.QueueDoesNotExist as ex:
        print(F"delete unused subscription{subscription.arn}")
        subscription.delete()
        


