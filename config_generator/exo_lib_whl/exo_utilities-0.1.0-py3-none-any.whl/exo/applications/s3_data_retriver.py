#!/usr/bin/env python3
import click
import dateutil.parser
import logging
import os
import json
from ..utilities import click_types
from exo.utilities.fetcher.s3_latest_od import LatestOdFetcher, LatestTsFetcher
from exo.utilities.fetcher.S3ArchiveFetcher import S3ArchiveFetcher
logging.getLogger().setLevel(logging.INFO)


FTP_PRODUCTS = ['ERP', 'Antex', 'Clocks', 'SP3', 'Sinex', 'DCB', 'olp', 'nanu']


@click.command()
@click.option('--start_date',
              help="plese use iso",
              type=click_types.DateTime())
@click.option('--end_date', help="plese use iso", type=click_types.DateTime())
@click.option('--s3-products-prefix',
              default='s3://lear-exo/zone/p/Archive/Sync/products')
@click.option('--od-prefix', default='s3://lear-exo/zone/p/od')
@click.option('--ts-prefix', default='s3://lear-exo/zone/staging/ts/gps')
@click.option('--download-meta-data-file-name', default='meta-data.json')
@click.option('--products',
              type=click.Choice(FTP_PRODUCTS + ['Od', 'Ts']),
              multiple=True,
              default=FTP_PRODUCTS)
@click.argument('dest_dir')
def fetch(start_date, end_date, dest_dir,
          s3_products_prefix, products,
          od_prefix, ts_prefix,
          download_meta_data_file_name):
    logging.info('started')
    downloaded_products_data = {}
    for ftp_product in FTP_PRODUCTS:
        if ftp_product in products:
            downloaded_products_data[ftp_product] = \
                S3ArchiveFetcher(
                    start_date,
                    end_date,
                    os.path.join(dest_dir, 'products', ftp_product),
                    F"{s3_products_prefix}/{ftp_product}")()
    if 'Od' in products:
        LatestOdFetcher(
            start_date=start_date,
            end_date=end_date,
            output_dir=os.path.join(dest_dir, 'od'),
            s3_prefix=od_prefix)()
    if 'Ts' in products:
        LatestTsFetcher(
            start_date=start_date,
            end_date=end_date,
            output_dir=os.path.join(dest_dir, 'ts'),
            s3_prefix=ts_prefix)()
    if download_meta_data_file_name:
        with open(
                os.path.join(dest_dir, download_meta_data_file_name), 'w') as file_meta_data:
            json.dump(downloaded_products_data, file_meta_data)


if __name__ == '__main__':
    fetch()
