import datetime
import gzip
import json
from logging import exception
import jmespath
import click
import re
import os
from exo.utilities import gpstime
from exo.utilities import s3
from exo.utilities import click_types


BUCKET = "s3://lear-exo-foc-staging-inputs-ntrips-obs-long-term-storage/obs/"
result_json = {}

def get_item_list_by_date(year, gps_day, quick):
    items_list = s3.list_files(f"{BUCKET}{year}/{gps_day}")
    if quick:
        query_get_station_3_hours = re.compile("\w*-c(?P<date>\d{4}-\d{2}-\d{2})T\d{2}-\d{2}-\d{2}-s(?P=date)T(00)")
    else:
        query_get_station_3_hours = re.compile("\w*-c(?P<date>\d{4}-\d{2}-\d{2})T\d{2}-\d{2}-\d{2}-s(?P=date)T(00|03|06|09|12|15|18|21)")
    station_date_lst = list(filter(query_get_station_3_hours.match, items_list))
    return station_date_lst


def download_files(output_path, year, gps_day, quick):
    global compressed_file_path_list 
    compressed_file_path_list = []
    for item in get_item_list_by_date(year, gps_day, quick):
        print(f"{item}")
        url = f"{BUCKET}{year}/{gps_day}/{item}"
        compressed_file_path = f"{output_path}{item}"
        if not os.path.exists(f"{compressed_file_path}"):
            s3.download_file(f"{url}" ,f"{compressed_file_path}")
        compressed_file_path_list += [ compressed_file_path ]
        with gzip.open(compressed_file_path) as f:
            data = json.load(f)
            yield data


def get_signals_by_constellation_per_station(data_query, station_name):
    for chunk in data_query:
        for constellation_key in chunk:
            signals = chunk.get(constellation_key)
            for signal in signals:
                if len(signal) == 3:
                    if station_name not in result_json:
                        result_json[f"{station_name}"] = {f"{constellation_key[0]}":[signal]}
                    elif constellation_key[0] not in result_json[station_name]:
                        result_json[f"{station_name}"][f"{constellation_key[0]}"] = [signal]
                    elif constellation_key[0] in result_json[f"{station_name}"] and signal not in result_json[f"{station_name}"][constellation_key[0]]:
                        result_json[f"{station_name}"][f"{constellation_key[0]}"] += ([signal])
                    elif constellation_key[0] not in result_json[f"{station_name}"]: 
                        result_json[f"{station_name}"].update({f"{constellation_key[0]}":[signal]})
    
    
def get_station_by_constellation(data_query, station_name):
    for chunk in data_query:
        for constellation in chunk:
            if constellation[0] not in result_json:
                result_json[f"{constellation[0]}"] = [station_name]
            elif station_name not in result_json[f"{constellation[0]}"]:
                result_json[f"{constellation[0]}"] += [station_name]


def get_station_per_satellite(data_query, station_name):
    for chunk in data_query:
            for constellation in chunk:
                if constellation not in result_json:
                    result_json[f"{constellation}"] = [station_name]
                if constellation in result_json and station_name not in result_json[f"{constellation}"]:
                    result_json[f"{constellation}"] += [station_name]


def get_satellite_per_station(data_query, station_name):
        for chunk in data_query:
                for constellation in chunk:
                    if station_name not in result_json:
                        result_json[f"{station_name}"] = [constellation]
                    if station_name in result_json and constellation not in result_json[f"{station_name}"]:
                        result_json[f"{station_name}"] += [constellation]


def get_station_signal_per_constellation(data_query, station_name):
    for chunk in data_query:
        for constellation_key in chunk:
            signals = chunk.get(constellation_key)
            for signal in signals:
                if len(signal) == 3:
                    if constellation_key[0] not in result_json:
                        result_json[f"{constellation_key[0]}"] = {f"{signal}":[station_name]}
                    elif signal not in result_json[constellation_key[0]]:
                        result_json[f"{constellation_key[0]}"][f"{signal}"] = [station_name]
                    elif signal in result_json[f"{constellation_key[0]}"] and station_name not in result_json[f"{constellation_key[0]}"][signal]:
                        result_json[f"{constellation_key[0]}"][f"{signal}"] += ([station_name])
                    elif signal not in result_json[f"{constellation_key[0]}"]: 
                        result_json[f"{constellation_key[0]}"].update({f"{signal}":[station_name]})
        
options = {
    "signals_by_constellation_per_station" : get_station_signal_per_constellation,
    "station_by_constellation" : get_station_by_constellation,
    "station_per_satellite" : get_station_per_satellite,
    "satellite_per_station" : get_satellite_per_station,
    "station_signal_per_constellation" : get_station_signal_per_constellation
}

@click.command()
@click.option('--date', help='e.g: 2020-01-14', required=True,type = click_types.DateTime())
@click.option('--output-path',type=click.Path(), help='e.g: C:\\Users\\user\\Desktop\\', required=True)
@click.option('--quick',  is_flag=True,default=False, help="To make the program to run quicker, it can download fewer files. Instead of downloading files every 3 hours, it will download files from just 1 hour.")
@click.option('--query', type=click.Choice(["signals_by_constellation_per_station", "station_by_constellation", "station_per_satellite", "satellite_per_station", "station_signal_per_constellation"], case_sensitive=False),required= True)
def main(date, output_path, quick, query):
    """
signals_by_constellation_per_station - which obs does a certain station see per constellation?\n\n
    BRUX | G: C1C,C2W,C5Q | \nE: C1C, C5Q \n
    BRST | ...\n\n
station_by_constellation - which stations does a certain constellation see?\n\n
    G | ALGO, BRUX, ...\n
    E | BRST, ALGO, ...\n\n
station_per_satellite - which stations does a certain satellite see?\n\n
    G01 | ALGO, BRUX, ...\n
    G02 | ...\n
    E01 | ...\n\n
satellite_per_station - which satellites does a station see?\n\n
    ALGO | G01, G03, E01\n
    BRUX | G01, G03, E27\n
station_signal_per_constellation - which stations see a certain obs?\n\n
    G: C1C | BRUX, ALGO, BRST \n
    G: C2W | ...\n
    E: C5Q | BRUX, ALGO, BRST\n
    """
    result_dest = f"{output_path}{date.date()}-results.json"
    year = date.year
    gps_day = f"{int(gpstime.from_utc(date).day_in_year):03}"
    for data in download_files(output_path=output_path, gps_day=gps_day,year=year, quick=quick):
        station_query = re.compile(f"(?<={output_path})\w*(?=-)")
        station_name = station_query.findall((compressed_file_path_list)[-1])[0]
        data_query = jmespath.search("items[?items[:].metadata.source==realtime].data", data)
        options[query](station_name=station_name, data_query=data_query)
    result_json.update({ "time-span": f"{date.date()}" })
    with open(result_dest, "w") as f:
        json.dump(result_json, f, indent=4)


if __name__ == '__main__':
    main()