from prompt_toolkit import prompt
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.validation import Validator, ValidationError


class MyCustomCompleter(Completer):
    def get_completions(self, document, complete_event):
        yield Completion('01', start_position=-len(document.text))
        yield Completion('02', start_position=-len(document.text))


class NumberValidator(Validator):
    def validate(self, document):
        text = document.text

        if text and not text.isdigit():
            raise ValidationError(
                message='This input contains non-numeric characters',
                cursor_position=i)


text = prompt(
    '> ',
    complete_while_typing=True,
    completer=MyCustomCompleter(),
    validator=NumberValidator())
print(text)
