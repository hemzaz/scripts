from collections import namedtuple
import click
from exo.utilities.fetcher.antex import AntexArchiver, AntexDownloader
from exo.utilities.fetcher.dcb import DcbArchiver, DcbDownloader
from exo.utilities.fetcher.bsx import BsxArchiver, BsxDownloader
from exo.utilities.fetcher.sinex import SinexArchiver
from exo.utilities.fetcher.nav import NavArchiver, NavDownloader, NavTypes
from exo.utilities.fetcher.nanu import NanuDownloader
from exo.utilities.fetcher.iri_data import IriDataDownloader,IriDataArchiver ,IRI_DATA_TYPES
from exo.utilities.fetcher.erp import ErpArchiver, ErpDownloader, ErpTypes
from exo.utilities.fetcher.ionex import IonexArchiver, IonexDownloader, IonexTypes
from exo.utilities.fetcher.sp3 import SP3Downloader, SP3Types

from exo.utilities.fetcher.sp3 import Sp3IguHourlyArchiver
from exo.utilities.fetcher.sp3 import Sp3IgsDailyArchiver
from exo.utilities.fetcher.sp3 import Sp3IgrDailyArchiver
from exo.utilities.fetcher.sp3 import Sp3WUMHourlyArchiver
from exo.utilities.fetcher.sp3 import Sp3CodDailyArchiver
from exo.utilities.fetcher.sp3 import Sp3GfzDailyArchiver
from exo.utilities.fetcher.sp3 import Sp3IacDailyArchiver
from exo.utilities.fetcher.sp3 import Sp3JaxDailyArchiver
from exo.utilities.fetcher.sp3 import Sp3ShaDailyArchiver
from exo.utilities.fetcher.sp3 import Sp3GrgDailyArchiver
from exo.utilities.click_types import DateTime, S3Path, TimeDelta, EnumType
from datetime import timedelta, datetime
from exo.utilities.fetcher.nagu import NAGUFetcher
from functools import partial

ARCHIVERS = {
    'antex': AntexArchiver,
    'dcb': DcbArchiver,
    'bsx': BsxArchiver,
    'erp': ErpArchiver,
    'nav': NavArchiver,
    'sinex': SinexArchiver,
    'iri-data-apf_107': partial(IriDataArchiver,iri_data_type=IRI_DATA_TYPES.apf_107),
    'iri-data-ig_rz': partial(IriDataArchiver, iri_data_type=IRI_DATA_TYPES.ig_rz),
    'sp3-igu-hourly': Sp3IguHourlyArchiver,
    'sp3-igs-daily': Sp3IgsDailyArchiver,
    'sp3-igr-daily': Sp3IgrDailyArchiver,
    'sp3-wum-hourly': Sp3WUMHourlyArchiver,
    'sp3-cod-daily': Sp3CodDailyArchiver,
    'sp3-gfz-daily': Sp3GfzDailyArchiver,
    'sp3-iac-daily': Sp3IacDailyArchiver,
    'sp3-jax-daily': Sp3JaxDailyArchiver,
    'sp3-sha-daily': Sp3ShaDailyArchiver,
    'sp3-grg-daily': Sp3GrgDailyArchiver,

}
for ionex_type in IonexTypes:
    ARCHIVERS[F'ionex-{ionex_type.name}'] = partial(IonexArchiver,ionex_type=ionex_type)



@click.group()
def cli():
    pass


def get_archiver(product):
    return ARCHIVERS[product]


Auth = namedtuple('Auth', field_names=['username', 'password'])


@cli.command()
@click.option("--product",
              type=click.Choice(list(ARCHIVERS.keys())),
              required=True)
@click.option('--delta', type=TimeDelta(), default="-9w")
@click.argument('archive_location', type=S3Path(dirs=False))
@click.argument('time', type=DateTime())
def archive(archive_location, product, time, delta):
    get_archiver(product)(
        s3_prefix=archive_location).fill(
        time,
        delta)


@cli.command()
@click.argument('archive_location', type=S3Path())
@click.option('--delta', type=TimeDelta(), default="-9w")
@click.argument('time', type=DateTime())
@click.argument('folder', type=click.Path())
def antex_restore(archive_location, time, delta, folder):
    AntexArchiver(archive_location).restore(time, delta, folder)


@cli.command()
@click.option("--product",
              type=click.Choice(list(ARCHIVERS.keys())),
              required=True)
@click.argument('archive_location', type=S3Path())
@click.option('--delta', type=TimeDelta(), default="-9w")
@click.argument('time', type=DateTime())
@click.argument('folder', type=click.Path())
def restore_from_archive(archive_location, time, delta, folder, product):
    archiver = get_archiver(product)(s3_prefix=archive_location)
    archiver.restore(time, delta, folder)


@cli.group()
def antex():
    pass


@antex.command("by_time")
@click.argument('time', type=DateTime())
@click.argument('dest_dir')
def download_antex_by_time(time, dest_dir):
    AntexDownloader().download(time, dest_dir)


@antex.command("latest")
@click.argument('dest_dir')
def download_antex_latest(dest_dir):
    AntexDownloader().download_latest(dest_dir)


@cli.group()
def iri_data():
    pass


@iri_data.command("by_time")
@click.option('--iri-type',required=True,type= EnumType(IRI_DATA_TYPES))
@click.argument('time', type=DateTime())
@click.argument('dest_dir')
def download_iri_by_time(time, dest_dir,iri_type):
    IriDataDownloader().download(time=time, dest_folder=dest_dir, iri_data_type=iri_type)


@antex.command("latest")
@click.argument('dest_dir')
def download_antex_latest(dest_dir):
    AntexDownloader().download_latest(dest_dir)


@cli.command()
@click.argument('time', type=DateTime())
@click.argument('dest_dir')
def download_dcb(time, dest_dir):
    for suffix in ['DCB']:
        DcbDownloader().download(time, dest_dir, suffix=suffix)


@cli.command()
@click.option('--sp3-type', '-t', type=EnumType(SP3Types),
              multiple=True, default=[x.name for x in SP3Types])
@click.option('-d', '--delta', type=TimeDelta(), default="1d")
@click.argument("start_time", type=DateTime())
@click.argument('dest_dir')
def download_sp3(start_time, delta, dest_dir, sp3_type):
    for sp3_selected_type in sp3_type:
        SP3Downloader().download(
            start_time=min(start_time, start_time + delta),
            end_time=max(start_time, start_time + delta),
            dest_folder=dest_dir,
            sp3_type=sp3_selected_type)


@cli.command()
@click.argument('time', type=DateTime())
@click.option('--nav-type', '-t', required=True, type=EnumType(NavTypes))
@click.argument('dest_dir')
def download_nav(time, dest_dir, nav_type):
    NavDownloader().download(
        time,
        dest_dir,
        nav_file_type=nav_type)


@cli.command()
@click.argument('time', type=DateTime())
@click.option('--delta', type=TimeDelta(), default="-9w")
@click.argument('dest_dir')
def download_nanu(time, delta, dest_dir):
    start_date = min(time, time + delta)
    end_date = max(time, time + delta)
    NanuDownloader().download(start_date, end_date, dest_dir)


@cli.command()
@click.argument('time', type=DateTime())
@click.argument('dest_dir')
@click.option('--erp-type', required=True, type=EnumType(ErpTypes))
def download_erp(time, dest_dir, erp_type):
    ErpDownloader().download(time, dest_dir, erp_type=erp_type)


@cli.group()
@click.pass_context
@click.option('--output-folder', '-o')
def nagu(ctx, output_folder):
    ctx.obj = NAGUFetcher(output_folder)


@nagu.command()
@click.pass_context
def active(ctx):
    ctx.obj.download_active()


now = datetime.now()


@nagu.command()
@click.pass_context
@click.option('--start-date', '-s', type=DateTime(),
              default=(now - timedelta(days=90)).strftime('%Y-%m-%dT%H:%M:%S'))
@click.option('--end-date', '-e', type=DateTime(),
              default=(now).strftime('%Y-%m-%dT%H:%M:%S'))
def archive(ctx, start_date, end_date):
    ctx.obj.download_archive(start_date, end_date)


@cli.command()
@click.option('--time', '-t', type=DateTime(),
    default=now.strftime('%Y-%m-%dT%H:%M:%S'))
@click.option('--ionex-type',type=EnumType(IonexTypes),required=True)
def download_ionex(time,ionex_type):
    IonexDownloader(file_type=ionex_type).download(time=time,dest_folder="/tmp")
    print(time)
    pass

if __name__ == "__main__":
    cli()
