import click
import json
import os
import yaml
import re
import exo.utilities.fetcher.read_stations_from_caster


def write_coordinates_to_file(station_data, file_name, output_folder):
    with open(os.path.join(output_folder, file_name), 'w') as write_to:
        for station in station_data:
            write_to.write(F"{station['longitude']}, {station['latitude']}\n")


def write_names_to_file(station_data, file_name, output_folder):
    with open(os.path.join(output_folder, file_name), 'w') as write_to:
        for item in station_data:
            write_to.write("%s\n" % item)
# this script loads json file with all source tables data, filters stations
# and exports station coordinates, receivers and names according to
# required constellations


def get_stations_from_sites(sites):
    stations = {}
    for site in sites:
        site_info = read_stations_from_caster.get_stations_info_from_site(site)
        for stream in site_info:
            station_key = stream['mountpoint'][:4]
            if not re.findall(r"\d\d", stream['mountpoint'][4:6]):
                continue
            if station_key not in stations:
                stations[station_key] = {
                    'latitude': stream['latitude'],
                    'longitude': stream['longitude'],
                    'key': station_key,
                }
            if 'casters' not in stations[station_key]:
                stations[station_key]['casters'] = {}
            stations[station_key]['casters'][site] = stream
    return stations


def filter_duplicated_stations(stations):
    locations = dict()
    output = {}
    for key, station in stations.items():
        location = str(station['latitude']) + ", " + str(station['longitude'])
        if location not in locations:
            output[key] = station
            locations[location] = station
        else:
            print(
                F"location: {location} from station {key} already_exists in: {locations[location]['key']}")
    return output


@click.command()
@click.option("--sites-file", required=True,
              help="yaml of list of sites example: \n- http://site1\n- http://site2")
@click.option('--output_folder', default=os.getcwd())
def cli(output_folder, sites_file):
    """Generate site.
    cli --site-file FILE


    sites-flie need to be yaml with a list of sites

    example sites file

    ---\n
    - "http://www.igs-ip.net/"\n
    - "https://cddis-caster.gsfc.nasa.gov"\n
    - "rt.igs.org:2101"
    """
    sites = yaml.safe_load(open(sites_file, 'r').read())
    data = get_stations_from_sites(sites)
    data = filter_duplicated_stations(data)

    support_const = ["GPS", "GAL", "BDS"]
    for station, station_data in data.items():
        systems = []
        for caster in station_data["casters"].values():
            for System in caster["System"]:
                if System not in systems:
                    systems.append(System)
        station_data["System"] = systems
        station_data['number_of_casters'] = len(station_data['casters'])

    # filter stations according to properties
    stations = data.values()
    GAL_GPS_BDS_stations = [station for station in stations if all(
        [system in station["System"] for system in support_const])]
    three_caster_GAL_GPS_BDS_stations = [
        station for station in GAL_GPS_BDS_stations if station['number_of_casters'] == 3]
    # get data from nested dictionary
    station_name = []
    receiver_name = []
    for station in three_caster_GAL_GPS_BDS_stations:
        station_name.append(
            station['casters']['http://www.igs-ip.net/']['mountpoint'])
        receiver_name.append(
            station['casters']['http://www.igs-ip.net/']['Generator'])
    # print total number of stations
    print("total number of available stations:", len(data))
    print("number of stations supporting GPS + GAL + BDS:",
          len(GAL_GPS_BDS_stations))
    print("number of GPS + GAL + BDS stations disseminated via all 3 casters:",
          len(three_caster_GAL_GPS_BDS_stations))
    # write station coordinates and names to file
    write_coordinates_to_file(stations, 'all_station_coord.txt', output_folder)
    write_coordinates_to_file(GAL_GPS_BDS_stations,
                              'GAL_GPS_BDS_station_coord.txt', output_folder)
    write_coordinates_to_file(
        three_caster_GAL_GPS_BDS_stations,
        'GAL_GPS_BDS_from_3_casters_coord.txt',
        output_folder)
    # Names and receivers: 3-caster stations supporting GAL + GPS + BDS
    write_names_to_file(
        station_name, 'GAL_GPS_BDS_from_3_casters_names.txt', output_folder)
    write_names_to_file(
        receiver_name,
        'GAL_GPS_BDS_from_3_casters_receivers.txt',
        output_folder)


if __name__ == '__main__':
    cli()
