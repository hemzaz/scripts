from exo.utilities import s3
import yaml
import json
import logging
import os
import time
from collections import namedtuple
from json import dumps
from pathlib import PurePath, PurePosixPath

import click
from exo.utilities.s3 import (download_file, list_files, object_exists,
                              put_tags, write_to_key)

logging.basicConfig(format='%(levelname)s: %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)


@click.command()
@click.option('--s3-path',
              type=str,
              default="s3://lear-exo-foc-staging-tropo-compute-result/v1/2021/05/03/00",
              help="metadata file path on S3 (e.g. 's3://lear-exo-foc-staging-tropo-compute-result/v1/2021/05/03/00'")
@click.option('--local-path', type=str, default=".",
              help="Local path for download destination (e.g. 'tropo')")
def cli(s3_path, local_path):
    logger.info("Starting Tropo downloader:")
    logger.info("=" * 30)
    logger.info('S3-path= %s' % s3_path)

    try:
        data = json.loads(s3.get_object(F'{s3_path}/inputs-metadata.json'))
    except Exception as err:
        logger.error(F'Could not download the metadata file: {err}')
        return 

    dest_folder = os.path.join(local_path, 'inputdir')
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder, exist_ok=True)

    files_count = len(data['files'])
    logger.info(F'Downloading {files_count} files:')

    for c, file in enumerate(data['files']):
        logger.info(F'[{c+1:3d}] \t {file["name"]}')
        s3.download_file(key=file['s3_path'], dest_file=os.path.join(
            dest_folder, file['name']))

    config = yaml.safe_load(s3.get_object(F'{s3_path}/used-config.yaml'))
    config['outdir'] = F'{local_path}/output'
    config['inputdir'] = F'{local_path}/inputdir'
    config['logdir'] = F'{local_path}/logdir'
    config['processeddir'] = F'{local_path}/processeddir' 

    with open(os.path.join(dest_folder, f'config.yaml'), 'w') as f:
        f.write(yaml.dump(config))