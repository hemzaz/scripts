from exo.utilities import sns
from exo.applications.configuration_api.api import Api
from concurrent.futures import ThreadPoolExecutor
import click
import datetime
import time
import os
from contextlib import contextmanager
import json
from exo.utilities import s3
from io import BytesIO
import tarfile
import io
import yaml
import copy
import subprocess
import tempfile
import shutil
import gzip
from crontab import CronTab
from exo.utilities.highrate_app_utils.products import ProductInput, ProductRequirement, DynamicProductRequirement
from exo.utilities.highrate_app_utils.nav_input import NavInput
from exo.utilities.highrate_app_utils.obs_input import ObsInput
from exo.utilities.highrate_app_utils.softlink import softlink
from exo.iono.high_rate import IonoHighrateSearcher, NoLatestRunFound, get_run_info
from exo.utilities.tar_creator import create_tar
import logging
from exo.calibration.calibration_runs_utils import get_run_info as calibration_run_info
from prometheus_client import start_http_server, Gauge, Counter

logger = logging.getLogger(__name__)


CLEAN_OBS_SUCESS_COUNTER = Counter('operation_success', 'Cleanobs success', ['receiver'])
CLEAN_OBS_FAILED_COUNTER = Counter('operation_failed', 'Cleanobs Failed', ['receiver'])
LAST_RUN_TIME =  Gauge('last_run_time', 'last_run_time',['what'])
INPROGRESS =  Gauge('inprogress_running', 'inprogress',['what'])

def run_cleanobs(config, receivers):
    config = copy.deepcopy(config)
    config_file = tempfile.mktemp(F'-{"_".join(receivers)}-clean-obs.yml')
    receivers = receivers
    config['receivers'] = receivers

    with open(config_file, 'w') as f:
        config_yaml = yaml.dump(json.loads(
            json.dumps(config)), default_flow_style=False)
        f.write(config_yaml)
    try:
        subprocess.check_output(['/app/run_ionocleanobsapp.sh', '/mcr/v93',
                                 config_file])
        CLEAN_OBS_SUCESS_COUNTER.labels('-'.join(receivers)).inc()
        return receivers
    except subprocess.CalledProcessError:
        CLEAN_OBS_FAILED_COUNTER.labels('-'.join(receivers)).inc()
        logger.error(F"Failed to run cleanobs for receivers:{receivers}")
        return []


#@INPROGRESS.labels('vtec_correction').track_inprogress()
def run_vtec_correction(config):
    config = copy.deepcopy(config)
    config_file = tempfile.mktemp(F'-vtec_correction_config.yml')
    with open(config_file, 'w') as f:
        config_yaml = yaml.dump(json.loads(
            json.dumps(config)), default_flow_style=False)
        f.write(config_yaml)
    logger.info(F"started vteccorrectionsapp")
    subprocess.check_call(['/app/run_vteccorrectionsapp.sh', '/mcr/v93',
                           config_file])


#@INPROGRESS.labels('vtec_stddev').track_inprogress()
def run_vtec_stddev(config):
    config = copy.deepcopy(config)
    config_file = tempfile.mktemp(F'-vtec_stddev_config.yml')

    with open(config_file, 'w') as f:
        config_yaml = yaml.dump(json.loads(
            json.dumps(config)), default_flow_style=False)
        f.write(config_yaml)
    logger.info(F"started vtecstddevmapapp")
    subprocess.check_call(['/app/run_vtecstddevmapapp.sh', '/mcr/v93',
                           config_file])


class Main():
    def __init__(self, config):
        self._config = config
        start_http_server(int(self._config.get('metrics_port','9094')))

        self._configuration_api = Api(url=self._config['calibrations_api_url'])
        self._working_folder = '/mnt/working_folder'
        self._time = None
        self._last_download_vtec_metadata = None
        self._receivers = yaml.safe_load(os.environ['STATIONS'])['stations']

    def _send_done_to_sns(self):
        logger.info('send_sns done')
        sns.publish(
            arn=self._config['on_new_vtec_done_arn'], message=json.dumps(self._last_run_info_data))

    def _run_cleanobs(self):
        logger.info('cleanobs')
        cleanobs_config = yaml.safe_load(
            open('/etc/cleanobs_config/config.yaml').read())
        cleanobs_config['path'] = self._run_working_folder()
        cleanobs_config['iri_data_fullpath'] = '/mnt/working_folder/run/products/iri_data'
        cleanobs_config['time']['propagation_start_time_GPST'] = F"{self._time:%Y-%m-%dT%H:%M:00}"
        cleanobs_config['time']['cleanobs_time_span_hours'] = int(
            (self._time - self._estimation_start_time).seconds/3600) + 14
        receivers = [x['name'][:4] for x in self._receivers]
        with ThreadPoolExecutor(12) as executor:
            executor.map(lambda x: run_cleanobs(
                config=cleanobs_config, receivers=[x]), receivers)

    def _run_iono(self):
        logger.info('run_iono')
        config = yaml.safe_load(open('/etc/vtec_config/config.yaml').read())
        config['path'] = self._run_working_folder()
        config['time']['cleanobs_time_span_hours'] = int(
            (self._time - self._estimation_start_time).seconds/3600) + 14
        config['time']['propagation_start_time_GPST'] = F"{self._time:%Y-%m-%dT%H:%M:00}"
        config['time']['estimation_start_time_GPST'] = F"{self._estimation_start_time:%Y-%m-%dT%H:%M:00}"
        receivers = [x['name'][:4] for x in self._receivers]
        config_file = tempfile.mktemp(F'-iono.yml')
        config['receivers'] = receivers
        with open(config_file, 'w') as f:
            config_yaml = yaml.dump(json.loads(
                json.dumps(config)), default_flow_style=False)
            f.write(config_yaml)
        try:
            logger.info(F"Started iono")
            subprocess.check_call(['/app/run_ionohighrateapp.sh', '/mcr/v93',
                                   config_file])
            return receivers
        except subprocess.CalledProcessError:
            print(F"Failed to run iono for receivers:{receivers}")
            return []

    def _upload_file(self, source, to):
        s3.upload_file(source, to=F"{self._get_save_path()}/{to}")

    def _retry_id(self):
        return os.environ['POD_NAME'].split('-')[-1]

    def _get_save_path(self):
        return F"{self._config['s3_output']}/{self._calibration_time():%Y/%m}/{self._calibration_information['id']}/{self._time:%Y-%m-%dT%H-%M-%S}/{self._retry_id()}"


    def _write_run_info(self):
        logger.info('write_run_info')
        if 'last_download_vtec_metadata' in self._last_download_vtec_metadata:
            del self._last_download_vtec_metadata['last_download_vtec_metadata']

        self._last_run_info_data = dict(
                tags=json.loads(os.environ['LABELS_JSON']),
                calibration_info=self._calibration_information,
                time=F"{self._time:%Y-%m-%dT%H:%M:%S}",
                estimation_start_time=F"{self._estimation_start_time:%Y-%m-%dT%H:%M:%S}",
                s3_run_path=self._get_save_path(),
                vtec_s3_path = F"{self._get_save_path()}/xf.tar.gz",
                last_download_vtec_metadata = self._last_download_vtec_metadata
            )
        s3.write_to_key(json.dumps(self._last_run_info_data), F'{self._get_save_path()}/run_info.json')

    def run_once(self):
        LAST_RUN_TIME.labels('all').set_to_current_time()
        self._time = datetime.datetime.utcnow()
        self._time = self._time - datetime.timedelta(
            minutes=self._time.minute % 5, seconds=self._time.second, microseconds=self._time.microsecond)
        logger.info(F'run {self._estimation_start_time} to {self._time}')
        self._write_run_info()
        with self._prepare_input():
            self._run_cleanobs()
            self._run_iono()
            config = json.loads(json.dumps(
                self._config['vtec_correction_config']))
            config['estimates_path'] = os.path.join(
                self._run_working_folder(), 'iono-output', 'est')
            config['output_path'] = self._correction_path()
            run_vtec_correction(config)
            config = json.loads(json.dumps(self._config['vtec_std_config']))
            config['estimates_path'] = os.path.join(
                self._run_working_folder(), 'iono-output', 'est')
            config['input_path'] = os.path.join(
                self._run_working_folder(), 'iono-output', 'est')
            config['output_path'] = self._vtec_std_path()
            run_vtec_stddev(config)
            self._save_everything()
            self._estimation_start_time = self._time
        self._send_done_to_sns()

    def _correction_path(self):
        return os.path.join(self._run_working_folder(), 'vtec_correction')

    def _vtec_std_path(self):
        return os.path.join(self._run_working_folder(), 'vtec_std')

    def _create_tar_and_upload(self, path, to,**kwargs):
        tar_file = create_tar(path,**kwargs)
        self._upload_file(source=tar_file, to=to)
        os.remove(tar_file)

    def _save_everything(self):
        self._create_tar_and_upload(path=os.path.join(self._run_working_folder(), 'iono-output', 'est', F'xf_{self._time:%Y%m%d_%H%M%S}.mat'), to="xf.tar.gz")
        shutil.rmtree(self._last_iono_folder())
        shutil.copyfile(
            os.path.join(self._run_working_folder(), 'iono-output', 'est', F'xf_{self._time:%Y%m%d_%H%M%S}.mat'),
            os.path.join(self._last_iono_folder(), F'xf_{self._time:%Y%m%d_%H%M%S}.mat')
        )
        self._last_download_vtec_metadata = self._last_run_info_data

        self._create_tar_and_upload(os.path.join(
            self._run_working_folder(), 'nav'), "nav.tar.gz",no_dir_name=True)
        self._upload_file(source=os.path.join(self._run_working_folder(
        ), 'products', 'metadata.json'), to='products-metadata.json')
        self._upload_file(source=os.path.join(
            self._run_working_folder(), 'summary', 'summary.json'), to='summary.json')
        self._save_obs_chk()
        self._create_tar_and_upload(
            self._correction_path(), "vtec_correction.tar.gz",no_dir_name=True)
        self._create_tar_and_upload(self._vtec_std_path(), "vtec_std.tar.gz",no_dir_name=True)
        self._create_tar_and_upload(os.path.join(
            self._run_working_folder(), 'iono-output'), "all-iono-output.tar.gz",no_dir_name=True)

        shutil.rmtree(os.path.join(self._run_working_folder(), 'iono-output'))
        shutil.rmtree(self._correction_path())
        shutil.rmtree(self._vtec_std_path())

    def _save_obs_chk(self):
        local_file = tempfile.mktemp()
        subprocess.check_call(['ObservationCheckpointCreator', '--obs-dir', os.path.join(
            self._run_working_folder(), 'obs'), '--file-path', local_file])
        data = open(local_file, 'rb').read()
        s3.write_to_key(data=gzip.compress(data), path=F"{self._get_save_path()}/obs.chk.gz")
        os.remove(local_file)

    def _run_working_folder(self):
        return os.path.join(self._working_folder, 'run')

    def _download_latest_iono_state(self):
        try:
            self._download_latest_iono_state_from_last_run()
        except NoLatestRunFound:
            self._download_iono_statefrom_calibration()

    def _last_iono_folder(self):
        path = os.path.join(self._run_working_folder(), 'last_iono_output')
        os.makedirs(path, exist_ok=True)
        return path

    def _download_latest_iono_state_from_last_run(self):
        path = IonoHighrateSearcher(s3_path=self._config['s3_output']).latest_done(
            calibration_id=self._calibration_information['id'])
        byte_array = s3.get_object(F"{path}/xf.tar.gz")
        file_like_object = io.BytesIO(byte_array)
        archive_file = tarfile.open(fileobj=file_like_object)
        archive_file.extractall(self._last_iono_folder())
        run_info =  get_run_info(path)
        self._last_download_vtec_metadata = run_info
        self._estimation_start_time = datetime.datetime.strptime(run_info['time'], "%Y-%m-%dT%H:%M:%S")

    def _download_iono_statefrom_calibration(self):
        byte_array = s3.get_object(F"{self._calibration_information['s3_run_path']}/iono-est-xf.tar.gz")
        file_like_object = io.BytesIO(byte_array)
        archive_file = tarfile.open(fileobj=file_like_object)
        archive_file.extractall(self._last_iono_folder())
        run_info = calibration_run_info(self._calibration_information['s3_run_path'])
        data = {'vtec_s3_path': F"{self._calibration_information['s3_run_path']}/iono-est-xf.tar.gz"}
        self._last_download_vtec_metadata = {**run_info,**data};
        self._estimation_start_time = self._calibration_time()

    @contextmanager
    def _prepare_input(self):
        os.makedirs(self._run_working_folder(), exist_ok=True)
        with ProductInput(inputs=[
            ProductRequirement(
                source_dir=os.path.join(
                    self._working_folder, 'calibration_products'),
                needed_products=['^Antex/', '^DCB/', '^ERP/', "^Sinex/", '^olp/', "^iri_data/"]),
            DynamicProductRequirement(
                source_dir=os.path.join(
                    self._working_folder, 'realtime_products'),
                needed_products=['^nanu/', '^nagu/'])
        ]).prepare(dest_folder=os.path.join(self._run_working_folder(), 'products')) as e:
            with NavInput(working_folder=self._working_folder,
                          run_folder=self._run_working_folder()).prepare():
                with ObsInput(working_folder=self._working_folder,
                              run_folder=self._run_working_folder()).prepare():
                    yield

    def _calibration_time(self):
        return datetime.datetime.strptime(self._calibration_information['time'], "%Y-%m-%dT%H:%M:%S")

    def run(self):
        self._calibration_information = json.load(
            open('/tmp/calibration-info.json'))
        self._download_latest_iono_state()
        while(datetime.datetime.now() - self._estimation_start_time > datetime.timedelta(
                minutes=self._config['time_between_estimation_and_current_time_to_start_cron'])):
            self.run_once()
        logger.info("move to cron")
        x = CronTab(self._config['cron'])
        while(True):
            time_to_sleep = x.next(default_utc=True)
            logger.info(F'waiting {time_to_sleep} for the next run')
            time.sleep(time_to_sleep)
            logger.info("start run")
            self.run_once()
            logger.info("update configuration api")
            self._configuration_api.set_metadata(
                id=self._calibration_information['id'], key="vtec_ready", value="true")
            self._configuration_api.set_metadata(id=self._calibration_information['id'], key=F"vtec_ready_{self._retry_id()}", value="true")
            logger.info("update configuration done")


@click.group()
def cli():
    logging.basicConfig(level=logging.INFO)
    pass



@cli.command()
@click.option('--s3-path', default="s3://lear-exo-foc-staging-iono-vtec-vtec")
@click.option('--calibration-id', required=True)
def get_latest(calibration_id, s3_path):
    x = IonoHighrateSearcher(s3_path=s3_path).latest_done(
        calibration_id=calibration_id)
    print(x)


@cli.command()
@click.option('--config', required=True)
def run(config):
    Main(config=yaml.safe_load(open(config).read())).run()


if __name__ == '__main__':
    cli()
