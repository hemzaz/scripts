import requests
import json


class Api:
    def __init__(self, url):
        self._url = url

    def set_metadata(self,id,key,value):    
        response = requests.put(F"{self._url}/api/configuration/{id}/metadata",json=dict(key=key,value=value))
        response.raise_for_status()

    def read_configurations(self):
        response = requests.get(F"{self._url}/api/configurations")
        response.raise_for_status()
        data = response.json()
        for item in data:
            item['data'] = json.loads(item['json_data'])
        return data

    def deactivate(self,id):
        response = requests.put(F"{self._url}/api/configuration/{id}/deactivate")
        response.raise_for_status()


    def push(self, id, time, data):
        data = {
            "id": id,
            "time": time,
            "json_data": json.dumps(data),
        }
        url = F"{self._url}/api/configurations"
        response = requests.put(url, json=data)
        response.raise_for_status()

