from flask import abort
import boto3
import json
from datetime import datetime
from boto3.dynamodb.conditions import Key
dynamodb = boto3.resource('dynamodb')

class ConfigurationNotFoundException(Exception):
  pass

class ConfigurationAlreadyExistsException(Exception):
  pass

class ConfigurationDAL:
  def __init__(self,config):
    self.configuration_table = dynamodb.Table(config['tables']['configuration_arn'].split('/')[-1])
    #self.on_change_event = sns.Topic(config['topics']['on_configuration_changed_sns_arn'])
  

  def deactivate(self,id):
        self.configuration_table.update_item(
         Key=dict(Id=id),
         UpdateExpression = F"Set Active = :v",
           ExpressionAttributeValues={
            ':v': 'false'
        },
      )

  def add_metadata(self,id,key,value):
    current_configuration = self.get(id)
    if key in current_configuration['Metadata'] and value == current_configuration['Metadata'][key]:
      return
    else:
      self.configuration_table.update_item(
           Key=dict(Id=id),
           UpdateExpression = F"Set Metadata.{key} = :v",
             ExpressionAttributeValues={
              ':v': value
          },
        )
      self.configuration_table.update_item(
           Key=dict(Id=id),
           UpdateExpression = F"Set Metadata.{key}_change_time = :v",
             ExpressionAttributeValues={
              ':v': datetime.utcnow().isoformat()
          },
        )
  
  def add(self,id,time,data):
    try:
      response = self.configuration_table.put_item(
         Item={
                'Id': id,
                'Time':time,
                'register_time': datetime.utcnow().isoformat(),
                'Active': 'true',
                'DATA' : json.dumps(data),
                "Metadata": {}
              },
        ConditionExpression='attribute_not_exists(Id)'
      )
    except dynamodb.meta.client.exceptions.ConditionalCheckFailedException:
      raise ConfigurationAlreadyExistsException(F"Configuration Allready exists: id {time}")
    
    

  def get(self,id):
    response = self.configuration_table.get_item(Key= {
      "Id" :id
      })
    if 'Item' not in response:
      raise ConfigurationNotFoundException(F"{id} not found in database")
    return  response['Item']

  def list_all_active_configuration(self):
    data = self.configuration_table.query(IndexName='Active',KeyConditionExpression=Key('Active').eq('true'))
    return dict([(item['Id'],item) for item in data['Items']])
    