
from . dal import ConfigurationDAL
from . app import flask_app
import click
import yaml
from functools import partial

from . api import Api
import boto3
import json
sns = boto3.resource('sns')




def _on_change(sns_topic):
  print(sns_topic.publish(Message="Something Changed"))


@click.group()
def cli():
  pass

@cli.group()
@click.option('--url',help="configuration_url",default = "http://calibrations-api.foc-staging.lear-exo.com")
@click.pass_context
def commands(ctx,url):
  ctx.obj = Api(url = url)



@commands.command()
@click.option('--configuration-id',required=True)
@click.argument('key')
@click.argument('value')
@click.pass_context
def set_metadata(ctx,configuration_id,key,value):
  api = ctx.obj
  api.set_metadata(id = configuration_id, key=key, value = value)
  
@commands.command()
@click.pass_context
def list(ctx):
  api = ctx.obj
  print(json.dumps(api.read_configurations(),indent=4, sort_keys=True))
  


@cli.command('app')
@click.option('--config',required=True)
def app_command(config):
  global DAL
  config = yaml.safe_load(open(config).read())
  app.DAL = ConfigurationDAL(config)
  app.on_change = partial(_on_change,sns.Topic(config['topics']['on_configuration_changed_sns_arn']))
  flask_app.run(host= '0.0.0.0',debug=True)

