
from flask import Flask,abort
from flask_restplus import Api, Resource
from flask_restplus import fields
import json
from .dal import ConfigurationAlreadyExistsException,ConfigurationNotFoundException
flask_app = Flask(__name__)
api = Api(app = flask_app)

ns = api.namespace('api', description='Main APIs')

DAL = None
on_change = None

def _on_change():
  if on_change!=None:
    on_change()

configuration_model = api.model('Configuration', {
    'time': fields.String,
    'json_data': fields.String,
    'active': fields.Boolean,
    'id': fields.String,
    'register_time': fields.String,
    'metadata': fields.Raw
})

sublimited_configuration_model = api.model('Configuration', {
    'id': fields.String,
    'time': fields.String,
    'json_data': fields.String,
})

metadata_model = api.model('Metadata', {
    'key': fields.String,
    'value': fields.String,
})

def dal_to_configuration(dal_object):
  return dict(
    id = dal_object['Id'],
    time = dal_object['Time'],
    json_data = dal_object['DATA'],
    active = dal_object['Active'],
    register_time = dal_object.get('register_time','not defined'),
    metadata= dal_object['Metadata'] if 'Metadata' in dal_object else {})

@ns.route("/health")
class health(Resource):
  def get(self):
    return "OK",200


@ns.route("/configurations")
class configurations(Resource):

  @ns.marshal_list_with(configuration_model)
  def get(self):
    return [ dal_to_configuration(x) for x in DAL.list_all_active_configuration().values()]
  

  @ns.expect(sublimited_configuration_model)
  def put(self):
    try:
      DAL.add(id=api.payload['id'],
           time=api.payload['time'],
           data = json.loads(api.payload['json_data']))
      _on_change()
    except ConfigurationAlreadyExistsException as ex:
      abort(403,ex)
    return {},201


@ns.route("/configuration/<string:configuration_id>")
class configuration(Resource):
  @ns.marshal_with(configuration_model)
  def get(self,configuration_id,**kwargs):
    try:
      return dal_to_configuration(DAL.get(configuration_id))
    except ConfigurationNotFoundException as ex:
      raise abort(404,ex)
    

@ns.route("/configuration/<string:configuration_id>/metadata")
class configurationMetadata(Resource):
  @ns.expect(metadata_model)
  def put(self,configuration_id,**kwargs):
    DAL.add_metadata(configuration_id,api.payload['key'],api.payload['value'])
    _on_change()
    return {},200

@ns.route("/configuration/<string:configuration_id>/deactivate")
class configurationMetadata(Resource):
  def put(self,configuration_id,**kwargs):
    DAL.deactivate(configuration_id)
    _on_change()
    return {},200