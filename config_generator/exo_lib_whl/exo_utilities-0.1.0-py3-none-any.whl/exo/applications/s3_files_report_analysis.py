import click
import re
import pandas
import json
import pandas
from pandas import DataFrame
from datetime import datetime
from exo.utilities import s3
from IPython import embed
import gzip
import os


@click.group()
def cli():
    pandas.options.display.max_rows = 100
    pass


@cli.command()
@click.argument('file', type=click.Path())
@click.argument('output_folder', type=click.Path())
def analysis(file, output_folder):
    os.makedirs(output_folder, exist_ok=True)
    df = pandas.read_csv(file)
    df['first_folder'] = df['Key'].apply(lambda x: x.split('/')[0])
    df['file_name'] = df['Key'].apply(lambda x: x.split('/')[-1])
    (df.groupby(['first_folder']).sum(['Size']) /
     1e9).to_csv(os.path.join(output_folder, 'first_folder data.csv'))
    zone_info = df[df['first_folder'] == 'zone']
    zone_info['zone_info'] = zone_info['Key'].apply(
        lambda x: '/'.join(x.split('/')[:2]))
    (zone_info.groupby(['zone_info']).sum(['Size']) /
     1e9).to_csv(os.path.join(output_folder, 'zone size.csv'))
    staging_info = zone_info[zone_info['zone_info'] == 'zone/staging']
    staging_info['staging_info'] = staging_info['Key'].apply(
        lambda x: '/'.join(x.split('/')[:3]))
    (staging_info.groupby(['staging_info']).sum(
        ['Size']) / 1e9).to_csv(os.path.join(output_folder, 'zone_by_product.csv'))
    iono_folder = os.path.join(output_folder, 'iono')
    os.makedirs(iono_folder, exist_ok=True)
    iono = staging_info[staging_info['staging_info'] == 'zone/staging/iono']
    iono['iono'] = staging_info['Key'].apply(
        lambda x: '/'.join(x.split('/')[:4]))
    (iono.groupby(['iono']).sum(['Size']) /
     1e9).to_csv(os.path.join(iono_folder, 'iono-by-folder.csv'))
    iono_runs = iono[iono['iono'] == 'zone/staging/iono/runs']
    iono_runs['month'] = iono_runs['Key'].apply(
        lambda x: '/'.join(x.split('/')[:6]))
    print('-' * 50)
    print('iono_runs_by_month')
    print('-' * 50)
    (iono_runs.groupby(['month']).sum(
        ['Size']) / 1e9).to_csv(os.path.join(iono_folder, 'iono-runs-by-month.csv'))
    print('iono_runs_by_file_type')
    files_by_size = iono_runs.groupby(
        ['month', 'file_name']).sum(['Size']) / 1e9
    (iono_runs.groupby(['month', 'file_name']).sum(['Size']) / 1e9).to_csv(
        os.path.join(iono_folder, 'iono-runs-by-month-and-file-type.csv'))

    embed()


@cli.command()
@click.argument('result_file')
def download_latest(result_file):
    base = "s3://lear-exo-raanan/buckets-invetory/lear-exo/allfiles"
    folders = s3.list_dir(base)
    run_regex = r'(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d)-(\d\d)Z'
    run_folders = sorted(
        [folder for folder in folders if re.findall(run_regex, folder)])
    latest_folder = run_folders[-1]
    manifest_path = F"{base}/{latest_folder}/manifest.json"
    main_manifest = json.loads(s3.get_object(manifest_path))
    with open(result_file, 'wb') as res:
        res.write(main_manifest['fileSchema'].replace(' ', '').encode('utf-8'))
        res.write('\n'.encode('utf-8'))
        bucket_name = main_manifest['destinationBucket'].split(":::")[1]
        for i, f in enumerate(main_manifest['files']):
            file_path = F"s3://{bucket_name}/{f['key']}"
            x = gzip.decompress(s3.get_object(file_path))
            res.write(x)


if __name__ == '__main__':
    download_files()
