import click
import os
import subprocess
import json
import tempfile
import tarfile
from exo.utilities.s3 import get_object, upload_file
import io
import logging
from exo.utilities.tar_creator import create_tar
logging.basicConfig(level=logging.INFO)


class runner:
    def __init__(self, s3_inputs, parameters, script, script_type, s3_outputs):
        self._s3_inputs = s3_inputs
        self._s3_outputs = s3_outputs
        self._params = parameters
        self._script = script
        self._script_type = script_type

    def _param_fixes(self, string_to_replace):
        for key, value in self._params.items():
            string_to_replace = string_to_replace.replace(F"Ref::{key}", value)
        return string_to_replace

    def _static_artifects(self):
        if "STATIC_INPUT_ARTIFECTS" in os.environ:
            static_artifects = json.loads(
                self._param_fixes(
                    os.environ['STATIC_INPUT_ARTIFECTS']))
            for x in static_artifects:
                with open(self._param_fixes(x['to'], 'w')) as f:
                    f.write(self._param_fixes(x['content']))

    def _fetch_s3_inputs(self):
        for key, dest in self._s3_inputs.items():
            key = self._param_fixes(key)
            logging.info(F'fetching {key} to {dest}')
            obj = get_object(key)
            if key.endswith('.tar.gz'):
                tarfile.open(
                    fileobj=io.BytesIO(obj)
                ).extractall(dest)
            else:
                raise NotImplementedError('key type not supported')

    def _push_s3_outputs(self):
        for src, dest in self._s3_outputs.items():
            dest = self._param_fixes(dest)
            tar_created = create_tar(src)
            logging.info(F'pushing to {dest}')
            upload_file(tar_created, dest)
            os.remove(tar_created)

    def __call__(self):
        self._static_artifects()
        self._fetch_s3_inputs()
        s = tempfile.mktemp()
        with open(s, 'w') as f:
            f.write(self._param_fixes(self._script))
        subprocess.check_call([self._script_type, s])
        self._push_s3_outputs()


@click.command()
@click.option('--s3-input', type=(str, str), help="s3Src,Dest", multiple=True)
@click.option('--s3-output', type=(str, str),
              help="srd,s3_dest", multiple=True)
@click.option('--script-type', type=str, default="bash")
@click.option('--script', type=str, required=True)
@click.option('--parameter', type=(str, str), multiple=True)
def cli(s3_input, s3_output, parameter, script, script_type):
    runner(s3_outputs=dict(list(s3_output)),
           s3_inputs=dict(list(s3_input)),
           script=script,
           parameters=dict(list(parameter)),
           script_type=script_type)()
