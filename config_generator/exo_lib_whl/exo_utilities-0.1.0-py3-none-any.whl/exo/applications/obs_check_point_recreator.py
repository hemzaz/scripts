import click
from exo.utilities.obs.check_point.recreator import ObsCheckPointRecrator


@click.command()
@click.option("--long-term-storage-s3-prefix",
              default="s3://lear-exo-foc-staging-inputs-ntrips-obs-long-term-storage/obs")
@click.argument('check_point_file')
@click.argument('output_folder')
def cli(long_term_storage_s3_prefix, check_point_file, output_folder):
    ObsCheckPointRecrator(
        check_point_file=check_point_file,
        output_folder=output_folder,
        long_term_storage_s3_prefix=long_term_storage_s3_prefix)()


if __name__ == '__main__':
    cli()
