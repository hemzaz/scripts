import os
import io
from exo.utilities import s3
import json
import yaml


class SummaryFetcher():
    def __init__(self, *args, **kwargs):
        self._s3_prefix = kwargs['s3_prefix']
        self._output_dir = kwargs['output_dir']

    def __call__(self):
        s3_location = F"{self._s3_prefix}/summary.json"
        byte_array = s3.get_object(s3_location)
        with open(os.path.join(self._output_dir, 'summary.json'), 'wb') as f:
            f.write(byte_array)


class ConfigFetcher():
    def __init__(self, *args, **kwargs):
        self._s3_prefix = kwargs['s3_prefix']
        self._output_dir = kwargs['output_dir']

    def __call__(self):
        s3_location = F"{self._s3_prefix}/summary.json"
        byte_array = s3.get_object(s3_location)
        summary_dict = json.loads(byte_array)
        summary_dict['ymlConfig']['path'] = self._output_dir
        with open(os.path.join(self._output_dir, 'config.yml'), 'w') as f:
            f.write(yaml.dump(summary_dict['ymlConfig']))
