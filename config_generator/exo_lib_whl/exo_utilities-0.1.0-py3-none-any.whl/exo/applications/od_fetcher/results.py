import os
import io
import tarfile
from exo.utilities import s3


class MergeFetcher():
    def __init__(self, *args, **kwargs):
        self._s3_prefix = kwargs['s3_prefix']
        self._output_dir = os.path.join(
            kwargs['output_dir'], "results", 'merge')

    def __call__(self):
        s3_location = F"{self._s3_prefix}/merge.tar.gz"
        byte_array = s3.get_object(s3_location)
        file_like_object = io.BytesIO(byte_array)
        archive_file = tarfile.open(fileobj=file_like_object)
        os.makedirs(self._output_dir, exist_ok=True)
        archive_file.extractall(self._output_dir)


class PropFetcher():
    def __init__(self, *args, **kwargs):
        self._s3_prefix = kwargs['s3_prefix']
        self._output_dir = os.path.join(
            kwargs['output_dir'], "results", 'prop')

    def __call__(self):
        s3_location = F"{self._s3_prefix}/prop.tar.gz"
        byte_array = s3.get_object(s3_location)
        file_like_object = io.BytesIO(byte_array)
        archive_file = tarfile.open(fileobj=file_like_object)
        os.makedirs(self._output_dir, exist_ok=True)
        archive_file.extractall(self._output_dir)


class EstFetcher():
    def __init__(self, *args, **kwargs):
        self._s3_prefix = kwargs['s3_prefix']
        self._output_dir = os.path.join(kwargs['output_dir'], "results", 'est')

    def __call__(self):
        s3_location = F"{self._s3_prefix}/est.tar.gz"
        byte_array = s3.get_object(s3_location)
        file_like_object = io.BytesIO(byte_array)
        archive_file = tarfile.open(fileobj=file_like_object)
        os.makedirs(self._output_dir, exist_ok=True)
        archive_file.extractall(self._output_dir)
