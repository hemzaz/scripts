import os
import json
from more_itertools import first
from exo.utilities import s3
from exo.utilities import s3_file_archiver


class ProductsFetcher():
    def __init__(self, *args, **kwargs):
        self._s3_prefix = kwargs['s3_prefix']
        self._output_dir = os.path.join(kwargs['output_dir'], "products")

    def __call__(self):
        metadata_json = F"{self._s3_prefix}/products-metadata.json"
        loaded_json = json.loads(s3.get_object(metadata_json))
        for file in loaded_json['files']:
            file_metadata = first(file['file_metadata']['files'].values())
            s3_location = file_metadata['s3_location']
            compress = file_metadata.get('compress', 'none')
            print(F'downloading: {s3_location}')
            file_data = s3.get_object(path=s3_location)
            file_data = s3_file_archiver.uncommpress_file(
                compress=compress, object_data=file_data)
            dest_path = os.path.join(
                self._output_dir, file['relative_dest_path'])
            os.makedirs(os.path.split(dest_path)[0], exist_ok=True)
            with open(dest_path, 'wb') as f:
                f.write(file_data)
