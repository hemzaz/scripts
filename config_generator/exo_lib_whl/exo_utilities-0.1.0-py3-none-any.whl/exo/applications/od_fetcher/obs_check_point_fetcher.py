from exo.utilities.obs.check_point.recreator import ObsCheckPointRecrator
import gzip
import tempfile
import os
from exo.utilities import s3


class ObsCheckPointFetcher():
    def __init__(self, *args, **kwargs):
        self._s3_prefix = kwargs['s3_prefix']
        self._output_dir = os.path.join(kwargs['output_dir'], "obs")
        self._obs_longterm_storage_s3_prefix = kwargs['obs_longterm_storage_s3_prefix']
        assert self._obs_longterm_storage_s3_prefix, "please set obs_longterm_storage_s3_prefix"

    def __call__(self):
        s3_location = F"{self._s3_prefix}/obs.chk.gz"
        byte_array = s3.get_object(s3_location)
        byte_array = gzip.decompress(byte_array)
        obs_check_point_File = tempfile.mktemp("obs-chk.json")
        with open(obs_check_point_File, 'wb') as f:
            f.write(byte_array)
        ObsCheckPointRecrator(
            check_point_file=obs_check_point_File,
            output_folder=self._output_dir,
            long_term_storage_s3_prefix=self._obs_longterm_storage_s3_prefix)()
