import click
import time
import yaml
import tempfile
import os
import datetime
import subprocess
from exo.utilities.click_types import TimeDelta
from prometheus_client import start_http_server, Gauge

READY_COUNTER = Gauge('ready_counter', 'ready_counter')


@click.command()
@click.option('--base-config', required=True)
@click.option('--every', type=int, default=60*10)
@click.option('--port', type=int, default=9092)
@click.option('--delta-time', type=TimeDelta(),default = '14h')
def cli(base_config, every, port,delta_time):
    start_http_server(port)
    base_config = yaml.safe_load(open(base_config).read())
    original_nav_dir = base_config['rinexConfig']['navDir']
    next_counter = 0
    ready_counter = -1
    READY_COUNTER.set_function(lambda: ready_counter)
    while(True):
        config_file = tempfile.mktemp('-nav.yaml')
        with open(config_file, 'w') as f:
            base_config['rinexConfig']['navDir'] = os.path.join(
                original_nav_dir, str(next_counter))
            f.write(yaml.dump(base_config))
        now = datetime.datetime.utcnow()
        args = ['RinexFromDatabaseGeneratorApp', '--config',config_file,
            '-s',(now - delta_time).isoformat()[:19],
            '-e',now.isoformat()[:19],
             "-st","BRDC00IGS", "-rt","nav"] 
        print(args)
        subprocess.check_call(args
            )
        ready_counter = next_counter
        next_counter = next_counter + 1
        time.sleep(every)
        os.remove(config_file)