import time
import click
import requests
from datetime import datetime
from prometheus_client.parser import text_string_to_metric_families
from prometheus_client.exposition import delete_from_gateway
from ..utilities import click_types


@click.command()
@click.option('--older-then', type=click_types.TimeDelta(),
              default="1h", help="Num of sec to delete older then")
@click.option('--required-label', type=(str, str), multiple=True)
@click.option('--push-gateway', required=True)
def command(push_gateway, older_then, required_label):
    required_labels = dict(required_label)
    request = requests.get(push_gateway + '/metrics', timeout=20)
    request.raise_for_status()
    metrics = list(text_string_to_metric_families(request.text))
    push_time_seconds = [
        metric for metric in metrics if metric.name == 'push_time_seconds']
    if not push_time_seconds:
        print('no push_time_seconds metrics')
    push_time_seconds = push_time_seconds[0]
    now = datetime.now()
    for sample in push_time_seconds.samples:
        grouping_keys = dict(sample.labels)
        if all([label in grouping_keys and required_labels[label] == grouping_keys[label]
                for label in required_labels]) and \
                now - datetime.fromtimestamp(sample.value) > older_then:
            grouping_keys_for_delete = dict(sample.labels)
            del grouping_keys_for_delete['job']
            del grouping_keys_for_delete['instance']
            x = delete_from_gateway(
                push_gateway,
                job=sample.labels['job'],
                grouping_key=grouping_keys_for_delete)
            print(F"Deleted job: {sample.labels['job']} keys:{grouping_keys}")


if __name__ == '__main__':
    command()
