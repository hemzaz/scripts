import click


from exo.utilities.click_types import TimeDelta, S3Path, DateTime

import tempfile
from exo.utilities.obs.obs_archiver import ObsArchiver


@click.group()
def cli():
    pass


@cli.command()
@click.option('--start-time', type=DateTime(), required=True)
@click.option('--delta', type=TimeDelta(), default="1d")
@click.option('--receiver', default=["ALBH"], multiple=True)
@click.argument("dest_s3_prefix", type=S3Path())
def fill(start_time, delta, receiver, dest_s3_prefix):
    ObsArchiver(dest_s3_prefix, receiver).fill(start_time, delta)


@cli.command()
@click.option('--start-time', type=DateTime(), required=True)
@click.option('--delta', type=TimeDelta(), default="1d")
@click.option('--receiver', default=["ALBH"], multiple=True)
@click.argument("dest_s3_prefix", type=S3Path())
@click.argument("dest_folder", type=click.Path())
def restore(start_time, delta, receiver, dest_s3_prefix, dest_folder):
    ObsArchiver(dest_s3_prefix, receiver).restore(
        start_time, delta, dest_folder)
