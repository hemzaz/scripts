import click
import yaml

from .configuration_api.api import Api as ConfigurationApi
from .calibration_api.api import Api as ActiveCalibrationApi, NoActiveCalibrationSet


class App():
    def __init__(self, config):
        self._config = config
        self._configuration_api = ConfigurationApi(
            config['configurations_url'])
        self._active_calibration_api = ActiveCalibrationApi(
            config['active_configuration_url'])
        self._deactivate_configs = []
        self._active_calibrations = None
        self._current_output_configuration = None
        self._expected_metadata_for_ready_configuration = self._config['ready_metadata']

    def _remove_max_old_calibrations(self):
        removed_me = []
        for item in self._active_calibrations[:-self._config['max_active_calibrations']]:
            self._deactivate_configs.append(item['id'])
            removed_me.append(item)
        for item in removed_me:
            self._active_calibrations.remove(item)

    def _deactivate_config(self):
        for id in self._deactivate_configs:
            print(F"deactive old configuration {id}")
            self._configuration_api.deactivate(id)

    def _load_active_calibrations(self):
        self._active_calibrations = self._configuration_api.read_configurations()
        self._active_calibrations.sort(key=lambda item: item['time'])

    def _set_active_calibration(self):
        print(F"setting new active calibration {self._current_output_configuration['id']}")
        self._active_calibration_api.set_current(configuration_id=self._current_output_configuration['id'], data=dict(configuration_data=self._current_output_configuration['data'], setter_data={})
                                                 )

    def __call__(self):
        self._load_active_calibrations()
        if not self._active_calibrations:
            print("Sorry no active calibrations")
            return

        ready_calibrations = [dict(item=item,
                                   ready=self._expected_metadata_for_ready_configuration.items() <= item['metadata'].items())
                              for item in self._active_calibrations]

        if not any([item['ready'] for item in ready_calibrations]):
            print('no ready calibrations')
            if len(self._active_calibrations) > self._config['max_active_calibrations']:
                print('too many active calibrations removing the oldest')
                self._remove_max_old_calibrations()
            print('set the current calibration to the oldest')
            self._current_output_configuration = self._active_calibrations[-1]
        else:
            ready_calibrations_newest_first = ready_calibrations[::-1]
            found = None
            count_not_found = 0
            for item in ready_calibrations_newest_first:
                if found:
                    print(F"deactivate {item['item']['id']} is older then {found['id']}")
                    self._deactivate_configs.append(item['item']['id'])
                else:
                    if item['ready']:
                        found = item['item']
                        print(F"{found['id']} is ready")
                        self._current_output_configuration = found
                    else:
                        if count_not_found >= self._config['max_active_calibrations']:
                            print(F"deactivate {item['item']['id']} reached maximum number of unready config")
                            self._deactivate_configs.append(item['item']['id'])
                        count_not_found = count_not_found + 1
        if self._current_output_configuration:
            try:
                x = self._active_calibration_api.get_current()
                if x['configuration_id'] != self._current_output_configuration['id']:
                    self._set_active_calibration()
            except NoActiveCalibrationSet:
                self._set_active_calibration()

        self._deactivate_config()


@click.command()
@click.argument('config')
def cli(config):
    config = yaml.safe_load(open(config).read())
    app = App(config)()
