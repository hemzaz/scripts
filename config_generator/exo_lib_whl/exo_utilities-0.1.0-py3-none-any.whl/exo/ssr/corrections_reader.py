from statemachine import StateMachine, State
from datetime import timedelta,datetime
from collections import namedtuple

LabelItem = namedtuple('LabelItem',['name','type'])

class RecordType():
  def __init__(self,fields = []):
    self._fields = fields
  def parse(self,line):
    elements = [x for x in line.split(' ') if x!='']
    key = elements[0]
    parameters = {}
    for i,field in enumerate(self._fields):
      parameters[field.name] = field.type(elements[i+1])

    return key,parameters
    
  pass
class CorrectionsReader(StateMachine):
  def __init__(self):
    self._types_of_records = {
      'ORBIT': RecordType(fields = [
          LabelItem('iode',int),
          LabelItem('delta_radial_m',float),
          LabelItem('delta_along_track_m',float),
          LabelItem('delta_cross_track_m',float),
          LabelItem('dot_delta_radial_m_sec',float),
          LabelItem('dot_delta_along_track_m_sec',float),
          LabelItem('dot_delta_cross_track_m_sec',float),
          LabelItem('nav_id',str),
          ]
        ),
      'CLOCK': RecordType(fields = [
          LabelItem('iode',int),
          LabelItem('delta_clock_c0_m',float),
          LabelItem('delta_clock_c1_m_sec',float),
          LabelItem('delta_clock_c2_m_sec2',float),
          ]
        )
    }
    super().__init__()
  search_start_line = State('search_start_line',initial=True)
  sat_reader = State('sat_reader')
  read_sat = search_start_line.to(sat_reader)
  reset = sat_reader.to(search_start_line)
  
  def read(self,data):
    self._results = []
    for line in data.split('\n'):
      self._newline(line)
    return self._results

  def _newline(self,line):
    if self.current_state == self.search_start_line:
      if line[:1] == '>':
        splited = line.split(' ')
        record_type = splited[1]
        if record_type not in self._types_of_records:
          raise Exception(F"Unexpected record type {record_type}")
        self._current_item = {
          'record_type': record_type,
          'time': datetime(*[int(x) for x in splited[2:7]]) +timedelta(seconds = float(splited[7])),
          'num_of_sats':int(splited[9]),
          'ssr_update_interval' : int(splited[8]),
          'sat_info': {}
        }
        self._num_of_expected_sat = int(splited[9])
        self.read_sat()
    elif(self.current_state == self.sat_reader):
      sat_id,parameters = self._types_of_records[self._current_item['record_type']].parse(line)
      self._current_item['sat_info'][sat_id] = parameters
      self._num_of_expected_sat -=1
      if self._num_of_expected_sat == 0:
        self._results.append( self._current_item)
        self.reset()


if __name__=='__main__':
  data = CorrectionsReader().read(data=
  open('/tmp/corrections.txt').read())
  import json
  print(json.dumps(data))