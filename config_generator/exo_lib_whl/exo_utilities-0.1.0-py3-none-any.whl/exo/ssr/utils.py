import re
import json
import itertools
from datetime import datetime, timedelta
from exo.utilities import s3
from exo.utilities.range_s3_search import   list_relevent_runs_by_calibration_id
from concurrent.futures import ThreadPoolExecutor
from enum import Enum 
import io
import tarfile
from exo.ssr.corrections_reader import CorrectionsReader
from more_itertools import first


class ssr_output_type(Enum):
    ts="ts"
    od="od"




def get_corrections(run_s3_path):
    data = s3.get_object(F"{run_s3_path}/correction.tar.gz")
    tar = tarfile.open(fileobj= io.BytesIO(data))
    return tar.extractfile('corrections.txt').read()



def get_run_summary(run):
    return json.loads(s3.get_object(F"{run}/summary.json"))

def summary_exists(run):
    return s3.object_exists(F"{run}/summary.json")

def check_time(time,min_date,max_date):
    if min_date != None and time < min_date:
        return False
    elif max_date != None and time >= max_date:
        return False
    return True

def _list_relevent_calibrations(prefix,min_date,max_date):
    max_calibration_active_time = timedelta(days=6)
    list

CALIBRATION_ID_TO_TIME_REGEX = r'(\d\d\d\d)-(\d\d)-(\d\d)T(\d\d)-(\d\d)-(\d\d)'


def _parse_time_from_calibration_id(id):
    return  datetime(*[int(x) for x in re.findall(CALIBRATION_ID_TO_TIME_REGEX,id)[0]])

def _parse_time_from_od_id(id):
    return  datetime(*[int(x) for x in re.findall(CALIBRATION_ID_TO_TIME_REGEX,id)[0]])

def list_ssr_runs(prefix,output_type,
        min_date=None,
        max_date=None,
        filter_summary_not_exists=False):
    if output_type == ssr_output_type.od:
        return list_od_runs(
            prefix=prefix,
            min_date=min_date,
            max_date=max_date,
            filter_summary_not_exists=filter_summary_not_exists)
    elif output_type == ssr_output_type.ts:
        return list_ts_runs(
            prefix=prefix,
            min_date=min_date,
            max_date=max_date,
            filter_summary_not_exists=filter_summary_not_exists)
    else: 
        raise Exception(F"ssr_output_type is not supported: {output_type}")

def list_ts_runs(
        prefix,
        min_date=None,
        max_date=None,
        filter_summary_not_exists=False):
    runs = list_relevent_runs_by_calibration_id(path= prefix,start_date=min_date,end_date=max_date)
    with ThreadPoolExecutor(max_workers=5) as executor:
        runs = itertools.chain(*executor.map(
                    lambda run:
                        [{**run,**dict(path=F"{run['path']}/{folder}")} for folder in s3.list_dir(run['path'])]
                    , runs))
        if filter_summary_not_exists:
                runs = [run for run, exists in executor.map(
                    lambda run: (
                        run, summary_exists(run['path'])
                    ), runs) if exists]
    return runs

def list_od_runs(
        prefix,
        min_date=None,
        max_date=None,
        filter_summary_not_exists=False):
    runs = list_relevent_runs_by_calibration_id(path= prefix,start_date=min_date,end_date=max_date)
    if filter_summary_not_exists:
        with ThreadPoolExecutor(max_workers=5) as executor:
            runs = [run for run, exists in executor.map(
                lambda run: (
                    run, summary_exists(run['path'])
                ), runs) if exists]
    return runs


class CorrectionsFetcher:
  def __init__(self,ts_s3_path):
    self._correction_reader = CorrectionsReader()
    self._ts_s3_path = ts_s3_path;

  def _get_first_good_run(self,path):
    runs = s3.list_dir(path)
    for run in runs:
      run_s3_path = F"{path}/{run}"
      if summary_exists(run_s3_path):
        return run_s3_path
    return None



  def get_corrections_from_ts(self,calibration_id,start_time,end_time):
    calibration_s3_path = F"{self._ts_s3_path}/{calibration_id[:4]}/{calibration_id[5:7]}/{calibration_id}"
    ts_runs = [dict(time=datetime.strptime(x,"%Y-%m-%dT%H-%M-%S"),path=F"{calibration_s3_path}/{x}")
          for x in s3.list_dir(calibration_s3_path) ]
    ts_runs = [ts_run for ts_run in ts_runs if ts_run['time'] >= start_time  and ts_run['time'] < end_time +timedelta(minutes=20)]
    ts_runs.sort(key=lambda x: x['time'],reverse=True)
    res = {}
    for ts_run in ts_runs:
      path = self._get_first_good_run(ts_run['path'])
      if path:
        corrections = get_corrections(path).decode('utf-8')
        data = self._correction_reader.read(corrections)
        orbits = [x for x in data if x['record_type'] == 'ORBIT']
        clocks = [x for x in data if x['record_type'] == 'CLOCK']
        for orbit in orbits:
          time = orbit['time']
          if time <=start_time or time>end_time:
            continue
          clock = first([clock for clock in clocks if clock['time'] == orbit['time']])
          sats_info = {}
          for sat_id,orbit_info in orbit['sat_info'].items():
            if sat_id not in clock['sat_info']:
                continue
            clock_info = clock['sat_info'][sat_id]
            nav_id = orbit_info['nav_id']
            del orbit_info['iode']
            del clock_info['iode']
            del orbit_info['nav_id']
            sats_info[sat_id] = dict(
              nav_id = nav_id,
              orbit = orbit_info,
              clock = clock_info,
            )

          res[time] = dict(sats_info = sats_info,s3_source_path = path)
    return res