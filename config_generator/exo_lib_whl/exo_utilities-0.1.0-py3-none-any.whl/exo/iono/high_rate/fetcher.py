from datetime import datetime,timedelta
from IPython import embed
from exo.utilities import s3
from exo.iono.high_rate import summary_exists
import tarfile
import io
import json

def download_corrections(path):
  data = s3.get_object(F"{path}/vtec_correction.tar.gz")
  tarobj=  tarfile.open(fileobj=io.BytesIO(data))
  found_name = [i.name for i in tarobj.getmembers() if i.name.startswith('vtecCorrections') and i.name.endswith('json')][0]
  data = json.loads(tarobj.extractfile(found_name).read())
  return data


def download_vtec_std(path):
  data = s3.get_object(F"{path}/vtec_std.tar.gz")
  tarobj=  tarfile.open(fileobj=io.BytesIO(data))
  found_name = [i.name for i in tarobj.getmembers() if i.name.startswith('vtecStdDevGridCorrections') and i.name.endswith('json')][0]
  data = json.loads(tarobj.extractfile(found_name).read())
  return data


class VtecFinder:
  def __init__(self,s3_path):
    self._s3_path = s3_path

  def find(self, calibration_id,start_time,end_time):
    calibration_s3_path = F"{self._s3_path}/{calibration_id[:4]}/{calibration_id[5:7]}/{calibration_id}"
    vtec_runs = [dict(time=datetime.strptime(x,"%Y-%m-%dT%H-%M-%S"),path=F"{calibration_s3_path}/{x}")
          for x in s3.list_dir(calibration_s3_path)]
    vtec_runs = [vtec_run for vtec_run in vtec_runs if vtec_run['time'] >= start_time  and vtec_run['time'] < end_time +timedelta(minutes=30)]          
    for vtec_run in vtec_runs:
      path = self._get_first_good_run(vtec_run['path'])
      corrections = download_corrections(path)
      vtec = download_vtec_std(path)
      raise Exception("Not Implamented")

  def _get_first_good_run(self,path):
    runs = s3.list_dir(path)
    for run in runs:
      run_s3_path = F"{path}/{run}"
      if summary_exists(run_s3_path):
        return run_s3_path
    return None
    
if __name__ == '__main__':
  VtecFinder('s3://lear-exo-foc-staging-iono-vtec-vtec/v1').find('2021-05-05T00-00-00',datetime(2020,1,1),datetime(2023,1,1))
