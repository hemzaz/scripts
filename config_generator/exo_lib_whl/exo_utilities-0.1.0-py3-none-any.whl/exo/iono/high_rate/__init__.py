import json
from exo.utilities import s3

class NoLatestRunFound(Exception):
    pass


class IonoHighrateSearcher:
    def __init__(self, s3_path):
        self._s3_path = s3_path

    def latest_done(self, calibration_id):
        prefix = F"{self._s3_path}/{calibration_id[:4]}/{calibration_id[5:7]}/{calibration_id}"
        times = s3.list_dir(prefix)
        times.reverse()
        for time in times:
            for run_path in s3.list_dir(F"{prefix}/{time}"):
                sub_path = f"{prefix}/{time}/{run_path}"
                if s3.object_exists(F'{sub_path}/summary.json'):
                    return sub_path
        raise NoLatestRunFound(prefix)


def get_run_summary(run):
    return json.loads(s3.get_object(F"{run}/summary.json"))

def summary_exists(run):
    return s3.object_exists(F"{run}/summary.json")

def get_run_info(s3_path):
    return json.loads(s3.get_object(F"{s3_path}/run_info.json"))